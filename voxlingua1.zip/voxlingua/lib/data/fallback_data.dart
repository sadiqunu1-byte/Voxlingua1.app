import '../models/app_models.dart';

class AppStrings {
  static String get(String lang, String key) {
    return (_dict[lang] ?? _dict['ar']!)[key] ?? _dict['ar']![key] ?? key;
  }

  static const Map<String, Map<String, String>> _dict = {
    'ar': {
      'splashTagline': 'أتقن النطق والمحادثة اليومية',
      'streakUnit': 'يوم',
      'sentenceOfTheDay': 'جملة اليوم',
      'masteredBadge': 'مُتقنة ✓',
      'tapWordHint': 'اضغط على أي كلمة للمعنى',
      'listen': 'استماع',
      'listenSlow': 'استماع ببطء',
      'shadowingPrompt': 'اضغط الميكروفون وكرر الجملة بصوتك',
      'youSaid': 'ما سمعناه:',
      'prev': 'السابقة',
      'next': 'التالية',
      'random': 'جملة جديدة لا نهائية',
      'googleTranslate': 'ترجمة Google',
      'practiceCustom': 'تدرب على نصك الخاص',
      'shadowingTitle': 'تقنية الظل',
      'addCustomVideo': '+ رابط يوتيوب / SRT',
      'fetchNewVideos': 'تحديث القائمة',
      'waitingSpeech': 'في انتظار بدء الكلام في الفيديو...',
      'noCaptions': 'لم تتوفر ترجمة تلقائية لهذا المقطع، يمكنك لصق ملف SRT عبر الزر بالأعلى.',
      'builderTitle': 'تركيب الكلمات',
      'builderPrompt': 'رتّب الكلمات لتكوين المعنى التالي:',
      'tapWordsBelow': 'اضغط على الكلمات بالأسفل لتركيب الجملة...',
      'clear': 'مسح',
      'check': 'تحقق',
      'levelsTitle': 'المستويات الأوروبية',
      'back': 'رجوع',
      'loadMore': 'تحميل المزيد من المراجع العالمية',
      'myWordsTitle': 'كلماتي المحفوظة',
      'navHome': 'الرئيسية',
      'navShadowing': 'تقنية الظل',
      'navBuilder': 'تركيب الكلمات',
      'navLevels': 'المستويات',
      'navMyWords': 'كلماتي',
      'loadingWord': 'جارٍ جلب المعنى والنطق...',
      'meaningAr': 'المعنى بالعربية',
      'exampleSentence': 'مثال عملي',
      'saveToMyWords': 'حفظ في كلماتي',
      'savedSuccess': 'تم حفظ الكلمة في كلماتي!',
      'alreadySaved': 'الكلمة محفوظة مسبقاً.',
      'wordError': 'عذراً، تعذر جلب تفاصيل الكلمة حالياً. تحقق من الإنترنت.',
      'settingsTitle': 'الحساب والإعدادات',
      'interfaceLang': 'لغة الواجهة',
      'fontSize': 'حجم الخط',
      'clickSound': 'صوت النقر عند اللمس',
      'practiceCustomTitle': 'تدرب على نصك الخاص',
      'startPractice': 'ابدأ التدريب',
      'micDenied': 'يرجى منح إذن الميكروفون من إعدادات الهاتف لتقييم النطق.',
      'micUnavailable': 'التعرّف الصوتي غير متاح حالياً على هذا الجهاز.',
      'greatScore': 'نطق ممتاز! استمر بهذا الأداء الرائع 🌟',
      'goodScore': 'محاولة رائعة! قريب جداً من الإتقان 👍',
      'tryAgainScore': 'بداية جيدة! استمع ببطء وجرب مرة أخرى 💪',
      'builderCorrect': 'أحسنت! إجابة صحيحة 🎉',
      'builderWrong': 'الترتيب الصحيح هو:',
      'noSavedWords': 'لم تحفظ أي كلمات بعد. اضغط على أي كلمة أثناء التدريب لحفظها هنا.',
      'deleteWord': 'حذف',
      'loadingVideos': 'جارٍ تجهيز فيديوهات المستوى...',
      'videosSourceInfo': 'يوتيوب + دروس السحابة بتتبع الكلمة لحظياً',
      'videoLoadError': 'تعذر تشغيل هذا المقطع، جرب مقطعاً آخر من القائمة.',
      'customVideoTitle': 'إضافة رابط يوتيوب أو فيديو مع ترجمة SRT',
      'videoUrlHint': 'رابط YouTube أو رابط مباشر MP4/WebM',
      'srtHint': 'اختياري ليوتيوب (أو الصق نص SRT/VTT هنا)...',
      'openVideo': 'تشغيل المقطع',
      'masteredLabel': 'متقنة',
      'adminPinTitle': 'دخول لوحة الإدارة',
      'adminPinHint': 'أدخل الرمز السري (PIN)',
      'adminWrongPin': 'الرمز السري غير صحيح!',
      'enterBtn': 'دخول',
      'adminTitle': 'لوحة تحكم الأدمن',
      'syncNow': 'مزامنة السحابة الآن',
      'syncOk': 'تم تحديث الدروس من السحابة وحفظها بالكاش ✓',
      'syncFail': 'تعذر الاتصال؛ يعمل التطبيق بالنسخة المخبأة محلياً.',
      'updateTitle': 'يتوفر تحديث جديد للتطبيق!',
      'updateNow': 'تحديث الآن',
      'updateLater': 'لاحقاً',
    },
    'en': {
      'splashTagline': 'Master daily pronunciation & speaking',
      'streakUnit': 'days',
      'sentenceOfTheDay': 'Sentence of the Day',
      'masteredBadge': 'Mastered ✓',
      'tapWordHint': 'Tap any word for meaning',
      'listen': 'Listen',
      'listenSlow': 'Listen Slowly',
      'shadowingPrompt': 'Tap the mic and repeat the sentence aloud',
      'youSaid': 'You said:',
      'prev': 'Previous',
      'next': 'Next',
      'random': 'New Unlimited Sentence',
      'googleTranslate': 'Google Translate',
      'practiceCustom': 'Practice Your Own Text',
      'shadowingTitle': 'Shadowing Technique',
      'addCustomVideo': '+ YouTube / SRT',
      'fetchNewVideos': 'Refresh List',
      'waitingSpeech': 'Waiting for spoken dialogue...',
      'noCaptions': 'No auto-captions found for this clip. Paste SRT via the button above.',
      'builderTitle': 'Sentence Builder',
      'builderPrompt': 'Arrange the words to match this meaning:',
      'tapWordsBelow': 'Tap words below to build the sentence...',
      'clear': 'Clear',
      'check': 'Check',
      'levelsTitle': 'CEFR Levels',
      'back': 'Back',
      'loadMore': 'Load More from Global Sources',
      'myWordsTitle': 'My Saved Words',
      'navHome': 'Home',
      'navShadowing': 'Shadowing',
      'navBuilder': 'Builder',
      'navLevels': 'Levels',
      'navMyWords': 'My Words',
      'loadingWord': 'Fetching meaning & phonetics...',
      'meaningAr': 'Arabic Meaning',
      'exampleSentence': 'Practical Example',
      'saveToMyWords': 'Save to My Words',
      'savedSuccess': 'Word saved to My Words!',
      'alreadySaved': 'Word is already saved.',
      'wordError': 'Could not fetch word details right now. Check connection.',
      'settingsTitle': 'Account & Settings',
      'interfaceLang': 'Interface Language',
      'fontSize': 'Font Size',
      'clickSound': 'Tap Click Sound',
      'practiceCustomTitle': 'Practice Your Own Text',
      'startPractice': 'Start Practice',
      'micDenied': 'Please grant microphone permission in device settings.',
      'micUnavailable': 'Speech recognition is unavailable on this device.',
      'greatScore': 'Excellent pronunciation! Keep it up 🌟',
      'goodScore': 'Great try! Very close to mastery 👍',
      'tryAgainScore': 'Good start! Listen slowly and try again 💪',
      'builderCorrect': 'Well done! Correct sentence 🎉',
      'builderWrong': 'Correct order is:',
      'noSavedWords': 'No saved words yet. Tap any word anywhere to save it here.',
      'deleteWord': 'Delete',
      'loadingVideos': 'Loading level videos...',
      'videosSourceInfo': 'YouTube + Cloud with live word highlighting',
      'videoLoadError': 'Could not play this clip, try another one.',
      'customVideoTitle': 'Add YouTube or Video URL & Optional SRT',
      'videoUrlHint': 'YouTube URL or direct MP4/WebM link',
      'srtHint': 'Optional for YouTube (or paste SRT/VTT here)...',
      'openVideo': 'Play Clip',
      'masteredLabel': 'Mastered',
      'adminPinTitle': 'Admin Panel Access',
      'adminPinHint': 'Enter Secret PIN',
      'adminWrongPin': 'Incorrect PIN!',
      'enterBtn': 'Enter',
      'adminTitle': 'Admin JSON Generator',
      'syncNow': 'Sync Cloud Now',
      'syncOk': 'Cloud lessons synced & cached locally ✓',
      'syncFail': 'Offline or unreachable; using local cache.',
      'updateTitle': 'New App Update Available!',
      'updateNow': 'Update Now',
      'updateLater': 'Later',
    }
  };
}

class CefrMeta {
  final String code;
  final String descAr;
  final String descEn;
  const CefrMeta(this.code, this.descAr, this.descEn);
}

const List<CefrMeta> cefrMetaList = [
  CefrMeta('A1', 'المبتدئ: عبارات يومية أساسية للتعارف والاحتياجات البسيطة.', 'Beginner: Basic everyday phrases and simple needs.'),
  CefrMeta('A2', 'الأساسي: جمل شائعة عن الروتين، التسوق، والعائلة.', 'Elementary: Common expressions on routine and shopping.'),
  CefrMeta('B1', 'المتوسط: التحليل التكتيكي لكرة القدم والمحادثات العملية.', 'Intermediate: Football tactics & practical conversations.'),
  CefrMeta('B2', 'فوق المتوسط: نقاشات التحليل التكتيكي والمواقف المتقدمة.', 'Upper-Intermediate: Tactical football analysis & debates.'),
  CefrMeta('C1', 'المتقدم: تحليلات تكتيكية احترافية وتعبيرات دقيقة.', 'Advanced: Pro tactical breakdowns & fluent speech.'),
  CefrMeta('C2', 'الإتقان: محاضرات متقدمة وفهم عميق للتراكيب.', 'Proficiency: Mastery of nuanced, complex English.'),
];

// قائمة فيديوهات يوتيوب حقيقية ومحققة مقسمة حسب المستويات (مع التركيز على التحليل التكتيكي لكرة القدم في B1/B2/C1)
List<ShadowingVideo> getCuratedYoutubeVideos(String level) {
  switch (level.toUpperCase()) {
    case 'A1':
      return [
        ShadowingVideo(id: 'yt_1vUTq', level: 'A1', youtubeId: '1vUTq-Pd4Vs', title: 'What Can You Do? Easy English Conversations', sourceName: 'BBC Learning English', durationSec: 360),
        ShadowingVideo(id: 'yt_sJ7sR', level: 'A1', youtubeId: 'sJ7sRSK2in4', title: 'Talking About Daily Routines (Real Easy English)', sourceName: 'BBC Learning English', durationSec: 380),
        ShadowingVideo(id: 'yt_fLB70', level: 'A1', youtubeId: 'fLB70DZdqIE', title: 'Learn the Language to Talk About Worries', sourceName: 'BBC Learning English', durationSec: 360),
      ];
    case 'A2':
      return [
        ShadowingVideo(id: 'yt_9GT95', level: 'A2', youtubeId: '9GT95P0B-AM', title: '4 Useful Phrasal Verbs for Daily Relaxation', sourceName: 'BBC Learning English', durationSec: 180),
        ShadowingVideo(id: 'yt_i9K0S', level: 'A2', youtubeId: 'i9K0SxFSyx0', title: 'Everyday Conversations to Improve Your English', sourceName: 'Learn English with Jessica', durationSec: 900),
        ShadowingVideo(id: 'yt_1vUTq2', level: 'A2', youtubeId: '1vUTq-Pd4Vs', title: 'Easy Practical English Dialogues at Work & Home', sourceName: 'BBC Learning English', durationSec: 360),
      ];
    case 'B1':
      return [
        ShadowingVideo(id: 'yt_RWNtM', level: 'B1', youtubeId: 'RWNtMDjwrGU', title: 'Football Tactics: Francesco Totti Role Explained', sourceName: 'Tifo Football', durationSec: 420),
        ShadowingVideo(id: 'yt_KaMRL', level: 'B1', youtubeId: 'KaMRLpSnD_E', title: 'Football Tactics Breakdown: David Moyes Setup', sourceName: 'Tifo Football', durationSec: 480),
        ShadowingVideo(id: 'yt_oeoQU', level: 'B1', youtubeId: 'oeoQU26Lx0A', title: 'Practical Conversation: Is It OK to Disagree?', sourceName: 'BBC Learning English', durationSec: 370),
      ];
    case 'B2':
      return [
        ShadowingVideo(id: 'yt_khvii', level: 'B2', youtubeId: '-khviiki9rA', title: 'Tactical Analysis: England 1-1 Switzerland Euro 2024', sourceName: "Coaches' Voice", durationSec: 540),
        ShadowingVideo(id: 'yt_dgFm7', level: 'B2', youtubeId: 'dgFm7A8pyzo', title: 'Practical Discussion: Living with Debt (6 Min English)', sourceName: 'BBC Learning English', durationSec: 380),
        ShadowingVideo(id: 'yt_FZDIm', level: 'B2', youtubeId: 'FZDImEiPgMk', title: 'Feed Your Brain: Science & Habits Discussion', sourceName: 'BBC Learning English', durationSec: 370),
      ];
    case 'C1':
      return [
        ShadowingVideo(id: 'yt_khvii2', level: 'C1', youtubeId: '-khviiki9rA', title: 'Advanced Match Pressing & Midfield Tactics Breakdown', sourceName: "Coaches' Voice", durationSec: 540),
        ShadowingVideo(id: 'yt_RWNtM2', level: 'C1', youtubeId: 'RWNtMDjwrGU', title: 'Tactical Evolution of the False Nine in Football', sourceName: 'Tifo Football', durationSec: 420),
        ShadowingVideo(id: 'yt_7m75B', level: 'C1', youtubeId: '7m75Bi3rzjM', title: 'Being Human: Advanced Vocabulary Masterclass', sourceName: 'BBC Learning English', durationSec: 900),
      ];
    case 'C2':
      return [
        ShadowingVideo(id: 'yt_eAUOK', level: 'C2', youtubeId: 'eAU_OKKK9Pw', title: 'Nuanced Body Language & Communication Expressions', sourceName: 'BBC Learning English', durationSec: 420),
        ShadowingVideo(id: 'yt_nB9lN', level: 'C2', youtubeId: 'nB9lNrkfc88', title: 'Psychological Transitions & Academic Discourse', sourceName: 'BBC Learning English', durationSec: 380),
        ShadowingVideo(id: 'yt_7m75B2', level: 'C2', youtubeId: '7m75Bi3rzjM', title: 'Complex Idioms & Advanced Listening Compilation', sourceName: 'BBC Learning English', durationSec: 900),
      ];
    default:
      return getCuratedYoutubeVideos('A1');
  }
}

const List<SentenceItem> fallbackDailySentences = [
  SentenceItem(id: 's1', level: 'A1', en: 'Could you tell me how to get to the nearest train station?', ar: 'هل يمكنك إخباري بكيفية الوصول إلى أقرب محطة قطار؟'),
  SentenceItem(id: 's2', level: 'A2', en: 'I usually drink a cup of coffee before I start working.', ar: 'عادةً ما أشرب فنجاناً من القهوة قبل أن أبدأ العمل.'),
  SentenceItem(id: 's3', level: 'B1', en: 'The midfielders pressed high to win possession near the box.', ar: 'ضغط لاعبو الوسط عالياً لاستعادة الكرة قرب منطقة الجزاء.'),
  SentenceItem(id: 's4', level: 'B1', en: 'I am looking forward to hearing from you very soon.', ar: 'أتطلع إلى سماع أخبارك قريباً جداً.'),
  SentenceItem(id: 's5', level: 'B2', en: 'Switching the play quickly creates space behind the full-backs.', ar: 'تغيير جهة اللعب بسرعة يخلق مساحة خلف الأظهرة.'),
  SentenceItem(id: 's6', level: 'C1', en: 'Consistency is far more valuable than short bursts of intense effort.', ar: 'الاستمرارية أكثر قيمة بكثير من فترات الجهد المكثف القصيرة.'),
];

const Map<String, List<LevelVocabItem>> fallbackLevelData = {
  'A1': [
    LevelVocabItem(word: 'morning', phonetic: '/ˈmɔːrnɪŋ/', ar: 'صباح', en: 'Good morning, how did you sleep last night?', enAr: 'صباح الخير، كيف نمت الليلة الماضية؟'),
    LevelVocabItem(word: 'water', phonetic: '/ˈwɔːtər/', ar: 'ماء', en: 'Can I have a glass of cold water, please?', enAr: 'هل يمكنني الحصول على كوب ماء بارد من فضلك؟'),
    LevelVocabItem(word: 'friend', phonetic: '/frend/', ar: 'صديق', en: 'My best friend lives near the city center.', enAr: 'صديقي المقرب يعيش بالقرب من وسط المدينة.'),
  ],
  'A2': [
    LevelVocabItem(word: 'schedule', phonetic: '/ˈskedʒuːl/', ar: 'جدول مواعيد', en: 'Let me check my schedule for tomorrow afternoon.', enAr: 'دعني أتحقق من جدولي لبعد ظهر الغد.'),
    LevelVocabItem(word: 'improve', phonetic: '/ɪmˈpruːv/', ar: 'يحسّن', en: 'Reading every day will improve your English fast.', enAr: 'القراءة يومياً ستحسّن إنجليزيتك بسرعة.'),
  ],
  'B1': [
    LevelVocabItem(word: 'pressing', phonetic: '/ˈpresɪŋ/', ar: 'الضغط التكتيكي', en: 'High pressing forces the opponent into quick mistakes.', enAr: 'الضغط العالي يجبر الخصم على ارتكاب أخطاء سريعة.'),
    LevelVocabItem(word: 'confidence', phonetic: '/ˈkɒnfɪdəns/', ar: 'ثقة', en: 'Speaking aloud builds confidence in real conversations.', enAr: 'التحدث بصوت عالٍ يبني الثقة في المحادثات الحقيقية.'),
  ],
  'B2': [
    LevelVocabItem(word: 'transition', phonetic: '/trænˈzɪʃən/', ar: 'التحول السريع', en: 'Fast transitions turn defense into a dangerous attack.', enAr: 'التحولات السريعة تحوّل الدفاع إلى هجمة خطيرة.'),
    LevelVocabItem(word: 'perspective', phonetic: '/pərˈspektɪv/', ar: 'منظور', en: 'Travel gives you a fresh perspective on life.', enAr: 'السفر يمنحك منظوراً جديداً للحياة.'),
  ],
  'C1': [
    LevelVocabItem(word: 'overload', phonetic: '/ˈoʊvərloʊd/', ar: 'الزيادة العددية', en: 'The wingers tucked inside to create a midfield overload.', enAr: 'تعمّق الأجنحة للداخل لخلق زيادة عددية في الوسط.'),
    LevelVocabItem(word: 'resilience', phonetic: '/rɪˈzɪliəns/', ar: 'صمود ومرونة', en: 'Resilience helps us adapt quickly to unexpected changes.', enAr: 'المرونة تساعدنا على التكيف سريعاً مع التغيرات غير المتوقعة.'),
  ],
  'C2': [
    LevelVocabItem(word: 'eloquent', phonetic: '/ˈeləkwənt/', ar: 'بليغ', en: 'Her eloquent speech moved everyone in the auditorium.', enAr: 'خطابها البليغ أثّر في كل من في القاعة.'),
    LevelVocabItem(word: 'pragmatic', phonetic: '/præɡˈmætɪk/', ar: 'عملي وواقعي', en: 'We need a pragmatic approach to solve this issue.', enAr: 'نحتاج إلى نهج عملي لحل هذه المشكلة.'),
  ],
};