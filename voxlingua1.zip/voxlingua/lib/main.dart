import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import 'data/fallback_data.dart';
import 'screens/admin_panel_screen.dart';
import 'screens/builder_screen.dart';
import 'screens/home_screen.dart';
import 'screens/levels_screen.dart';
import 'screens/my_words_screen.dart';
import 'screens/phonics_screen.dart';
import 'screens/shadowing_screen.dart';
import 'screens/splash_screen.dart';
import 'services/api_service.dart';
import 'services/speech_service.dart';
import 'services/storage_service.dart';
import 'theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final locale = WidgetsBinding.instance.platformDispatcher.locale;
  await StorageService.instance.init(locale);
  runApp(const VoxlinguaApp());
}

class VoxlinguaApp extends StatefulWidget {
  const VoxlinguaApp({super.key});
  @override
  State<VoxlinguaApp> createState() => _VoxlinguaAppState();
}

class _VoxlinguaAppState extends State<VoxlinguaApp> {
  bool _showSplash = true;

  @override
  Widget build(BuildContext context) {
    final store = StorageService.instance;
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) {
        final isAr = store.lang == 'ar';
        return MaterialApp(
          debugShowCheckedModeBanner: false,
          title: 'Voxlingua',
          theme: AppTheme.buildTheme(isAr),
          builder: (ctx, child) => Directionality(
            textDirection: isAr ? TextDirection.rtl : TextDirection.ltr,
            child: MediaQuery(
              data: MediaQuery.of(ctx).copyWith(textScaler: TextScaler.linear(store.fontScalePercent / 100.0)),
              child: child ?? const SizedBox.shrink(),
            ),
          ),
          home: AnimatedSwitcher(
            duration: const Duration(milliseconds: 400),
            child: _showSplash
                ? SplashScreen(onFinished: () => setState(() => _showSplash = false))
                : const MainShell(),
          ),
        );
      },
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});
  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    _syncAndCheckUpdates();
  }

  Future<void> _syncAndCheckUpdates() async {
    await ApiService.instance.syncRemoteContent(force: true);
    final update = ApiService.instance.checkPendingUpdate();
    if (update != null && mounted) {
      final lang = StorageService.instance.lang;
      showDialog(
        context: context,
        barrierDismissible: !update.force,
        builder: (ctx) => AlertDialog(
          backgroundColor: AppColors.tealDark,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          title: Text('${AppStrings.get(lang, 'updateTitle')} (v${update.version})', style: const TextStyle(color: Colors.white, fontSize: 16)),
          content: Text(update.notes.isNotEmpty ? update.notes : 'v${update.version}', style: const TextStyle(color: Colors.white70)),
          actions: [
            if (!update.force)
              TextButton(
                onPressed: () => Navigator.pop(ctx),
                child: Text(AppStrings.get(lang, 'updateLater'), style: const TextStyle(color: Colors.white70)),
              ),
            ElevatedButton(
              style: ElevatedButton.styleFrom(backgroundColor: AppColors.tealAccent, foregroundColor: AppColors.tealDark),
              onPressed: () => launchUrl(Uri.parse(update.apkUrl), mode: LaunchMode.externalApplication),
              child: Text(AppStrings.get(lang, 'updateNow'), style: const TextStyle(fontWeight: FontWeight.w700)),
            ),
          ],
        ),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    final store = StorageService.instance;
    final lang = store.lang;

    return Scaffold(
      backgroundColor: AppColors.bgMain,
      appBar: AppBar(
        backgroundColor: AppColors.bgMain,
        elevation: 0,
        surfaceTintColor: Colors.transparent,
        titleSpacing: 14,
        title: Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
              decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(99)),
              child: Text('🔥 ${store.streak} ${AppStrings.get(lang, 'streakUnit')}',
                  style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w700)),
            ),
            const VoxlinguaLogo(fontSize: 22),
            IconButton(
              onPressed: () => showSettingsModal(context),
              icon: const Icon(Icons.person_outline_rounded, color: AppColors.tealDark),
            ),
          ],
        ),
      ),
      body: IndexedStack(
        index: _tab,
        children: const [HomeScreen(), ShadowingScreen(), BuilderScreen(), LevelsScreen(), MyWordsScreen(), PhonicsScreen()],
      ),
      bottomNavigationBar: _VoxBottomBar(
        currentIndex: _tab,
        onTap: (i) {
          SpeechService.instance.playTapClick();
          setState(() => _tab = i);
        },
        items: [
          _NavItemData(Icons.home_rounded, AppStrings.get(lang, 'navHome')),
          _NavItemData(Icons.ondemand_video_rounded, AppStrings.get(lang, 'navShadowing')),
          _NavItemData(Icons.grid_view_rounded, AppStrings.get(lang, 'navBuilder')),
          _NavItemData(Icons.bar_chart_rounded, AppStrings.get(lang, 'navLevels')),
          _NavItemData(Icons.bookmark_rounded, AppStrings.get(lang, 'navMyWords')),
          _NavItemData(Icons.abc_rounded, lang == 'ar' ? 'التأسيس' : 'Phonics'),
        ],
      ),
    );
  }
}

class _NavItemData {
  final IconData icon;
  final String label;
  const _NavItemData(this.icon, this.label);
}

/// شريط تنقل سفلي بنفس شكل الشريط السابق، لكنه يتّسع لست تبويبات دون تجاوز (overflow):
/// التسمية تلتفّ على سطرين وارتفاع الشريط يتمدّد تلقائياً مع حجم الخط.
class _VoxBottomBar extends StatelessWidget {
  final int currentIndex;
  final List<_NavItemData> items;
  final ValueChanged<int> onTap;
  const _VoxBottomBar({required this.currentIndex, required this.items, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return ClipRRect(
      borderRadius: const BorderRadius.vertical(top: Radius.circular(24)),
      child: Material(
        color: AppColors.tealDark,
        child: SafeArea(
          top: false,
          child: Padding(
            padding: const EdgeInsets.symmetric(vertical: 6),
            child: Row(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: [
                for (int i = 0; i < items.length; i++)
                  Expanded(
                    child: InkWell(
                      onTap: () => onTap(i),
                      child: Padding(
                        padding: const EdgeInsets.symmetric(vertical: 4, horizontal: 2),
                        child: Column(
                          mainAxisSize: MainAxisSize.min,
                          children: [
                            Icon(
                              items[i].icon,
                              size: 24,
                              color: i == currentIndex ? AppColors.tealAccent : Colors.white60,
                            ),
                            const SizedBox(height: 2),
                            Text(
                              items[i].label,
                              maxLines: 2,
                              overflow: TextOverflow.ellipsis,
                              textAlign: TextAlign.center,
                              style: TextStyle(
                                fontSize: i == currentIndex ? 11 : 10.5,
                                height: 1.15,
                                fontWeight: i == currentIndex ? FontWeight.w600 : FontWeight.w400,
                                color: i == currentIndex ? AppColors.tealAccent : Colors.white60,
                              ),
                            ),
                          ],
                        ),
                      ),
                    ),
                  ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}

void showSettingsModal(BuildContext context) {
  SpeechService.instance.playTapClick();
  showDialog(context: context, builder: (_) => const _SettingsDialog());
}

class _SettingsDialog extends StatelessWidget {
  const _SettingsDialog();
  static const String _adminPin = '2026';

  void _promptAdminPin(BuildContext rootCtx) {
    final pinCtrl = TextEditingController();
    final lang = StorageService.instance.lang;
    showDialog(
      context: rootCtx,
      builder: (pinCtx) => AlertDialog(
        backgroundColor: AppColors.tealDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(22)),
        title: Text(AppStrings.get(lang, 'adminPinTitle'), style: const TextStyle(color: Colors.white, fontSize: 16)),
        content: TextField(
          controller: pinCtrl, keyboardType: TextInputType.number, obscureText: true, textDirection: TextDirection.ltr,
          style: const TextStyle(color: Colors.white, letterSpacing: 4),
          decoration: InputDecoration(
            filled: true, fillColor: AppColors.tealSub, hintText: AppStrings.get(lang, 'adminPinHint'),
            hintStyle: const TextStyle(color: Colors.white54, letterSpacing: 0),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
          ),
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.tealAccent, foregroundColor: AppColors.tealDark),
            onPressed: () {
              if (pinCtrl.text.trim() == _adminPin) {
                Navigator.pop(pinCtx);
                Navigator.push(rootCtx, MaterialPageRoute(builder: (_) => const AdminPanelScreen()));
              } else {
                Navigator.pop(pinCtx);
                ScaffoldMessenger.of(rootCtx).showSnackBar(
                  SnackBar(content: Text(AppStrings.get(lang, 'adminWrongPin')), backgroundColor: AppColors.orangeText),
                );
              }
            },
            child: Text(AppStrings.get(lang, 'enterBtn'), style: const TextStyle(fontWeight: FontWeight.w700)),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = StorageService.instance;
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) {
        final lang = store.lang;
        return Dialog(
          backgroundColor: AppColors.tealDark,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(AppStrings.get(lang, 'settingsTitle'), style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700)),
                    IconButton(onPressed: () { SpeechService.instance.playTapClick(); Navigator.pop(context); }, icon: const Icon(Icons.close, color: Colors.white)),
                  ],
                ),
                const SizedBox(height: 14),
                Text(AppStrings.get(lang, 'interfaceLang'), style: const TextStyle(color: Colors.white70, fontSize: 14)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(child: _LangOptionBtn(label: 'العربية', active: lang == 'ar', onTap: () { SpeechService.instance.playTapClick(); store.setLanguage('ar'); })),
                    const SizedBox(width: 8),
                    Expanded(child: _LangOptionBtn(label: 'English', active: lang == 'en', onTap: () { SpeechService.instance.playTapClick(); store.setLanguage('en'); })),
                  ],
                ),
                const SizedBox(height: 18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(AppStrings.get(lang, 'fontSize'), style: const TextStyle(color: Colors.white70, fontSize: 14)),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(color: AppColors.tealAccent, borderRadius: BorderRadius.circular(99)),
                      child: Text('${store.fontScalePercent}%', style: const TextStyle(color: AppColors.tealDark, fontWeight: FontWeight.w700)),
                    ),
                  ],
                ),
                Row(
                  children: [
                    IconButton(onPressed: () { SpeechService.instance.playTapClick(); store.setFontScale(store.fontScalePercent - 5); }, icon: const Icon(Icons.remove_circle_outline, color: Colors.white)),
                    Expanded(
                      child: Slider(
                        value: store.fontScalePercent.toDouble(), min: 80, max: 150, divisions: 14,
                        activeColor: AppColors.tealAccent, inactiveColor: Colors.white24,
                        onChanged: (v) => store.setFontScale(v.round()),
                      ),
                    ),
                    IconButton(onPressed: () { SpeechService.instance.playTapClick(); store.setFontScale(store.fontScalePercent + 5); }, icon: const Icon(Icons.add_circle_outline, color: Colors.white)),
                  ],
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(color: AppColors.tealSub, borderRadius: BorderRadius.circular(16)),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(AppStrings.get(lang, 'clickSound'), style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                      Switch(
                        value: store.clickSound,
                        activeColor: AppColors.tealDark,
                        activeTrackColor: AppColors.tealAccent,
                        onChanged: (v) async { await store.setClickSound(v); if (v) SpeechService.instance.playTapClick(); },
                      ),
                    ],
                  ),
                ),
                const SizedBox(height: 12),
                GestureDetector(
                  onLongPress: () {
                    final navCtx = Navigator.of(context, rootNavigator: true).context;
                    Navigator.pop(context);
                    _promptAdminPin(navCtx);
                  },
                  child: const Padding(
                    padding: EdgeInsets.symmetric(vertical: 6),
                    child: Text('Voxlingua v1.0.0', textAlign: TextAlign.center, style: TextStyle(color: Colors.white38, fontSize: 12)),
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _LangOptionBtn extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _LangOptionBtn({required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(color: active ? AppColors.tealAccent : AppColors.tealSub, borderRadius: BorderRadius.circular(14)),
        alignment: Alignment.center,
        child: Text(label, style: TextStyle(color: active ? AppColors.tealDark : Colors.white, fontWeight: FontWeight.w700)),
      ),
    );
  }
}