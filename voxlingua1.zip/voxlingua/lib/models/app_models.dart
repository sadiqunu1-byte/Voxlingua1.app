class SentenceItem {
  final String id;
  final String level;
  final String en;
  final String ar;

  const SentenceItem({
    required this.id,
    required this.level,
    required this.en,
    required this.ar,
  });
}

class WordLookup {
  final String word;
  final String phonetic;
  final String arabic;
  final String example;

  const WordLookup({
    required this.word,
    required this.phonetic,
    required this.arabic,
    required this.example,
  });

  Map<String, dynamic> toJson() => {
        'word': word,
        'phonetic': phonetic,
        'arabic': arabic,
        'example': example,
      };

  factory WordLookup.fromJson(Map<String, dynamic> json) => WordLookup(
        word: (json['word'] ?? '').toString(),
        phonetic: (json['phonetic'] ?? '').toString(),
        arabic: (json['arabic'] ?? '').toString(),
        example: (json['example'] ?? '').toString(),
      );
}

class WordTiming {
  final String word;
  final int startMs;
  final int endMs;

  const WordTiming({
    required this.word,
    required this.startMs,
    required this.endMs,
  });

  Map<String, dynamic> toJson() => {
        'word': word,
        'startMs': startMs,
        'endMs': endMs,
      };

  factory WordTiming.fromJson(Map<String, dynamic> json) => WordTiming(
        word: (json['word'] ?? '').toString(),
        startMs: (json['startMs'] as num?)?.toInt() ?? 0,
        endMs: (json['endMs'] as num?)?.toInt() ?? 0,
      );
}

class SubtitleCue {
  final int startMs;
  final int endMs;
  final String en;
  String ar;
  List<WordTiming> words;

  SubtitleCue({
    required this.startMs,
    required this.endMs,
    required this.en,
    this.ar = '',
    List<WordTiming>? words,
  }) : words = words ?? [];

  Map<String, dynamic> toJson() => {
        'startMs': startMs,
        'endMs': endMs,
        'en': en,
        'ar': ar,
      };

  factory SubtitleCue.fromJson(Map<String, dynamic> json) => SubtitleCue(
        startMs: (json['startMs'] as num?)?.toInt() ?? 0,
        endMs: (json['endMs'] as num?)?.toInt() ?? 0,
        en: (json['en'] ?? '').toString(),
        ar: (json['ar'] ?? '').toString(),
      );
}

class ShadowingVideo {
  final String id;
  final String level;
  final String title;
  final String videoUrl;
  final String youtubeId;
  final String subtitleUrl;
  final String sourceName;
  final int durationSec;
  List<SubtitleCue> cues;

  ShadowingVideo({
    required this.id,
    this.level = 'A1',
    required this.title,
    this.videoUrl = '',
    this.youtubeId = '',
    this.subtitleUrl = '',
    required this.sourceName,
    this.durationSec = 0,
    List<SubtitleCue>? cues,
  }) : cues = cues ?? [];

  bool get isYouTube => youtubeId.isNotEmpty;

  Map<String, dynamic> toJson() => {
        'id': id,
        'level': level,
        'title': title,
        'videoUrl': videoUrl,
        'youtubeId': youtubeId,
        'subtitleUrl': subtitleUrl,
        'sourceName': sourceName,
        'durationSec': durationSec,
        'cues': cues.map((c) => c.toJson()).toList(),
      };

  factory ShadowingVideo.fromJson(Map<String, dynamic> json) => ShadowingVideo(
        id: (json['id'] ?? '').toString(),
        level: (json['level'] ?? 'A1').toString(),
        title: (json['title'] ?? '').toString(),
        videoUrl: (json['videoUrl'] ?? '').toString(),
        youtubeId: (json['youtubeId'] ?? '').toString(),
        subtitleUrl: (json['subtitleUrl'] ?? '').toString(),
        sourceName: (json['sourceName'] ?? 'Voxlingua Cloud').toString(),
        durationSec: (json['durationSec'] as num?)?.toInt() ?? 0,
        cues: ((json['cues'] as List?) ?? [])
            .map((e) => SubtitleCue.fromJson(Map<String, dynamic>.from(e as Map)))
            .toList(),
      );
}

class LevelVocabItem {
  final String word;
  final String phonetic;
  final String ar;
  final String en;
  final String enAr;

  const LevelVocabItem({
    required this.word,
    required this.phonetic,
    required this.ar,
    required this.en,
    required this.enAr,
  });

  Map<String, dynamic> toJson() => {
        'word': word,
        'phonetic': phonetic,
        'ar': ar,
        'en': en,
        'enAr': enAr,
      };

  factory LevelVocabItem.fromJson(Map<String, dynamic> json) => LevelVocabItem(
        word: (json['word'] ?? '').toString(),
        phonetic: (json['phonetic'] ?? '').toString(),
        ar: (json['ar'] ?? '').toString(),
        en: (json['en'] ?? '').toString(),
        enAr: (json['enAr'] ?? '').toString(),
      );
}

class WordFeedback {
  final String text;
  final bool isCorrect;

  const WordFeedback({required this.text, required this.isCorrect});
}

class PronunciationEval {
  final int score;
  final List<WordFeedback> words;

  const PronunciationEval({required this.score, required this.words});
}