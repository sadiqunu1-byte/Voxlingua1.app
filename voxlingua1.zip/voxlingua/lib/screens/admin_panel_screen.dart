import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../data/fallback_data.dart';
import '../models/app_models.dart';
import '../services/api_service.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';

class AdminPanelScreen extends StatefulWidget {
  const AdminPanelScreen({super.key});
  @override
  State<AdminPanelScreen> createState() => _AdminPanelScreenState();
}

class _AdminPanelScreenState extends State<AdminPanelScreen> {
  final _urlCtrl = TextEditingController(text: StorageService.instance.remoteJsonUrl);
  final _titleCtrl = TextEditingController();
  final _videoUrlCtrl = TextEditingController();
  final _durCtrl = TextEditingController(text: '180');
  final _srtCtrl = TextEditingController();

  final _wordCtrl = TextEditingController();
  final _phoneticCtrl = TextEditingController();
  final _arWordCtrl = TextEditingController();
  final _enSentCtrl = TextEditingController();
  final _arSentCtrl = TextEditingController();

  String _level = 'A1';
  int _mode = 0;
  bool _busy = false;
  String _statusMsg = '';
  List<SubtitleCue> _parsedCues = [];
  String _generatedJson = '';

  @override
  void dispose() {
    _urlCtrl.dispose();
    _titleCtrl.dispose();
    _videoUrlCtrl.dispose();
    _durCtrl.dispose();
    _srtCtrl.dispose();
    _wordCtrl.dispose();
    _phoneticCtrl.dispose();
    _arWordCtrl.dispose();
    _enSentCtrl.dispose();
    _arSentCtrl.dispose();
    super.dispose();
  }

  Future<void> _syncCloud() async {
    SpeechService.instance.playTapClick();
    setState(() { _busy = true; _statusMsg = ''; });
    await StorageService.instance.setRemoteJsonUrl(_urlCtrl.text);
    final ok = await ApiService.instance.syncRemoteContent(force: true);
    if (!mounted) return;
    final lang = StorageService.instance.lang;
    setState(() { _busy = false; _statusMsg = AppStrings.get(lang, ok ? 'syncOk' : 'syncFail'); });
  }

  Future<void> _parseAndTranslateVideo({required bool fullDocument}) async {
    SpeechService.instance.playTapClick();
    final rawUrl = _videoUrlCtrl.text.trim();
    final ytId = YoutubePlayer.convertUrlToId(rawUrl) ?? '';
    final videoObj = ShadowingVideo(
      id: 'vid_${DateTime.now().millisecondsSinceEpoch}',
      level: _level,
      title: _titleCtrl.text.trim().isEmpty ? 'New Shadowing Lesson' : _titleCtrl.text.trim(),
      youtubeId: ytId,
      videoUrl: ytId.isEmpty ? rawUrl : '',
      sourceName: ytId.isNotEmpty ? 'YouTube Cloud' : 'Voxlingua Cloud',
      durationSec: int.tryParse(_durCtrl.text.trim()) ?? 180,
    );

    setState(() { _busy = true; _statusMsg = '...'; });
    List<SubtitleCue> cues = _srtCtrl.text.trim().isNotEmpty
        ? ApiService.parseSrtOrVtt(_srtCtrl.text)
        : await ApiService.instance.loadAndTranslateSubtitles(videoObj);

    for (int i = 0; i < cues.length; i++) {
      if (cues[i].ar.isEmpty) {
        cues[i].ar = await ApiService.instance.translateToArabic(cues[i].en).catchError((_) => '');
      }
      if (mounted) setState(() => _statusMsg = '${i + 1} / ${cues.length}');
    }
    videoObj.cues = cues;

    const encoder = JsonEncoder.withIndent('  ');
    String output;
    if (fullDocument) {
      final root = ApiService.instance.getCurrentCloudMapSnapshot();
      final list = List<dynamic>.from((root['videos'] as List?) ?? []);
      list.insert(0, videoObj.toJson());
      root['videos'] = list;
      output = encoder.convert(root);
    } else {
      output = encoder.convert(videoObj.toJson());
    }
    if (mounted) setState(() { _busy = false; _parsedCues = cues; _generatedJson = output; });
  }

  Future<void> _autoFillWord() async {
    final w = _wordCtrl.text.trim();
    if (w.isEmpty) return;
    SpeechService.instance.playTapClick();
    setState(() => _busy = true);
    try {
      final info = await ApiService.instance.lookupWord(w);
      final exAr = await ApiService.instance.translateToArabic(info.example).catchError((_) => info.arabic);
      if (mounted) {
        _phoneticCtrl.text = info.phonetic;
        _arWordCtrl.text = info.arabic;
        _enSentCtrl.text = info.example;
        _arSentCtrl.text = exAr;
      }
    } catch (_) {}
    if (mounted) setState(() => _busy = false);
  }

  void _generateVocabJson({required bool fullDocument}) {
    SpeechService.instance.playTapClick();
    final item = LevelVocabItem(
      word: _wordCtrl.text.trim(),
      phonetic: _phoneticCtrl.text.trim(),
      ar: _arWordCtrl.text.trim(),
      en: _enSentCtrl.text.trim(),
      enAr: _arSentCtrl.text.trim(),
    );
    const encoder = JsonEncoder.withIndent('  ');
    String output;
    if (fullDocument) {
      final root = ApiService.instance.getCurrentCloudMapSnapshot();
      final lessons = Map<String, dynamic>.from((root['lessons'] as Map?) ?? {});
      final lvlList = List<dynamic>.from((lessons[_level] as List?) ?? []);
      lvlList.insert(0, item.toJson());
      lessons[_level] = lvlList;
      root['lessons'] = lessons;
      output = encoder.convert(root);
    } else {
      output = encoder.convert(item.toJson());
    }
    setState(() => _generatedJson = output);
  }

  Future<void> _copyJson() async {
    if (_generatedJson.isEmpty) return;
    SpeechService.instance.playTapClick();
    await Clipboard.setData(ClipboardData(text: _generatedJson));
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        const SnackBar(content: Text('JSON Copied! ✓'), backgroundColor: AppColors.tealDark),
      );
    }
  }

  Widget _field(TextEditingController c, String label, {int lines = 1, bool ltr = false}) {
    return Padding(
      padding: const EdgeInsets.only(bottom: 10),
      child: TextField(
        controller: c,
        maxLines: lines,
        textDirection: ltr ? TextDirection.ltr : null,
        style: const TextStyle(color: Colors.white, fontSize: 13.5),
        decoration: InputDecoration(
          labelText: label,
          labelStyle: const TextStyle(color: AppColors.tealAccent, fontSize: 12.5),
          filled: true,
          fillColor: AppColors.tealSub,
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lang = StorageService.instance.lang;
    return Scaffold(
      backgroundColor: AppColors.bgMain,
      appBar: AppBar(
        backgroundColor: AppColors.tealDark,
        foregroundColor: Colors.white,
        title: Text(AppStrings.get(lang, 'adminTitle'), style: const TextStyle(fontWeight: FontWeight.w700)),
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(20)),
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                _field(_urlCtrl, 'GitHub Raw JSON URL', ltr: true),
                ElevatedButton.icon(
                  style: ElevatedButton.styleFrom(backgroundColor: AppColors.tealAccent, foregroundColor: AppColors.tealDark),
                  onPressed: _busy ? null : _syncCloud,
                  icon: const Icon(Icons.cloud_sync_rounded),
                  label: Text(AppStrings.get(lang, 'syncNow'), style: const TextStyle(fontWeight: FontWeight.w700)),
                ),
                if (_statusMsg.isNotEmpty) ...[
                  const SizedBox(height: 8),
                  Text(_statusMsg, textAlign: TextAlign.center, style: const TextStyle(color: AppColors.tealAccent, fontSize: 12.5)),
                ],
              ],
            ),
          ),
          const SizedBox(height: 12),
          Row(
            children: [
              Expanded(child: ChoiceChip(label: const Text('يوتيوب / فيديو + SRT'), selected: _mode == 0, onSelected: (_) => setState(() => _mode = 0))),
              const SizedBox(width: 8),
              Expanded(child: ChoiceChip(label: const Text('درس / مفردات'), selected: _mode == 1, onSelected: (_) => setState(() => _mode = 1))),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: cefrMetaList.map((m) {
              final active = m.code == _level;
              return Expanded(
                child: GestureDetector(
                  onTap: () => setState(() => _level = m.code),
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 2),
                    padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(color: active ? AppColors.tealDark : AppColors.bgSoft, borderRadius: BorderRadius.circular(10)),
                    alignment: Alignment.center,
                    child: Text(m.code, style: TextStyle(color: active ? Colors.white : AppColors.tealDark, fontWeight: FontWeight.w700)),
                  ),
                ),
              );
            }).toList(),
          ),
          const SizedBox(height: 12),
          Container(
            padding: const EdgeInsets.all(14),
            decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(20)),
            child: _mode == 0
                ? Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _field(_titleCtrl, 'عنوان الفيديو (English)', ltr: true),
                      _field(_videoUrlCtrl, 'رابط YouTube أو MP4/WebM', ltr: true),
                      _field(_durCtrl, 'المدة بالثواني (مثال: 180)', ltr: true),
                      _field(_srtCtrl, 'ترجمة SRT/VTT (اختياري لليوتيوب)', lines: 4, ltr: true),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: AppColors.tealAccent, foregroundColor: AppColors.tealDark),
                        onPressed: _busy ? null : () => _parseAndTranslateVideo(fullDocument: true),
                        child: _busy
                            ? const SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2))
                            : const Text('ترجمة وتوليد lessons.json كامل', style: TextStyle(fontWeight: FontWeight.w700)),
                      ),
                      const SizedBox(height: 8),
                      OutlinedButton(
                        style: OutlinedButton.styleFrom(foregroundColor: Colors.white),
                        onPressed: _busy ? null : () => _parseAndTranslateVideo(fullDocument: false),
                        child: const Text('توليد عنصر الفيديو فقط {...}'),
                      ),
                      if (_parsedCues.isNotEmpty) ...[
                        const SizedBox(height: 8),
                        Text('الأسطر المتزامنة: ${_parsedCues.length}', style: const TextStyle(color: AppColors.tealAccent, fontSize: 12)),
                      ],
                    ],
                  )
                : Column(
                    crossAxisAlignment: CrossAxisAlignment.stretch,
                    children: [
                      _field(_wordCtrl, 'الكلمة الإنجليزية', ltr: true),
                      OutlinedButton.icon(
                        style: OutlinedButton.styleFrom(foregroundColor: AppColors.tealAccent),
                        onPressed: _busy ? null : _autoFillWord,
                        icon: const Icon(Icons.auto_fix_high_rounded, size: 18),
                        label: const Text('جلب النطق والترجمة والمثال تلقائياً'),
                      ),
                      const SizedBox(height: 10),
                      _field(_phoneticCtrl, 'النطق الصوتي (Phonetics)', ltr: true),
                      _field(_arWordCtrl, 'معنى الكلمة بالعربية'),
                      _field(_enSentCtrl, 'جملة المثال بالإنجليزية', ltr: true),
                      _field(_arSentCtrl, 'ترجمة جملة المثال بالعربية'),
                      ElevatedButton(
                        style: ElevatedButton.styleFrom(backgroundColor: AppColors.tealAccent, foregroundColor: AppColors.tealDark),
                        onPressed: () => _generateVocabJson(fullDocument: true),
                        child: const Text('توليد lessons.json كامل', style: TextStyle(fontWeight: FontWeight.w700)),
                      ),
                      const SizedBox(height: 8),
                      OutlinedButton(
                        style: OutlinedButton.styleFrom(foregroundColor: Colors.white),
                        onPressed: () => _generateVocabJson(fullDocument: false),
                        child: const Text('توليد عنصر الدرس فقط {...}'),
                      ),
                    ],
                  ),
          ),
          if (_generatedJson.isNotEmpty) ...[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(20)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  ElevatedButton.icon(
                    style: ElevatedButton.styleFrom(backgroundColor: AppColors.greenLight, foregroundColor: AppColors.greenText),
                    onPressed: _copyJson,
                    icon: const Icon(Icons.copy_rounded),
                    label: const Text('نسخ كود JSON بضغطة زر', style: TextStyle(fontWeight: FontWeight.w700)),
                  ),
                  const SizedBox(height: 10),
                  Directionality(
                    textDirection: TextDirection.ltr,
                    child: SelectableText(_generatedJson, style: const TextStyle(color: Colors.white70, fontSize: 11.5, fontFamily: 'monospace')),
                  ),
                ],
              ),
            ),
          ],
        ],
      ),
    );
  }
}