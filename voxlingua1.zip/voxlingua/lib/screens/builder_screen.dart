import 'dart:math';
import 'package:flutter/material.dart';
import '../data/fallback_data.dart';
import '../models/app_models.dart';
import '../services/api_service.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';

class BuilderScreen extends StatefulWidget {
  const BuilderScreen({super.key});
  @override
  State<BuilderScreen> createState() => _BuilderScreenState();
}

class _BuilderScreenState extends State<BuilderScreen> {
  String _level = 'A1';
  SentenceItem? _current;
  List<_WordTok> _bank = [];
  final List<_WordTok> _placed = [];
  bool _loading = true;
  String? _feedback;
  bool _isOk = false;
  int _solved = 0;

  @override
  void initState() {
    super.initState();
    _loadNext();
  }

  Future<void> _loadNext() async {
    setState(() { _loading = true; _feedback = null; _placed.clear(); });
    final item = await ApiService.instance.fetchUnlimitedSentence(preferredLevel: _level);
    final words = item.en.trim().split(RegExp(r'\s+'));
    final tokens = List.generate(words.length, (i) => _WordTok(i, words[i]))..shuffle(Random());
    if (mounted) setState(() { _current = item; _bank = tokens; _loading = false; });
  }

  void _check() {
    if (_current == null || _placed.isEmpty) return;
    SpeechService.instance.playTapClick();
    final lang = StorageService.instance.lang;
    final built = _placed.map((e) => e.word).join(' ');
    final ok = SpeechService.cleanText(built) == SpeechService.cleanText(_current!.en);

    if (ok) {
      setState(() { _isOk = true; _solved++; _feedback = AppStrings.get(lang, 'builderCorrect'); });
      SpeechService.instance.speakEnglish(_current!.en);
      StorageService.instance.markMasteredAndStreak(_current!.id, levelCode: _level);
      Future.delayed(const Duration(milliseconds: 2100), () { if (mounted) _loadNext(); });
    } else {
      setState(() { _isOk = false; _feedback = '${AppStrings.get(lang, 'builderWrong')} "${_current!.en}"'; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = StorageService.instance.lang;
    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(AppStrings.get(lang, 'builderTitle'), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(99)),
              child: Text('$_solved ✓', style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        Row(
          children: cefrMetaList.map((m) {
            final active = m.code == _level;
            return Expanded(
              child: GestureDetector(
                onTap: () { SpeechService.instance.playTapClick(); setState(() => _level = m.code); _loadNext(); },
                child: Container(
                  margin: const EdgeInsets.symmetric(horizontal: 3),
                  padding: const EdgeInsets.symmetric(vertical: 8),
                  decoration: BoxDecoration(color: active ? AppColors.tealDark : AppColors.bgSoft, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.tealDark.withValues(alpha: 0.18))),
                  alignment: Alignment.center,
                  child: Text(m.code, style: TextStyle(color: active ? Colors.white : AppColors.tealDark, fontWeight: FontWeight.w700)),
                ),
              ),
            );
          }).toList(),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(24)),
          child: _loading || _current == null
              ? const Center(child: Padding(padding: EdgeInsets.all(30), child: CircularProgressIndicator(color: AppColors.tealAccent)))
              : Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Text(AppStrings.get(lang, 'builderPrompt'), style: const TextStyle(color: AppColors.tealAccent, fontSize: 13)),
                    const SizedBox(height: 6),
                    Text(_current!.ar, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
                    const SizedBox(height: 14),
                    Container(
                      constraints: const BoxConstraints(minHeight: 70),
                      padding: const EdgeInsets.all(10),
                      decoration: BoxDecoration(color: AppColors.tealSub, borderRadius: BorderRadius.circular(18), border: Border.all(color: AppColors.tealAccent.withValues(alpha: 0.3))),
                      child: Directionality(
                        textDirection: TextDirection.ltr,
                        child: _placed.isEmpty
                            ? Center(child: Text(AppStrings.get(lang, 'tapWordsBelow'), style: const TextStyle(color: Colors.white54, fontSize: 13)))
                            : Wrap(
                                spacing: 7, runSpacing: 7,
                                children: _placed.map((tok) => GestureDetector(
                                  onTap: () { SpeechService.instance.playTapClick(); setState(() => _placed.remove(tok)); },
                                  child: Container(
                                    padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
                                    decoration: BoxDecoration(color: AppColors.tealAccent, borderRadius: BorderRadius.circular(12)),
                                    child: Text(tok.word, style: const TextStyle(color: AppColors.tealDark, fontWeight: FontWeight.w700)),
                                  ),
                                )).toList(),
                              ),
                      ),
                    ),
                    const SizedBox(height: 16),
                    Directionality(
                      textDirection: TextDirection.ltr,
                      child: Wrap(
                        alignment: WrapAlignment.center, spacing: 8, runSpacing: 8,
                        children: _bank.map((tok) {
                          final used = _placed.contains(tok);
                          return GestureDetector(
                            onTap: used ? null : () { SpeechService.instance.playTapClick(); setState(() => _placed.add(tok)); },
                            child: Opacity(
                              opacity: used ? 0.3 : 1,
                              child: Container(
                                padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 8),
                                decoration: BoxDecoration(color: Colors.white, borderRadius: BorderRadius.circular(12)),
                                child: Text(tok.word, style: const TextStyle(color: AppColors.tealDark, fontWeight: FontWeight.w700)),
                              ),
                            ),
                          );
                        }).toList(),
                      ),
                    ),
                    if (_feedback != null) ...[
                      const SizedBox(height: 14),
                      Container(
                        padding: const EdgeInsets.all(12),
                        decoration: BoxDecoration(color: _isOk ? AppColors.greenLight : AppColors.orangeSoft, borderRadius: BorderRadius.circular(14)),
                        child: Text(_feedback!, style: TextStyle(color: _isOk ? AppColors.greenText : AppColors.orangeText, fontWeight: FontWeight.w700)),
                      ),
                    ],
                    const SizedBox(height: 16),
                    Row(
                      children: [
                        Expanded(
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white, backgroundColor: AppColors.tealSub,
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            onPressed: () { SpeechService.instance.playTapClick(); setState(() { _placed.clear(); _feedback = null; }); },
                            child: FittedBox(fit: BoxFit.scaleDown, child: Text(AppStrings.get(lang, 'clear'), maxLines: 1, softWrap: false)),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          flex: 2,
                          child: ElevatedButton(
                            style: ElevatedButton.styleFrom(
                              backgroundColor: AppColors.tealAccent, foregroundColor: AppColors.tealDark,
                              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            onPressed: _check,
                            child: FittedBox(fit: BoxFit.scaleDown, child: Text(AppStrings.get(lang, 'check'), maxLines: 1, softWrap: false, style: const TextStyle(fontWeight: FontWeight.w700))),
                          ),
                        ),
                        const SizedBox(width: 8),
                        Expanded(
                          child: OutlinedButton(
                            style: OutlinedButton.styleFrom(
                              foregroundColor: Colors.white, backgroundColor: AppColors.tealSub,
                              padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 12),
                              shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
                            ),
                            onPressed: () { SpeechService.instance.playTapClick(); _loadNext(); },
                            child: FittedBox(fit: BoxFit.scaleDown, child: Text(AppStrings.get(lang, 'next'), maxLines: 1, softWrap: false)),
                          ),
                        ),
                      ],
                    ),
                  ],
                ),
        ),
      ],
    );
  }
}

class _WordTok {
  final int id;
  final String word;
  const _WordTok(this.id, this.word);
}