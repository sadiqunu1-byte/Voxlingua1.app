import 'package:flutter/material.dart';
import 'package:url_launcher/url_launcher.dart';
import '../data/fallback_data.dart';
import '../models/app_models.dart';
import '../services/api_service.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';
import '../widgets/word_sheet.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final List<SentenceItem> _history = List.from(fallbackDailySentences);
  int _index = DateTime.now().difference(DateTime(2024, 1, 1)).inDays % fallbackDailySentences.length;
  bool _playingWave = false;
  bool _recording = false;
  bool _loadingRandom = false;
  String _liveText = '';
  PronunciationEval? _eval;

  SentenceItem get _current => _history[_index];

  Future<void> _fetchUnlimitedNew() async {
    SpeechService.instance.playTapClick();
    setState(() { _loadingRandom = true; _eval = null; _liveText = ''; });
    final item = await ApiService.instance.fetchUnlimitedSentence();
    if (!mounted) return;
    setState(() {
      _history.add(item);
      _index = _history.length - 1;
      _loadingRandom = false;
    });
  }

  Future<void> _toggleRecord() async {
    if (_recording) {
      await SpeechService.instance.stopListening();
      if (mounted) setState(() => _recording = false);
      return;
    }

    setState(() { _recording = true; _liveText = ''; _eval = null; });
    final err = await SpeechService.instance.startListening(
      onLive: (txt) {
        if (mounted) setState(() => _liveText = txt);
      },
      onFinal: (finalTxt) {
        final ev = SpeechService.instance.evaluate(_current.en, finalTxt);
        if (ev.score >= 80) {
          StorageService.instance.markMasteredAndStreak(_current.id, levelCode: _current.level);
        }
        if (mounted) setState(() { _eval = ev; _recording = false; });
      },
      onStopped: () {
        if (mounted) setState(() => _recording = false);
      },
    );

    if (err != null && mounted) {
      setState(() => _recording = false);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(
          content: Text(AppStrings.get(StorageService.instance.lang, err)),
          backgroundColor: AppColors.tealDark,
        ),
      );
    }
  }

  Future<void> _openGoogleTranslate() async {
    SpeechService.instance.playTapClick();
    final url = Uri.parse(
      'https://translate.google.com/?sl=en&tl=ar&text=${Uri.encodeComponent(_current.en)}&op=translate',
    );
    await launchUrl(url, mode: LaunchMode.externalApplication);
  }

  void _openCustomTextDialog() {
    SpeechService.instance.playTapClick();
    final ctrl = TextEditingController();
    final lang = StorageService.instance.lang;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.tealDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(AppStrings.get(lang, 'practiceCustomTitle'),
            style: const TextStyle(color: Colors.white)),
        content: TextField(
          controller: ctrl,
          maxLines: 3,
          textDirection: TextDirection.ltr,
          style: const TextStyle(color: Colors.white),
          decoration: InputDecoration(
            filled: true,
            fillColor: AppColors.tealSub,
            hintText: 'Type or paste English text...',
            hintStyle: const TextStyle(color: Colors.white54),
            border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
          ),
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.tealAccent,
              foregroundColor: AppColors.tealDark,
            ),
            onPressed: () async {
              final text = ctrl.text.trim();
              if (text.isEmpty) return;
              Navigator.pop(ctx);
              final ar = await ApiService.instance.translateToArabic(text).catchError((_) => '');
              if (!mounted) return;
              setState(() {
                _history.add(SentenceItem(
                  id: 'cust_${DateTime.now().millisecondsSinceEpoch}',
                  level: 'Custom',
                  en: text,
                  ar: ar,
                ));
                _index = _history.length - 1;
                _eval = null;
                _liveText = '';
              });
            },
            child: Text(AppStrings.get(lang, 'startPractice')),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final store = StorageService.instance;
    final lang = store.lang;
    final mastered = store.masteredIds.contains(_current.id);

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(AppStrings.get(lang, 'sentenceOfTheDay'),
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
            if (mastered)
              Container(
                padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.greenLight,
                  borderRadius: BorderRadius.circular(99),
                ),
                child: Text(AppStrings.get(lang, 'masteredBadge'),
                    style: const TextStyle(color: AppColors.greenText, fontSize: 12, fontWeight: FontWeight.w700)),
              ),
          ],
        ),
        const SizedBox(height: 12),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.tealDark,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.stretch,
            children: [
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Container(
                    padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                    decoration: BoxDecoration(
                      color: AppColors.tealAccent,
                      borderRadius: BorderRadius.circular(99),
                    ),
                    child: Text(_current.level,
                        style: const TextStyle(color: AppColors.tealDark, fontWeight: FontWeight.w700, fontSize: 12)),
                  ),
                  Text(AppStrings.get(lang, 'tapWordHint'),
                      style: const TextStyle(color: AppColors.tealAccent, fontSize: 12)),
                ],
              ),
              const SizedBox(height: 12),
              if (_loadingRandom)
                const Padding(
                  padding: EdgeInsets.all(20),
                  child: Center(child: CircularProgressIndicator(color: AppColors.tealAccent)),
                )
              else ...[
                ClickableSentence(
                  text: _current.en,
                  style: const TextStyle(color: Colors.white, fontSize: 20, fontWeight: FontWeight.w600, height: 1.5),
                ),
                const SizedBox(height: 10),
                const Divider(color: Colors.white12),
                Text(_current.ar, style: const TextStyle(color: Colors.white70, fontSize: 15)),
              ],
              const SizedBox(height: 10),
              AnimatedWaveform(playing: _playingWave),
              const SizedBox(height: 10),
              Row(
                children: [
                  Expanded(
                    child: ElevatedButton.icon(
                      style: ElevatedButton.styleFrom(
                        backgroundColor: AppColors.tealAccent,
                        foregroundColor: AppColors.tealDark,
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        padding: const EdgeInsets.symmetric(vertical: 11),
                      ),
                      onPressed: () {
                        SpeechService.instance.playTapClick();
                        SpeechService.instance.speakEnglish(
                          _current.en,
                          onStart: () { if (mounted) setState(() => _playingWave = true); },
                          onDone: () { if (mounted) setState(() => _playingWave = false); },
                        );
                      },
                      icon: const Icon(Icons.volume_up_rounded, size: 18),
                      label: Text(AppStrings.get(lang, 'listen'), style: const TextStyle(fontWeight: FontWeight.w700)),
                    ),
                  ),
                  const SizedBox(width: 10),
                  Expanded(
                    child: OutlinedButton.icon(
                      style: OutlinedButton.styleFrom(
                        backgroundColor: AppColors.tealSub,
                        foregroundColor: Colors.white,
                        side: BorderSide(color: AppColors.tealAccent.withValues(alpha: 0.3)),
                        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                        padding: const EdgeInsets.symmetric(vertical: 11),
                      ),
                      onPressed: () {
                        SpeechService.instance.playTapClick();
                        SpeechService.instance.speakEnglish(
                          _current.en,
                          slow: true,
                          onStart: () { if (mounted) setState(() => _playingWave = true); },
                          onDone: () { if (mounted) setState(() => _playingWave = false); },
                        );
                      },
                      icon: const Icon(Icons.slow_motion_video_rounded, size: 18),
                      label: Text(AppStrings.get(lang, 'listenSlow'), style: const TextStyle(fontWeight: FontWeight.w700)),
                    ),
                  ),
                ],
              ),
            ],
          ),
        ),
        const SizedBox(height: 14),
        Container(
          padding: const EdgeInsets.all(18),
          decoration: BoxDecoration(
            color: AppColors.tealDark,
            borderRadius: BorderRadius.circular(24),
          ),
          child: Column(
            children: [
              Text(AppStrings.get(lang, 'shadowingPrompt'),
                  style: const TextStyle(color: Colors.white70, fontSize: 14)),
              const SizedBox(height: 14),
              GestureDetector(
                onTap: _toggleRecord,
                child: AnimatedContainer(
                  duration: const Duration(milliseconds: 220),
                  width: _recording ? 82 : 74,
                  height: _recording ? 82 : 74,
                  decoration: BoxDecoration(
                    shape: BoxShape.circle,
                    color: _recording ? AppColors.tealAccent : Colors.white,
                    boxShadow: _recording
                        ? [BoxShadow(color: AppColors.tealAccent.withValues(alpha: 0.55), blurRadius: 20, spreadRadius: 4)]
                        : const [BoxShadow(color: Colors.black26, blurRadius: 12)],
                  ),
                  child: const Icon(Icons.mic_rounded, size: 34, color: AppColors.tealDark),
                ),
              ),
              if (_liveText.isNotEmpty) ...[
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.tealSub,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(AppStrings.get(lang, 'youSaid'),
                          style: const TextStyle(color: AppColors.tealAccent, fontSize: 12)),
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Text(_liveText, style: const TextStyle(color: Colors.white, fontSize: 15)),
                      ),
                    ],
                  ),
                ),
              ],
              if (_eval != null) ...[
                const SizedBox(height: 12),
                Container(
                  width: double.infinity,
                  padding: const EdgeInsets.all(12),
                  decoration: BoxDecoration(
                    color: AppColors.tealSub,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        children: [
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                            decoration: BoxDecoration(
                              color: AppColors.tealAccent,
                              borderRadius: BorderRadius.circular(99),
                            ),
                            child: Text('${_eval!.score}%',
                                style: const TextStyle(color: AppColors.tealDark, fontWeight: FontWeight.w700)),
                          ),
                          const SizedBox(width: 10),
                          Expanded(
                            child: Text(
                              _eval!.score >= 80
                                  ? AppStrings.get(lang, 'greatScore')
                                  : (_eval!.score >= 55
                                      ? AppStrings.get(lang, 'goodScore')
                                      : AppStrings.get(lang, 'tryAgainScore')),
                              style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600, fontSize: 13),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 10),
                      Directionality(
                        textDirection: TextDirection.ltr,
                        child: Wrap(
                          spacing: 6,
                          runSpacing: 6,
                          children: _eval!.words.map((wf) {
                            return Container(
                              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
                              decoration: BoxDecoration(
                                color: wf.isCorrect ? AppColors.greenLight : AppColors.orangeSoft,
                                borderRadius: BorderRadius.circular(10),
                              ),
                              child: Text(
                                wf.text,
                                style: TextStyle(
                                  color: wf.isCorrect ? AppColors.greenText : AppColors.orangeText,
                                  fontWeight: FontWeight.w700,
                                ),
                              ),
                            );
                          }).toList(),
                        ),
                      ),
                    ],
                  ),
                ),
              ],
            ],
          ),
        ),
        const SizedBox(height: 12),
        Row(
          children: [
            Expanded(
              child: _NavChip(
                label: AppStrings.get(lang, 'prev'),
                onTap: () {
                  SpeechService.instance.playTapClick();
                  setState(() {
                    _index = (_index - 1 + _history.length) % _history.length;
                    _eval = null;
                    _liveText = '';
                  });
                },
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _NavChip(
                label: AppStrings.get(lang, 'next'),
                onTap: () {
                  SpeechService.instance.playTapClick();
                  if (_index < _history.length - 1) {
                    setState(() { _index++; _eval = null; _liveText = ''; });
                  } else {
                    _fetchUnlimitedNew();
                  }
                },
              ),
            ),
          ],
        ),
        const SizedBox(height: 8),
        Row(
          children: [
            Expanded(
              child: _NavChip(
                label: '🎲 ${AppStrings.get(lang, 'random')}',
                onTap: _fetchUnlimitedNew,
              ),
            ),
            const SizedBox(width: 8),
            Expanded(
              child: _NavChip(
                label: '🌐 ${AppStrings.get(lang, 'googleTranslate')}',
                onTap: _openGoogleTranslate,
              ),
            ),
          ],
        ),
        const SizedBox(height: 10),
        ElevatedButton.icon(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.tealDark,
            foregroundColor: Colors.white,
            padding: const EdgeInsets.symmetric(vertical: 14),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
          ),
          onPressed: _openCustomTextDialog,
          icon: const Icon(Icons.edit_note_rounded),
          label: Text(AppStrings.get(lang, 'practiceCustom'), style: const TextStyle(fontWeight: FontWeight.w700)),
        ),
      ],
    );
  }
}

class _NavChip extends StatelessWidget {
  final String label;
  final VoidCallback onTap;
  const _NavChip({required this.label, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return OutlinedButton(
      style: OutlinedButton.styleFrom(
        backgroundColor: AppColors.bgSoft,
        foregroundColor: AppColors.tealDark,
        side: BorderSide(color: AppColors.tealDark.withValues(alpha: 0.16)),
        padding: const EdgeInsets.symmetric(vertical: 11, horizontal: 8),
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
      ),
      onPressed: onTap,
      child: Text(label, textAlign: TextAlign.center, style: const TextStyle(fontWeight: FontWeight.w600, fontSize: 13)),
    );
  }
}