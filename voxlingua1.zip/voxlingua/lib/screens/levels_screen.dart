import 'package:flutter/material.dart';
import '../data/fallback_data.dart';
import '../models/app_models.dart';
import '../services/api_service.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';
import '../widgets/word_sheet.dart';

class LevelsScreen extends StatefulWidget {
  const LevelsScreen({super.key});

  @override
  State<LevelsScreen> createState() => _LevelsScreenState();
}

class _LevelsScreenState extends State<LevelsScreen> {
  String? _openLevel;
  int _page = 0;
  bool _loading = false;
  final List<LevelVocabItem> _items = [];

  Future<void> _open(String code) async {
    SpeechService.instance.playTapClick();
    setState(() { _openLevel = code; _page = 0; _items.clear(); });
    await _loadMore();
  }

  Future<void> _loadMore() async {
    if (_openLevel == null) return;
    setState(() => _loading = true);
    final list = await ApiService.instance.fetchDynamicLevelItems(_openLevel!, _page++);
    if (mounted) setState(() { _items.addAll(list); _loading = false; });
  }

  @override
  Widget build(BuildContext context) {
    final store = StorageService.instance;
    final lang = store.lang;

    if (_openLevel == null) {
      return ListView(
        padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
        children: [
          Text(AppStrings.get(lang, 'levelsTitle'),
              style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
          const SizedBox(height: 12),
          GridView.builder(
            shrinkWrap: true,
            physics: const NeverScrollableScrollPhysics(),
            itemCount: cefrMetaList.length,
            gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
              crossAxisCount: 2,
              mainAxisSpacing: 10,
              crossAxisSpacing: 10,
              childAspectRatio: 1.12,
            ),
            itemBuilder: (_, i) {
              final m = cefrMetaList[i];
              final count = store.masteredByLevel[m.code] ?? 0;
              return GestureDetector(
                onTap: () => _open(m.code),
                child: Container(
                  padding: const EdgeInsets.all(14),
                  decoration: BoxDecoration(
                    color: AppColors.tealDark,
                    borderRadius: BorderRadius.circular(24),
                  ),
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Row(
                        mainAxisAlignment: MainAxisAlignment.spaceBetween,
                        children: [
                          Text(m.code,
                              style: const TextStyle(color: AppColors.tealAccent, fontSize: 22, fontWeight: FontWeight.w700)),
                          Container(
                            padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 3),
                            decoration: BoxDecoration(color: AppColors.tealSub, borderRadius: BorderRadius.circular(99)),
                            child: Text('$count ${AppStrings.get(lang, 'masteredLabel')}',
                                style: const TextStyle(color: Colors.white, fontSize: 11)),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Expanded(
                        child: Text(
                          lang == 'ar' ? m.descAr : m.descEn,
                          style: const TextStyle(color: Colors.white70, fontSize: 12.5),
                        ),
                      ),
                    ],
                  ),
                ),
              );
            },
          ),
        ],
      );
    }

    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: [
              OutlinedButton.icon(
                onPressed: () {
                  SpeechService.instance.playTapClick();
                  setState(() => _openLevel = null);
                },
                icon: const Icon(Icons.arrow_back_rounded, size: 18),
                label: Text(AppStrings.get(lang, 'back')),
              ),
              Text('$_openLevel • ${AppStrings.get(lang, 'levelsTitle')}',
                  style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700)),
            ],
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 4, 16, 20),
            itemCount: _items.length + 1,
            itemBuilder: (_, i) {
              if (i == _items.length) {
                return Padding(
                  padding: const EdgeInsets.only(top: 6),
                  child: ElevatedButton(
                    style: ElevatedButton.styleFrom(
                      backgroundColor: AppColors.tealDark,
                      foregroundColor: Colors.white,
                      padding: const EdgeInsets.symmetric(vertical: 14),
                      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(18)),
                    ),
                    onPressed: _loading ? null : () {
                      SpeechService.instance.playTapClick();
                      _loadMore();
                    },
                    child: _loading
                        ? const SizedBox(height: 20, width: 20, child: CircularProgressIndicator(color: AppColors.tealAccent))
                        : Text(AppStrings.get(lang, 'loadMore'), style: const TextStyle(fontWeight: FontWeight.w700)),
                  ),
                );
              }
              final item = _items[i];
              return Container(
                margin: const EdgeInsets.only(bottom: 10),
                padding: const EdgeInsets.all(14),
                decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(20)),
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.stretch,
                  children: [
                    Row(
                      mainAxisAlignment: MainAxisAlignment.spaceBetween,
                      children: [
                        Expanded(
                          child: Directionality(
                            textDirection: TextDirection.ltr,
                            child: Text('${item.word}  ${item.phonetic}',
                                style: const TextStyle(color: AppColors.tealAccent, fontSize: 17, fontWeight: FontWeight.w700)),
                          ),
                        ),
                        IconButton(
                          onPressed: () {
                            SpeechService.instance.playTapClick();
                            SpeechService.instance.speakEnglish('${item.word}. ${item.en}');
                          },
                          icon: const Icon(Icons.volume_up_rounded, color: AppColors.tealAccent),
                        ),
                      ],
                    ),
                    Text(item.ar, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                    const SizedBox(height: 6),
                    ClickableSentence(
                      text: item.en,
                      style: const TextStyle(color: Colors.white, fontSize: 14),
                    ),
                    const SizedBox(height: 4),
                    Text(item.enAr, style: const TextStyle(color: Colors.white70, fontSize: 13)),
                  ],
                ),
              );
            },
          ),
        ),
      ],
    );
  }
}