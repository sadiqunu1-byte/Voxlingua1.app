import 'package:flutter/material.dart';
import '../data/fallback_data.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';

class MyWordsScreen extends StatelessWidget {
  const MyWordsScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final store = StorageService.instance;
    final lang = store.lang;

    return ListView(
      padding: const EdgeInsets.fromLTRB(16, 12, 16, 24),
      children: [
        Row(
          mainAxisAlignment: MainAxisAlignment.spaceBetween,
          children: [
            Text(AppStrings.get(lang, 'myWordsTitle'),
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
            Container(
              padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
              decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(99)),
              child: Text('${store.savedWords.length}',
                  style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700)),
            ),
          ],
        ),
        const SizedBox(height: 12),
        if (store.savedWords.isEmpty)
          Container(
            padding: const EdgeInsets.all(18),
            decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(24)),
            child: Text(AppStrings.get(lang, 'noSavedWords'),
                style: const TextStyle(color: Colors.white, fontSize: 15)),
          )
        else
          ...List.generate(store.savedWords.length, (i) {
            final w = store.savedWords[i];
            return Container(
              margin: const EdgeInsets.only(bottom: 10),
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(20)),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.stretch,
                children: [
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Expanded(
                        child: Directionality(
                          textDirection: TextDirection.ltr,
                          child: Text('${w.word}  ${w.phonetic}',
                              style: const TextStyle(color: AppColors.tealAccent, fontSize: 17, fontWeight: FontWeight.w700)),
                        ),
                      ),
                      Row(
                        children: [
                          IconButton(
                            onPressed: () {
                              SpeechService.instance.playTapClick();
                              SpeechService.instance.speakEnglish(w.word);
                            },
                            icon: const Icon(Icons.volume_up_rounded, color: AppColors.tealAccent),
                          ),
                          IconButton(
                            onPressed: () {
                              SpeechService.instance.playTapClick();
                              store.deleteWord(i);
                            },
                            icon: const Icon(Icons.delete_outline_rounded, color: AppColors.orangeSoft),
                          ),
                        ],
                      ),
                    ],
                  ),
                  Text(w.arabic, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 15)),
                  const SizedBox(height: 4),
                  Directionality(
                    textDirection: TextDirection.ltr,
                    child: Text(w.example, style: const TextStyle(color: Colors.white70, fontSize: 13.5)),
                  ),
                ],
              ),
            );
          }),
      ],
    );
  }
}