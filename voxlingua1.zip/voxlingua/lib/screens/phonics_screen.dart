// lib/screens/phonics_screen.dart
// Voxlingua - قسم "التأسيس ومزج الكلمات" (Phonics & Blending)
//
// ثلاثة أقسام داخل الشاشة:
//   1) الحروف: الكبير والصغير مع صوت الحرف (وليس اسمه فقط) وكلمة مثال.
//   2) المزج: كلمات CVC؛ اضغطي كل حرف لسماع صوته ثم زر "مزج" لسماع الكلمة وترجمتها.
//   3) اختبار: اسمعي الصوت واختاري الحرف الصحيح.
//
// النطق يتم عبر SpeechService (الذي يغلّف flutter_tts) حتى لا يُنشأ كائن
// FlutterTts ثانٍ يتعارض مع مستمعات الإكمال في الخدمة الحالية.

import 'dart:async';
import 'dart:math';

import 'package:flutter/material.dart';

import '../services/speech_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';
import '../widgets/word_sheet.dart' show AnimatedWaveform;

// -----------------------------------------------------------------------------
// البيانات
// -----------------------------------------------------------------------------

/// حرف إنجليزي مع صوته.
/// [sound] هو النص الذي يقرؤه flutter_tts ليُنتج صوت الحرف (وليس اسمه):
/// مثلاً "buh" بدل "bee". يمكنك تعديل أي قيمة هنا إن أردت صوتاً أقرب على جهازك.
class PhonicsLetter {
  final String upper;
  final String lower;
  final String sound;
  final String ipa;
  final String word;
  final String emoji;
  final String ar;
  final bool vowel;

  const PhonicsLetter(
    this.upper,
    this.lower,
    this.sound,
    this.ipa,
    this.word,
    this.emoji,
    this.ar, {
    this.vowel = false,
  });
}

const List<PhonicsLetter> kPhonicsLetters = <PhonicsLetter>[
  PhonicsLetter('A', 'a', 'ah', '/æ/', 'apple', '🍎', 'تفاحة', vowel: true),
  PhonicsLetter('B', 'b', 'buh', '/b/', 'ball', '⚽', 'كرة'),
  PhonicsLetter('C', 'c', 'kuh', '/k/', 'cat', '🐱', 'قطة'),
  PhonicsLetter('D', 'd', 'duh', '/d/', 'dog', '🐶', 'كلب'),
  PhonicsLetter('E', 'e', 'eh', '/ɛ/', 'egg', '🥚', 'بيضة', vowel: true),
  PhonicsLetter('F', 'f', 'fuh', '/f/', 'fish', '🐟', 'سمكة'),
  PhonicsLetter('G', 'g', 'guh', '/g/', 'goat', '🐐', 'ماعز'),
  PhonicsLetter('H', 'h', 'huh', '/h/', 'hat', '🎩', 'قبعة'),
  PhonicsLetter('I', 'i', 'ih', '/ɪ/', 'insect', '🐛', 'حشرة', vowel: true),
  PhonicsLetter('J', 'j', 'juh', '/dʒ/', 'jet', '✈️', 'طائرة'),
  PhonicsLetter('K', 'k', 'kuh', '/k/', 'key', '🔑', 'مفتاح'),
  PhonicsLetter('L', 'l', 'luh', '/l/', 'lion', '🦁', 'أسد'),
  PhonicsLetter('M', 'm', 'muh', '/m/', 'moon', '🌙', 'قمر'),
  PhonicsLetter('N', 'n', 'nuh', '/n/', 'nose', '👃', 'أنف'),
  PhonicsLetter('O', 'o', 'aw', '/ɒ/', 'octopus', '🐙', 'أخطبوط', vowel: true),
  PhonicsLetter('P', 'p', 'puh', '/p/', 'pen', '🖊️', 'قلم'),
  PhonicsLetter('Q', 'q', 'kwuh', '/kw/', 'queen', '👑', 'ملكة'),
  PhonicsLetter('R', 'r', 'ruh', '/r/', 'rabbit', '🐰', 'أرنب'),
  PhonicsLetter('S', 's', 'suh', '/s/', 'sun', '☀️', 'شمس'),
  PhonicsLetter('T', 't', 'tuh', '/t/', 'tiger', '🐯', 'نمر'),
  PhonicsLetter('U', 'u', 'uh', '/ʌ/', 'umbrella', '☂️', 'مظلة', vowel: true),
  PhonicsLetter('V', 'v', 'vuh', '/v/', 'van', '🚐', 'شاحنة صغيرة'),
  PhonicsLetter('W', 'w', 'wuh', '/w/', 'water', '💧', 'ماء'),
  PhonicsLetter('X', 'x', 'ksuh', '/ks/', 'box', '📦', 'صندوق'),
  PhonicsLetter('Y', 'y', 'yuh', '/j/', 'yellow', '💛', 'أصفر'),
  PhonicsLetter('Z', 'z', 'zuh', '/z/', 'zebra', '🦓', 'حمار وحشي'),
];

final Map<String, PhonicsLetter> _letterByChar = <String, PhonicsLetter>{
  for (final PhonicsLetter l in kPhonicsLetters) l.lower: l,
};

PhonicsLetter _letterFor(String ch) =>
    _letterByChar[ch.toLowerCase()] ?? kPhonicsLetters.first;

/// كلمة قصيرة من نوع CVC (حرف ساكن + علة + ساكن) مع ترجمتها.
class CvcWord {
  final String word;
  final String ar;
  const CvcWord(this.word, this.ar);
}

const List<CvcWord> kCvcWords = <CvcWord>[
  CvcWord('cat', 'قطة'),
  CvcWord('pen', 'قلم'),
  CvcWord('dog', 'كلب'),
  CvcWord('sun', 'شمس'),
  CvcWord('hat', 'قبعة'),
  CvcWord('bed', 'سرير'),
  CvcWord('pig', 'خنزير'),
  CvcWord('cup', 'كوب'),
  CvcWord('bus', 'حافلة'),
  CvcWord('map', 'خريطة'),
  CvcWord('net', 'شبكة'),
  CvcWord('pin', 'دبوس'),
  CvcWord('hen', 'دجاجة'),
  CvcWord('jet', 'طائرة نفاثة'),
  CvcWord('fan', 'مروحة'),
  CvcWord('leg', 'ساق'),
  CvcWord('lip', 'شفة'),
  CvcWord('mug', 'كوب كبير'),
  CvcWord('nut', 'جوزة'),
  CvcWord('pot', 'قِدر'),
  CvcWord('rat', 'جرذ'),
  CvcWord('red', 'أحمر'),
  CvcWord('sit', 'يجلس'),
  CvcWord('top', 'قمة'),
  CvcWord('van', 'شاحنة صغيرة'),
  CvcWord('web', 'نسيج العنكبوت'),
  CvcWord('yes', 'نعم'),
  CvcWord('zip', 'سحّاب'),
  CvcWord('bag', 'حقيبة'),
  CvcWord('run', 'يركض'),
  CvcWord('big', 'كبير'),
  CvcWord('hot', 'ساخن'),
  CvcWord('wet', 'مبلل'),
  CvcWord('kid', 'طفل'),
  CvcWord('gum', 'علكة'),
  CvcWord('log', 'جذع شجرة'),
];

const int kQuizLength = 10;

String _t(bool ar, String a, String e) => ar ? a : e;

// -----------------------------------------------------------------------------
// أداة مشتركة لتشغيل تسلسلات صوتية قابلة للإلغاء
// -----------------------------------------------------------------------------
mixin _AudioRunner<T extends StatefulWidget> on State<T> {
  int _run = 0;
  bool busy = false;

  /// يشغّل [body]. أي تسلسل جديد (أو cancelAudio) يجعل السابق "ملغى"،
  /// فيتوقف عند أول فحص لـ cancelled().
  Future<void> runAudio(
    Future<void> Function(bool Function() cancelled) body,
  ) async {
    final int run = ++_run;
    if (mounted) setState(() => busy = true);
    try {
      await body(() => run != _run || !mounted);
    } catch (_) {
      // أخطاء النطق لا يجب أن توقف الشاشة.
    } finally {
      if (mounted && run == _run) setState(() => busy = false);
    }
  }

  /// ينطق [text] وينتظر انتهاءه (مع مهلة أمان حتى لا يعلق التسلسل).
  Future<void> say(String text, {bool slow = false}) async {
    try {
      await SpeechService.instance
          .speakEnglish(text, slow: slow)
          .timeout(const Duration(seconds: 10), onTimeout: () {});
    } catch (_) {}
  }

  Future<void> pause(int ms) => Future<void>.delayed(Duration(milliseconds: ms));

  /// يلغي التسلسل الحالي ويوقف الصوت (لا يستدعي setState).
  void cancelAudio() {
    _run++;
    busy = false;
    unawaited(SpeechService.instance.stopSpeaking());
  }
}

// -----------------------------------------------------------------------------
// الشاشة الرئيسية
// -----------------------------------------------------------------------------
class PhonicsScreen extends StatefulWidget {
  const PhonicsScreen({super.key});

  @override
  State<PhonicsScreen> createState() => _PhonicsScreenState();
}

class _PhonicsScreenState extends State<PhonicsScreen> {
  int _section = 0;

  void _select(int i) {
    if (i == _section) return;
    SpeechService.instance.playTapClick();
    unawaited(SpeechService.instance.stopSpeaking());
    setState(() => _section = i);
  }

  @override
  Widget build(BuildContext context) {
    // AnimatedBuilder حتى تتحدّث اللغة فوراً عند تغييرها من الإعدادات.
    return AnimatedBuilder(
      animation: StorageService.instance,
      builder: (BuildContext context, Widget? _) {
        final bool ar = StorageService.instance.lang == 'ar';
        final List<String> tabs = <String>[
          _t(ar, 'الحروف', 'Letters'),
          _t(ar, 'المزج', 'Blending'),
          _t(ar, 'اختبار', 'Quiz'),
        ];

        final Widget body;
        switch (_section) {
          case 0:
            body = _LettersSection(ar: ar);
            break;
          case 1:
            body = _BlendSection(ar: ar);
            break;
          default:
            body = _QuizSection(ar: ar);
        }

        return Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: <Widget>[
            Padding(
              padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
              child: Text(
                _t(ar, 'التأسيس ومزج الكلمات', 'Phonics & Blending'),
                style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700),
              ),
            ),
            Padding(
              padding: const EdgeInsets.fromLTRB(13, 0, 13, 8),
              child: Row(
                children: <Widget>[
                  for (int i = 0; i < tabs.length; i++)
                    Expanded(
                      child: GestureDetector(
                        onTap: () => _select(i),
                        child: Container(
                          margin: const EdgeInsets.symmetric(horizontal: 3),
                          padding: const EdgeInsets.symmetric(vertical: 9),
                          alignment: Alignment.center,
                          decoration: BoxDecoration(
                            color: i == _section
                                ? AppColors.tealDark
                                : AppColors.bgSoft,
                            borderRadius: BorderRadius.circular(12),
                            border: Border.all(
                              color: AppColors.tealDark.withValues(alpha: 0.18),
                            ),
                          ),
                          child: Text(
                            tabs[i],
                            style: TextStyle(
                              color: i == _section
                                  ? Colors.white
                                  : AppColors.tealDark,
                              fontWeight: FontWeight.w700,
                            ),
                          ),
                        ),
                      ),
                    ),
                ],
              ),
            ),
            Expanded(child: body),
          ],
        );
      },
    );
  }
}

// -----------------------------------------------------------------------------
// 1) قسم الحروف
// -----------------------------------------------------------------------------
class _LettersSection extends StatefulWidget {
  final bool ar;
  const _LettersSection({required this.ar});

  @override
  State<_LettersSection> createState() => _LettersSectionState();
}

class _LettersSectionState extends State<_LettersSection>
    with _AudioRunner<_LettersSection> {
  int _selected = 0;

  @override
  void dispose() {
    cancelAudio();
    super.dispose();
  }

  Future<void> _selectAndPlay(int i) async {
    SpeechService.instance.playTapClick();
    setState(() => _selected = i);
    await _playSoundThenWord();
  }

  Future<void> _playSound() {
    SpeechService.instance.playTapClick();
    return runAudio((bool Function() cancelled) async {
      await say(kPhonicsLetters[_selected].sound, slow: true);
    });
  }

  Future<void> _playWord() {
    SpeechService.instance.playTapClick();
    return runAudio((bool Function() cancelled) async {
      await say(kPhonicsLetters[_selected].word, slow: true);
    });
  }

  Future<void> _playSoundThenWord() {
    return runAudio((bool Function() cancelled) async {
      final PhonicsLetter l = kPhonicsLetters[_selected];
      await say(l.sound, slow: true);
      if (cancelled()) return;
      await pause(350);
      if (cancelled()) return;
      await say(l.word);
    });
  }

  Widget _actionBtn(IconData icon, String label, VoidCallback onTap) {
    return Expanded(
      child: Padding(
        padding: const EdgeInsets.symmetric(horizontal: 3),
        child: ElevatedButton(
          style: ElevatedButton.styleFrom(
            backgroundColor: AppColors.tealAccent,
            foregroundColor: AppColors.tealDark,
            padding: const EdgeInsets.symmetric(horizontal: 6, vertical: 11),
            shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
          ),
          onPressed: onTap,
          child: FittedBox(
            fit: BoxFit.scaleDown,
            child: Row(
              mainAxisSize: MainAxisSize.min,
              children: <Widget>[
                Icon(icon, size: 18),
                const SizedBox(width: 4),
                Text(
                  label,
                  style: const TextStyle(fontSize: 12, fontWeight: FontWeight.w700),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _detailCard(bool ar, PhonicsLetter cur) {
    final Color letterColor =
        cur.vowel ? AppColors.orangeSoft : AppColors.tealAccent;
    return Container(
      padding: const EdgeInsets.all(14),
      decoration: BoxDecoration(
        color: AppColors.tealDark,
        borderRadius: BorderRadius.circular(22),
      ),
      child: Directionality(
        textDirection: TextDirection.ltr,
        child: Column(
          children: <Widget>[
            Row(
              children: <Widget>[
                Container(
                  width: 112,
                  height: 96,
                  alignment: Alignment.center,
                  decoration: BoxDecoration(
                    color: AppColors.tealSub,
                    borderRadius: BorderRadius.circular(18),
                  ),
                  child: FittedBox(
                    fit: BoxFit.scaleDown,
                    child: Padding(
                      padding: const EdgeInsets.symmetric(horizontal: 8),
                      child: Text(
                        '${cur.upper}${cur.lower}',
                        style: TextStyle(
                          color: letterColor,
                          fontSize: 50,
                          fontWeight: FontWeight.w800,
                        ),
                      ),
                    ),
                  ),
                ),
                const SizedBox(width: 14),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: <Widget>[
                      Row(
                        children: <Widget>[
                          Container(
                            padding: const EdgeInsets.symmetric(
                                horizontal: 10, vertical: 3),
                            decoration: BoxDecoration(
                              color: AppColors.tealAccent,
                              borderRadius: BorderRadius.circular(99),
                            ),
                            child: Text(
                              cur.ipa,
                              style: const TextStyle(
                                color: AppColors.tealDark,
                                fontWeight: FontWeight.w800,
                                fontSize: 15,
                              ),
                            ),
                          ),
                          const SizedBox(width: 8),
                          Flexible(
                            child: Text(
                              _t(ar, 'صوت الحرف', 'letter sound'),
                              maxLines: 1,
                              overflow: TextOverflow.ellipsis,
                              style: const TextStyle(
                                  color: Colors.white70, fontSize: 12),
                            ),
                          ),
                        ],
                      ),
                      const SizedBox(height: 8),
                      Text(
                        '${cur.emoji}  ${cur.word}',
                        maxLines: 1,
                        overflow: TextOverflow.ellipsis,
                        style: const TextStyle(
                          color: Colors.white,
                          fontSize: 20,
                          fontWeight: FontWeight.w700,
                        ),
                      ),
                      Directionality(
                        textDirection: TextDirection.rtl,
                        child: Text(
                          cur.ar,
                          style: const TextStyle(
                              color: AppColors.tealAccent, fontSize: 15),
                        ),
                      ),
                      AnimatedWaveform(playing: busy),
                    ],
                  ),
                ),
              ],
            ),
            const SizedBox(height: 12),
            Row(
              children: <Widget>[
                _actionBtn(Icons.volume_up_rounded, _t(ar, 'الصوت', 'Sound'),
                    _playSound),
                _actionBtn(Icons.menu_book_rounded, _t(ar, 'الكلمة', 'Word'),
                    _playWord),
                _actionBtn(
                    Icons.play_arrow_rounded,
                    _t(ar, 'الصوت + الكلمة', 'Sound + Word'),
                    () {
                  SpeechService.instance.playTapClick();
                  _playSoundThenWord();
                }),
              ],
            ),
          ],
        ),
      ),
    );
  }

  Widget _legendDot(Color c, String label) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: <Widget>[
        Container(
          width: 12,
          height: 12,
          decoration: BoxDecoration(color: c, shape: BoxShape.circle),
        ),
        const SizedBox(width: 5),
        Text(label, style: const TextStyle(fontSize: 12, color: AppColors.tealSub)),
      ],
    );
  }

  Widget _letterCard(int i) {
    final PhonicsLetter l = kPhonicsLetters[i];
    final bool sel = i == _selected;
    return GestureDetector(
      onTap: () => _selectAndPlay(i),
      child: AnimatedContainer(
        duration: const Duration(milliseconds: 160),
        alignment: Alignment.center,
        decoration: BoxDecoration(
          color: l.vowel
              ? AppColors.orangeSoft
              : (sel ? AppColors.tealSub : AppColors.tealDark),
          borderRadius: BorderRadius.circular(16),
          border: Border.all(
            color: sel
                ? (l.vowel ? AppColors.orangeText : AppColors.tealAccent)
                : Colors.transparent,
            width: 2.5,
          ),
        ),
        child: FittedBox(
          fit: BoxFit.scaleDown,
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: <Widget>[
              Text(
                '${l.upper}${l.lower}',
                style: TextStyle(
                  fontSize: 24,
                  fontWeight: FontWeight.w800,
                  color: l.vowel ? AppColors.orangeText : Colors.white,
                ),
              ),
              Text(
                l.ipa,
                style: TextStyle(
                  fontSize: 11,
                  color: l.vowel ? AppColors.orangeText : AppColors.tealAccent,
                ),
              ),
            ],
          ),
        ),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool ar = widget.ar;
    final PhonicsLetter cur = kPhonicsLetters[_selected];
    // الاتجاه LTR دائماً ليبقى ترتيب الأبجدية A → Z من اليسار حتى في الواجهة العربية.
    // وكل المحتوى داخل CustomScrollView فلا يحدث overflow على الشاشات الصغيرة.
    return Directionality(
      textDirection: TextDirection.ltr,
      child: CustomScrollView(
        slivers: <Widget>[
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 4, 16, 6),
              child: _detailCard(ar, cur),
            ),
          ),
          SliverToBoxAdapter(
            child: Padding(
              padding: const EdgeInsets.fromLTRB(16, 0, 16, 4),
              child: Wrap(
                alignment: WrapAlignment.center,
                spacing: 16,
                runSpacing: 4,
                children: <Widget>[
                  _legendDot(AppColors.orangeSoft,
                      _t(ar, 'حروف العلة (Vowels)', 'Vowels')),
                  _legendDot(AppColors.tealDark,
                      _t(ar, 'حروف ساكنة (Consonants)', 'Consonants')),
                ],
              ),
            ),
          ),
          SliverPadding(
            padding: const EdgeInsets.fromLTRB(16, 6, 16, 16),
            sliver: SliverGrid(
              gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                crossAxisCount: 4,
                mainAxisSpacing: 8,
                crossAxisSpacing: 8,
                childAspectRatio: 0.95,
              ),
              delegate: SliverChildBuilderDelegate(
                (BuildContext context, int i) => _letterCard(i),
                childCount: kPhonicsLetters.length,
              ),
            ),
          ),
        ],
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// 2) قسم المزج (CVC)
// -----------------------------------------------------------------------------
class _BlendSection extends StatefulWidget {
  final bool ar;
  const _BlendSection({required this.ar});

  @override
  State<_BlendSection> createState() => _BlendSectionState();
}

class _BlendSectionState extends State<_BlendSection>
    with _AudioRunner<_BlendSection> {
  final Random _rng = Random();
  late CvcWord _current;
  int _lastIndex = -1;
  int _active = -1;
  bool _revealed = false;
  bool _credited = false;

  @override
  void initState() {
    super.initState();
    _current = _randomWord();
  }

  @override
  void dispose() {
    cancelAudio();
    super.dispose();
  }

  CvcWord _randomWord() {
    int i;
    do {
      i = _rng.nextInt(kCvcWords.length);
    } while (i == _lastIndex && kCvcWords.length > 1);
    _lastIndex = i;
    return kCvcWords[i];
  }

  void _nextWord() {
    SpeechService.instance.playTapClick();
    cancelAudio();
    setState(() {
      _current = _randomWord();
      _active = -1;
      _revealed = false;
    });
  }

  Future<void> _tapLetter(int i) {
    SpeechService.instance.playTapClick();
    final PhonicsLetter l = _letterFor(_current.word[i]);
    return runAudio((bool Function() cancelled) async {
      setState(() => _active = i);
      await say(l.sound, slow: true);
      if (cancelled()) return;
      setState(() => _active = -1);
    });
  }

  Future<void> _blend() {
    SpeechService.instance.playTapClick();
    final String w = _current.word;
    return runAudio((bool Function() cancelled) async {
      setState(() => _revealed = false);
      for (int i = 0; i < w.length; i++) {
        if (cancelled()) return;
        setState(() => _active = i);
        await say(_letterFor(w[i]).sound, slow: true);
        if (cancelled()) return;
        await pause(180);
      }
      if (cancelled()) return;
      setState(() => _active = -1);
      await say(w, slow: true);
      if (cancelled()) return;
      setState(() => _revealed = true);
      await pause(250);
      if (cancelled()) return;
      await say(w);
      if (!_credited) {
        _credited = true;
        // يحتسب يوم التدريب في سلسلة الأيام (streak) دون إضافة عنصر "متقن".
        unawaited(StorageService.instance.markMasteredAndStreak(''));
      }
    });
  }

  Future<void> _hearWord() {
    SpeechService.instance.playTapClick();
    final String w = _current.word;
    return runAudio((bool Function() cancelled) async {
      await say(w);
    });
  }

  Widget _tile(int i, String ch) {
    final PhonicsLetter l = _letterFor(ch);
    final bool active = _active == i;
    final Color bg = active
        ? AppColors.tealAccent
        : (l.vowel ? AppColors.orangeSoft : AppColors.tealDark);
    final Color fg = active
        ? AppColors.tealDark
        : (l.vowel ? AppColors.orangeText : Colors.white);
    return GestureDetector(
      onTap: () => _tapLetter(i),
      child: AnimatedScale(
        scale: active ? 1.08 : 1.0,
        duration: const Duration(milliseconds: 150),
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 150),
          width: 82,
          height: 104,
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(20),
            boxShadow: <BoxShadow>[
              BoxShadow(
                color: Colors.black.withValues(alpha: active ? 0.22 : 0.10),
                blurRadius: active ? 12 : 6,
                offset: const Offset(0, 4),
              ),
            ],
          ),
          child: Column(
            mainAxisAlignment: MainAxisAlignment.center,
            children: <Widget>[
              Text(
                l.lower,
                style: TextStyle(
                  fontSize: 46,
                  fontWeight: FontWeight.w800,
                  color: fg,
                  height: 1.1,
                ),
              ),
              Text(
                l.ipa,
                style: TextStyle(fontSize: 13, color: fg.withValues(alpha: 0.8)),
              ),
            ],
          ),
        ),
      ),
    );
  }

  List<Widget> _tiles(String w) {
    final List<Widget> out = <Widget>[];
    for (int i = 0; i < w.length; i++) {
      if (i > 0) {
        out.add(const Padding(
          padding: EdgeInsets.symmetric(horizontal: 6),
          child: Text(
            '+',
            style: TextStyle(
              fontSize: 22,
              fontWeight: FontWeight.w700,
              color: AppColors.tealSub,
            ),
          ),
        ));
      }
      out.add(_tile(i, w[i]));
    }
    return out;
  }

  Widget _resultCard(bool ar) {
    if (!_revealed) {
      return Container(
        key: const ValueKey<String>('hidden'),
        padding: const EdgeInsets.symmetric(vertical: 22, horizontal: 16),
        decoration: BoxDecoration(
          color: AppColors.bgMain,
          borderRadius: BorderRadius.circular(20),
          border: Border.all(color: AppColors.tealDark.withValues(alpha: 0.15)),
        ),
        child: Column(
          children: <Widget>[
            const Text(
              '?',
              style: TextStyle(
                fontSize: 40,
                fontWeight: FontWeight.w800,
                color: AppColors.tealSub,
              ),
            ),
            const SizedBox(height: 4),
            Text(
              _t(ar, 'اضغطي "مزج" لتسمعي الكلمة كاملة وتعرفي معناها',
                  'Press "Blend" to hear the whole word and see its meaning'),
              textAlign: TextAlign.center,
              style: const TextStyle(fontSize: 13, color: AppColors.tealSub),
            ),
          ],
        ),
      );
    }
    return Container(
      key: ValueKey<String>('revealed-${_current.word}'),
      padding: const EdgeInsets.symmetric(vertical: 16, horizontal: 16),
      decoration: BoxDecoration(
        color: AppColors.tealDark,
        borderRadius: BorderRadius.circular(20),
      ),
      child: Row(
        children: <Widget>[
          Expanded(
            child: Column(
              crossAxisAlignment: CrossAxisAlignment.start,
              children: <Widget>[
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(
                    _current.word,
                    style: const TextStyle(
                      color: AppColors.tealAccent,
                      fontSize: 40,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(height: 2),
                Text(
                  _current.ar,
                  style: const TextStyle(
                    color: Colors.white,
                    fontSize: 22,
                    fontWeight: FontWeight.w700,
                  ),
                ),
              ],
            ),
          ),
          IconButton.filled(
            style: IconButton.styleFrom(
              backgroundColor: AppColors.tealAccent,
              foregroundColor: AppColors.tealDark,
            ),
            onPressed: _hearWord,
            icon: const Icon(Icons.volume_up_rounded),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool ar = widget.ar;
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Container(
            padding: const EdgeInsets.all(12),
            decoration: BoxDecoration(
              color: AppColors.tealDark.withValues(alpha: 0.06),
              borderRadius: BorderRadius.circular(16),
            ),
            child: Text(
              _t(
                ar,
                '1) اضغطي كل حرف لتسمعي صوته.\n2) ثم اضغطي "مزج" لتسمعي الأصوات متصلة وتتعرفي على الكلمة.',
                '1) Tap each letter to hear its sound.\n2) Then press "Blend" to hear the sounds join into a word.',
              ),
              style: const TextStyle(fontSize: 13, height: 1.5),
            ),
          ),
          const SizedBox(height: 20),
          // ترتيب الحروف من اليسار لليمين دائماً (c + a + t).
          Directionality(
            textDirection: TextDirection.ltr,
            child: FittedBox(
              fit: BoxFit.scaleDown,
              child: Row(
                mainAxisSize: MainAxisSize.min,
                children: _tiles(_current.word),
              ),
            ),
          ),
          const SizedBox(height: 20),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.tealDark,
              foregroundColor: Colors.white,
              padding: const EdgeInsets.symmetric(vertical: 16),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(18)),
            ),
            onPressed: _blend,
            icon: const Icon(Icons.play_arrow_rounded, size: 26),
            label: Text(
              _t(ar, 'مزج الأصوات', 'Blend'),
              style: const TextStyle(fontSize: 17, fontWeight: FontWeight.w700),
            ),
          ),
          const SizedBox(height: 16),
          AnimatedSwitcher(
            duration: const Duration(milliseconds: 250),
            child: _resultCard(ar),
          ),
          const SizedBox(height: 12),
          OutlinedButton.icon(
            style: OutlinedButton.styleFrom(
              padding: const EdgeInsets.symmetric(vertical: 13),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
            ),
            onPressed: _nextWord,
            icon: const Icon(Icons.shuffle_rounded),
            label: Text(
              _t(ar, 'كلمة جديدة', 'New word'),
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }
}

// -----------------------------------------------------------------------------
// 3) قسم الاختبار
// -----------------------------------------------------------------------------
class _QuizSection extends StatefulWidget {
  final bool ar;
  const _QuizSection({required this.ar});

  @override
  State<_QuizSection> createState() => _QuizSectionState();
}

class _QuizSectionState extends State<_QuizSection>
    with _AudioRunner<_QuizSection> {
  final Random _rng = Random();
  late List<PhonicsLetter> _targets;
  late List<PhonicsLetter> _options;
  int _index = 0;
  int _score = 0;
  PhonicsLetter? _picked;
  bool _finished = false;

  @override
  void initState() {
    super.initState();
    _startRound();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      if (mounted) _playTarget();
    });
  }

  @override
  void dispose() {
    cancelAudio();
    super.dispose();
  }

  void _startRound() {
    final List<PhonicsLetter> pool = List<PhonicsLetter>.from(kPhonicsLetters)
      ..shuffle(_rng);
    _targets = pool.take(kQuizLength).toList();
    _index = 0;
    _score = 0;
    _picked = null;
    _finished = false;
    _buildOptions();
  }

  /// 4 خيارات بأصوات مختلفة (فلا يجتمع c و k لأنهما بالصوت نفسه /k/).
  void _buildOptions() {
    final PhonicsLetter target = _targets[_index];
    final List<PhonicsLetter> others = kPhonicsLetters
        .where((PhonicsLetter l) => l.ipa != target.ipa)
        .toList()
      ..shuffle(_rng);
    final List<PhonicsLetter> opts = <PhonicsLetter>[target];
    for (final PhonicsLetter l in others) {
      if (opts.length >= 4) break;
      if (opts.any((PhonicsLetter o) => o.ipa == l.ipa)) continue;
      opts.add(l);
    }
    opts.shuffle(_rng);
    _options = opts;
  }

  Future<void> _playTarget() {
    return runAudio((bool Function() cancelled) async {
      await say(_targets[_index].sound, slow: true);
    });
  }

  Future<void> _answer(PhonicsLetter choice) async {
    if (_picked != null || _finished) return;
    SpeechService.instance.playTapClick();
    final PhonicsLetter target = _targets[_index];
    final bool ok = choice.ipa == target.ipa;
    setState(() {
      _picked = choice;
      if (ok) _score++;
    });
    await runAudio((bool Function() cancelled) async {
      await say(target.sound, slow: true);
      if (cancelled()) return;
      await pause(300);
      if (cancelled()) return;
      await say(target.word);
    });
  }

  void _next() {
    SpeechService.instance.playTapClick();
    cancelAudio();
    if (_index + 1 >= _targets.length) {
      setState(() => _finished = true);
      unawaited(StorageService.instance.markMasteredAndStreak(''));
      return;
    }
    setState(() {
      _index++;
      _picked = null;
      _buildOptions();
    });
    unawaited(_playTarget());
  }

  void _restart() {
    SpeechService.instance.playTapClick();
    cancelAudio();
    setState(_startRound);
    unawaited(_playTarget());
  }

  Widget _optionCard(PhonicsLetter l) {
    final PhonicsLetter target = _targets[_index];
    final bool answered = _picked != null;
    final bool isRight = l.ipa == target.ipa;
    final bool isPicked = identical(_picked, l);

    Color bg = AppColors.tealDark;
    Color fg = Colors.white;
    if (answered && isRight) {
      bg = AppColors.greenLight;
      fg = AppColors.greenText;
    } else if (answered && isPicked) {
      bg = AppColors.orangeSoft;
      fg = AppColors.orangeText;
    }

    return GestureDetector(
      onTap: answered ? null : () => _answer(l),
      child: AnimatedOpacity(
        duration: const Duration(milliseconds: 200),
        opacity: answered && !isRight && !isPicked ? 0.45 : 1.0,
        child: AnimatedContainer(
          duration: const Duration(milliseconds: 200),
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: bg,
            borderRadius: BorderRadius.circular(20),
          ),
          child: Text(
            '${l.upper}${l.lower}',
            style: TextStyle(
              fontSize: 40,
              fontWeight: FontWeight.w800,
              color: fg,
            ),
          ),
        ),
      ),
    );
  }

  Widget _finishedView(bool ar) {
    final String msg;
    if (_score >= 9) {
      msg = _t(ar, 'ممتازة! أذنك الصوتية رائعة 🌟', 'Excellent! Great phonics ears 🌟');
    } else if (_score >= 6) {
      msg = _t(ar, 'جيد جداً! كرري التدريب لتتقني الباقي 👍',
          'Very good! Practice a bit more 👍');
    } else {
      msg = _t(ar, 'بداية جيدة! راجعي قسم الحروف وجربي مرة أخرى 💪',
          'Good start! Review the Letters tab and try again 💪');
    }
    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 20, 16, 24),
      child: Column(
        children: <Widget>[
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(vertical: 28, horizontal: 16),
            decoration: BoxDecoration(
              color: AppColors.tealDark,
              borderRadius: BorderRadius.circular(24),
            ),
            child: Column(
              children: <Widget>[
                const Text('🏆', style: TextStyle(fontSize: 54)),
                const SizedBox(height: 8),
                Directionality(
                  textDirection: TextDirection.ltr,
                  child: Text(
                    '$_score / ${_targets.length}',
                    style: const TextStyle(
                      color: AppColors.tealAccent,
                      fontSize: 44,
                      fontWeight: FontWeight.w800,
                    ),
                  ),
                ),
                const SizedBox(height: 8),
                Text(
                  msg,
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 15),
                ),
              ],
            ),
          ),
          const SizedBox(height: 16),
          ElevatedButton.icon(
            style: ElevatedButton.styleFrom(
              backgroundColor: AppColors.tealAccent,
              foregroundColor: AppColors.tealDark,
              padding: const EdgeInsets.symmetric(horizontal: 28, vertical: 14),
              shape: RoundedRectangleBorder(
                  borderRadius: BorderRadius.circular(16)),
            ),
            onPressed: _restart,
            icon: const Icon(Icons.refresh_rounded),
            label: Text(
              _t(ar, 'اختبار جديد', 'New quiz'),
              style: const TextStyle(fontWeight: FontWeight.w700),
            ),
          ),
        ],
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final bool ar = widget.ar;
    if (_finished) return _finishedView(ar);

    final PhonicsLetter target = _targets[_index];
    final bool answered = _picked != null;
    final bool correct = answered && _picked!.ipa == target.ipa;

    return SingleChildScrollView(
      padding: const EdgeInsets.fromLTRB(16, 4, 16, 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.stretch,
        children: <Widget>[
          Row(
            mainAxisAlignment: MainAxisAlignment.spaceBetween,
            children: <Widget>[
              Flexible(
                child: Text(
                  _t(ar, 'السؤال ${_index + 1} من ${_targets.length}',
                      'Question ${_index + 1} of ${_targets.length}'),
                  style: const TextStyle(
                      fontWeight: FontWeight.w700, color: AppColors.tealSub),
                ),
              ),
              Container(
                padding:
                    const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                decoration: BoxDecoration(
                  color: AppColors.tealDark,
                  borderRadius: BorderRadius.circular(99),
                ),
                child: Text(
                  '⭐ $_score',
                  style: const TextStyle(
                      color: Colors.white, fontWeight: FontWeight.w700),
                ),
              ),
            ],
          ),
          const SizedBox(height: 14),
          Container(
            padding: const EdgeInsets.symmetric(vertical: 18, horizontal: 16),
            decoration: BoxDecoration(
              color: AppColors.tealDark,
              borderRadius: BorderRadius.circular(22),
            ),
            child: Column(
              children: <Widget>[
                Text(
                  _t(ar, 'اسمعي الصوت ثم اختاري الحرف الصحيح',
                      'Listen to the sound, then pick the right letter'),
                  textAlign: TextAlign.center,
                  style: const TextStyle(color: Colors.white, fontSize: 14),
                ),
                const SizedBox(height: 12),
                IconButton.filled(
                  iconSize: 42,
                  style: IconButton.styleFrom(
                    backgroundColor: AppColors.tealAccent,
                    foregroundColor: AppColors.tealDark,
                    padding: const EdgeInsets.all(16),
                  ),
                  onPressed: () {
                    SpeechService.instance.playTapClick();
                    _playTarget();
                  },
                  icon: const Icon(Icons.volume_up_rounded),
                ),
                AnimatedWaveform(playing: busy),
              ],
            ),
          ),
          const SizedBox(height: 14),
          // الخيارات: LTR حتى لا ينعكس ترتيبها في الواجهة العربية.
          Directionality(
            textDirection: TextDirection.ltr,
            child: GridView.count(
              shrinkWrap: true,
              physics: const NeverScrollableScrollPhysics(),
              crossAxisCount: 2,
              mainAxisSpacing: 12,
              crossAxisSpacing: 12,
              childAspectRatio: 1.6,
              children: _options.map(_optionCard).toList(),
            ),
          ),
          if (answered) ...<Widget>[
            const SizedBox(height: 14),
            Container(
              padding: const EdgeInsets.all(14),
              decoration: BoxDecoration(
                color: correct ? AppColors.greenLight : AppColors.orangeSoft,
                borderRadius: BorderRadius.circular(18),
              ),
              child: Text(
                correct
                    ? _t(ar, 'أحسنتِ! إجابة صحيحة ✓', 'Great job! Correct ✓')
                    : _t(
                        ar,
                        'ليست الإجابة الصحيحة. الصوت ${target.ipa} هو للحرف ${target.upper}${target.lower} مثل ${target.word}',
                        'Not quite. The sound ${target.ipa} belongs to ${target.upper}${target.lower} as in ${target.word}',
                      ),
                style: TextStyle(
                  color: correct ? AppColors.greenText : AppColors.orangeText,
                  fontWeight: FontWeight.w700,
                  height: 1.4,
                ),
              ),
            ),
            const SizedBox(height: 12),
            ElevatedButton(
              style: ElevatedButton.styleFrom(
                backgroundColor: AppColors.tealDark,
                foregroundColor: Colors.white,
                padding: const EdgeInsets.symmetric(vertical: 14),
                shape: RoundedRectangleBorder(
                    borderRadius: BorderRadius.circular(16)),
              ),
              onPressed: _next,
              child: Text(
                _index + 1 >= _targets.length
                    ? _t(ar, 'عرض النتيجة', 'See result')
                    : _t(ar, 'السؤال التالي', 'Next question'),
                style: const TextStyle(fontWeight: FontWeight.w700),
              ),
            ),
          ],
        ],
      ),
    );
  }
}
