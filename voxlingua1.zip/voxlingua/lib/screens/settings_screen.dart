import 'package:flutter/material.dart';
import '../data/fallback_data.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';

void showSettingsModal(BuildContext context) {
  SpeechService.instance.playTapClick();
  showDialog(
    context: context,
    builder: (_) => const _SettingsDialog(),
  );
}

class _SettingsDialog extends StatelessWidget {
  const _SettingsDialog();

  @override
  Widget build(BuildContext context) {
    final store = StorageService.instance;
    return AnimatedBuilder(
      animation: store,
      builder: (_, __) {
        final lang = store.lang;
        return Dialog(
          backgroundColor: AppColors.tealDark,
          shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
          child: Padding(
            padding: const EdgeInsets.all(20),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              crossAxisAlignment: CrossAxisAlignment.stretch,
              children: [
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(
                      AppStrings.get(lang, 'settingsTitle'),
                      style: const TextStyle(color: Colors.white, fontSize: 18, fontWeight: FontWeight.w700),
                    ),
                    IconButton(
                      onPressed: () {
                        SpeechService.instance.playTapClick();
                        Navigator.pop(context);
                      },
                      icon: const Icon(Icons.close, color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 14),
                Text(AppStrings.get(lang, 'interfaceLang'),
                    style: const TextStyle(color: Colors.white70, fontSize: 14)),
                const SizedBox(height: 8),
                Row(
                  children: [
                    Expanded(
                      child: _LangBtn(
                        label: 'العربية',
                        active: lang == 'ar',
                        onTap: () {
                          SpeechService.instance.playTapClick();
                          store.setLanguage('ar');
                        },
                      ),
                    ),
                    const SizedBox(width: 8),
                    Expanded(
                      child: _LangBtn(
                        label: 'English',
                        active: lang == 'en',
                        onTap: () {
                          SpeechService.instance.playTapClick();
                          store.setLanguage('en');
                        },
                      ),
                    ),
                  ],
                ),
                const SizedBox(height: 18),
                Row(
                  mainAxisAlignment: MainAxisAlignment.spaceBetween,
                  children: [
                    Text(AppStrings.get(lang, 'fontSize'),
                        style: const TextStyle(color: Colors.white70, fontSize: 14)),
                    Container(
                      padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3),
                      decoration: BoxDecoration(
                        color: AppColors.tealAccent,
                        borderRadius: BorderRadius.circular(99),
                      ),
                      child: Text(
                        '${store.fontScalePercent}%',
                        style: const TextStyle(color: AppColors.tealDark, fontWeight: FontWeight.w700),
                      ),
                    ),
                  ],
                ),
                Row(
                  children: [
                    IconButton(
                      onPressed: () {
                        SpeechService.instance.playTapClick();
                        store.setFontScale(store.fontScalePercent - 5);
                      },
                      icon: const Icon(Icons.remove_circle_outline, color: Colors.white),
                    ),
                    Expanded(
                      child: Slider(
                        value: store.fontScalePercent.toDouble(),
                        min: 80,
                        max: 150,
                        divisions: 14,
                        activeColor: AppColors.tealAccent,
                        inactiveColor: Colors.white24,
                        onChanged: (v) => store.setFontScale(v.round()),
                      ),
                    ),
                    IconButton(
                      onPressed: () {
                        SpeechService.instance.playTapClick();
                        store.setFontScale(store.fontScalePercent + 5);
                      },
                      icon: const Icon(Icons.add_circle_outline, color: Colors.white),
                    ),
                  ],
                ),
                const SizedBox(height: 8),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 6),
                  decoration: BoxDecoration(
                    color: AppColors.tealSub,
                    borderRadius: BorderRadius.circular(16),
                  ),
                  child: Row(
                    mainAxisAlignment: MainAxisAlignment.spaceBetween,
                    children: [
                      Text(AppStrings.get(lang, 'clickSound'),
                          style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w600)),
                      Switch(
                        value: store.clickSound,
                        activeColor: AppColors.tealDark,
                        activeTrackColor: AppColors.tealAccent,
                        onChanged: (v) async {
                          await store.setClickSound(v);
                          if (v) SpeechService.instance.playTapClick();
                        },
                      ),
                    ],
                  ),
                ),
              ],
            ),
          ),
        );
      },
    );
  }
}

class _LangBtn extends StatelessWidget {
  final String label;
  final bool active;
  final VoidCallback onTap;
  const _LangBtn({required this.label, required this.active, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(vertical: 10),
        decoration: BoxDecoration(
          color: active ? AppColors.tealAccent : AppColors.tealSub,
          borderRadius: BorderRadius.circular(14),
        ),
        alignment: Alignment.center,
        child: Text(
          label,
          style: TextStyle(
            color: active ? AppColors.tealDark : Colors.white,
            fontWeight: FontWeight.w700,
          ),
        ),
      ),
    );
  }
}