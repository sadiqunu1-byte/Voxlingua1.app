import 'dart:async';
import 'package:flutter/material.dart';
import 'package:video_player/video_player.dart';
import 'package:youtube_player_flutter/youtube_player_flutter.dart';
import '../data/fallback_data.dart';
import '../models/app_models.dart';
import '../services/api_service.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';
import '../widgets/word_sheet.dart';

class ShadowingScreen extends StatefulWidget {
  const ShadowingScreen({super.key});
  @override
  State<ShadowingScreen> createState() => _ShadowingScreenState();
}

class _ShadowingScreenState extends State<ShadowingScreen> {
  String _selectedLevel = 'A1';
  bool _loadingList = true;
  List<ShadowingVideo> _videos = [];
  ShadowingVideo? _activeVideo;
  YoutubePlayerController? _ytCtrl;
  VideoPlayerController? _vc;
  bool _loadingCaptions = false;
  bool _loadingMp4 = false;
  int _activeCueIndex = -1;
  int? _shadowingCueIndex;
  PronunciationEval? _cueEval;
  final ScrollController _cueScrollCtrl = ScrollController();
  final ValueNotifier<int> _posMsNotifier = ValueNotifier<int>(0);
  Timer? _syncTimer;

  @override
  void initState() {
    super.initState();
    _loadVideos();
  }

  @override
  void dispose() {
    _disposePlayers();
    _cueScrollCtrl.dispose();
    _posMsNotifier.dispose();
    super.dispose();
  }

  void _disposePlayers() {
    _syncTimer?.cancel();
    _syncTimer = null;
    _ytCtrl?.dispose();
    _ytCtrl = null;
    _vc?.dispose();
    _vc = null;
    _posMsNotifier.value = 0;
  }

  Future<void> _loadVideos() async {
    setState(() => _loadingList = true);
    final list = await ApiService.instance.fetchShadowingVideos(_selectedLevel);
    if (mounted) setState(() { _videos = list; _loadingList = false; });
  }

  void _startSyncTimer() {
    _syncTimer?.cancel();
    _syncTimer = Timer.periodic(const Duration(milliseconds: 120), (_) => _onTick());
  }

  Future<void> _openVideo(ShadowingVideo video) async {
    SpeechService.instance.playTapClick();
    final messenger = ScaffoldMessenger.of(context);
    _disposePlayers();

    setState(() {
      _activeVideo = video;
      _loadingCaptions = true;
      _loadingMp4 = !video.isYouTube;
      _activeCueIndex = -1;
      _cueEval = null;
    });

    if (video.isYouTube) {
      _ytCtrl = YoutubePlayerController(
        initialVideoId: video.youtubeId,
        flags: const YoutubePlayerFlags(autoPlay: true, mute: false, enableCaption: false),
      );
      _startSyncTimer();
      await ApiService.instance.loadAndTranslateSubtitles(video);
      if (mounted) setState(() => _loadingCaptions = false);
      ApiService.instance.translateRemainingCues(video.cues, onLineReady: () {
        if (mounted) setState(() {});
      });
    } else {
      try {
        final cuesFuture = ApiService.instance.loadAndTranslateSubtitles(video);
        final ctrl = VideoPlayerController.networkUrl(
          Uri.parse(video.videoUrl),
          httpHeaders: const {'User-Agent': 'VoxlinguaApp/1.0'},
        );
        await Future.wait<void>([
          ctrl.initialize().timeout(const Duration(seconds: 15)),
          cuesFuture.then((_) {}),
        ]);
        if (!mounted) { await ctrl.dispose(); return; }
        _vc = ctrl;
        await ctrl.play();
        _startSyncTimer();
        setState(() { _loadingMp4 = false; _loadingCaptions = false; });
        ApiService.instance.translateRemainingCues(video.cues, onLineReady: () {
          if (mounted) setState(() {});
        });
      } catch (_) {
        if (mounted) {
          setState(() { _loadingMp4 = false; _loadingCaptions = false; });
          messenger.showSnackBar(SnackBar(content: Text(AppStrings.get(StorageService.instance.lang, 'videoLoadError'))));
        }
      }
    }
  }

  void _onTick() {
    final video = _activeVideo;
    if (video == null) return;
    int posMs = 0;
    if (_ytCtrl != null) {
      posMs = _ytCtrl!.value.position.inMilliseconds;
    } else if (_vc != null && _vc!.value.isInitialized) {
      posMs = _vc!.value.position.inMilliseconds;
    } else {
      return;
    }
    _posMsNotifier.value = posMs;

    int found = -1;
    for (int i = 0; i < video.cues.length; i++) {
      if (posMs >= video.cues[i].startMs && posMs <= video.cues[i].endMs) {
        found = i;
        break;
      }
    }
    if (found != _activeCueIndex && mounted) {
      setState(() => _activeCueIndex = found);
      if (found >= 0 && _cueScrollCtrl.hasClients) {
        final target = (found * 98.0).clamp(0.0, _cueScrollCtrl.position.maxScrollExtent);
        _cueScrollCtrl.animateTo(target, duration: const Duration(milliseconds: 260), curve: Curves.easeOutCubic);
      }
    }
  }

  void _pausePlayer() {
    _ytCtrl?.pause();
    _vc?.pause();
  }

  Future<void> _seekToCue(SubtitleCue cue) async {
    SpeechService.instance.playTapClick();
    final d = Duration(milliseconds: cue.startMs);
    if (_ytCtrl != null) {
      _ytCtrl!.seekTo(d);
      _ytCtrl!.play();
    } else if (_vc != null) {
      await _vc!.seekTo(d);
      await _vc!.play();
    }
  }

  Future<void> _shadowCue(int index, SubtitleCue cue) async {
    final messenger = ScaffoldMessenger.of(context);
    if (_shadowingCueIndex == index) {
      await SpeechService.instance.stopListening();
      if (mounted) setState(() => _shadowingCueIndex = null);
      return;
    }
    _pausePlayer();
    setState(() { _shadowingCueIndex = index; _cueEval = null; });
    final err = await SpeechService.instance.startListening(
      onLive: (_) {},
      onFinal: (spoken) {
        final ev = SpeechService.instance.evaluate(cue.en, spoken);
        if (ev.score >= 80) StorageService.instance.markMasteredAndStreak('vid_${cue.en.hashCode}', levelCode: _selectedLevel);
        if (mounted) setState(() { _cueEval = ev; _shadowingCueIndex = null; });
      },
      onStopped: () { if (mounted) setState(() => _shadowingCueIndex = null); },
    );
    if (err != null && mounted) {
      setState(() => _shadowingCueIndex = null);
      messenger.showSnackBar(SnackBar(content: Text(AppStrings.get(StorageService.instance.lang, err))));
    }
  }

  void _openCustomVideoDialog() {
    SpeechService.instance.playTapClick();
    final urlCtrl = TextEditingController(), srtCtrl = TextEditingController();
    final lang = StorageService.instance.lang;
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        backgroundColor: AppColors.tealDark,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(24)),
        title: Text(AppStrings.get(lang, 'customVideoTitle'), style: const TextStyle(color: Colors.white, fontSize: 16)),
        content: SingleChildScrollView(
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: urlCtrl, textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.white),
                decoration: InputDecoration(filled: true, fillColor: AppColors.tealSub, hintText: AppStrings.get(lang, 'videoUrlHint'),
                    hintStyle: const TextStyle(color: Colors.white54, fontSize: 13), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
              ),
              const SizedBox(height: 10),
              TextField(
                controller: srtCtrl, maxLines: 5, textDirection: TextDirection.ltr, style: const TextStyle(color: Colors.white, fontSize: 12),
                decoration: InputDecoration(filled: true, fillColor: AppColors.tealSub, hintText: AppStrings.get(lang, 'srtHint'),
                    hintStyle: const TextStyle(color: Colors.white54, fontSize: 12), border: OutlineInputBorder(borderRadius: BorderRadius.circular(14), borderSide: BorderSide.none)),
              ),
            ],
          ),
        ),
        actions: [
          ElevatedButton(
            style: ElevatedButton.styleFrom(backgroundColor: AppColors.tealAccent, foregroundColor: AppColors.tealDark),
            onPressed: () {
              final url = urlCtrl.text.trim();
              if (url.isEmpty) return;
              Navigator.pop(ctx);
              final ytId = YoutubePlayer.convertUrlToId(url) ?? '';
              final parsed = srtCtrl.text.trim().isNotEmpty ? ApiService.parseSrtOrVtt(srtCtrl.text) : <SubtitleCue>[];
              _openVideo(ShadowingVideo(
                id: 'custom_${DateTime.now().millisecondsSinceEpoch}', level: _selectedLevel,
                title: ytId.isNotEmpty ? 'Custom YouTube Shadowing' : 'Custom MP4 Video',
                youtubeId: ytId, videoUrl: ytId.isEmpty ? url : '',
                sourceName: ytId.isNotEmpty ? 'YouTube' : 'Custom Video', cues: parsed,
              ));
            },
            child: Text(AppStrings.get(lang, 'openVideo')),
          ),
        ],
      ),
    );
  }

  Widget _cueBtn(String label, bool active, VoidCallback onTap) {
    return GestureDetector(
      onTap: onTap,
      child: Container(
        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 5),
        decoration: BoxDecoration(color: active ? AppColors.tealAccent : AppColors.tealAccent.withValues(alpha: 0.16), borderRadius: BorderRadius.circular(10)),
        child: Text(label, style: TextStyle(color: active ? AppColors.tealDark : AppColors.tealAccent, fontWeight: FontWeight.w700)),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final lang = StorageService.instance.lang;
    final activeCue = (_activeVideo != null && _activeCueIndex >= 0 && _activeCueIndex < _activeVideo!.cues.length)
        ? _activeVideo!.cues[_activeCueIndex] : null;

    return Column(
      crossAxisAlignment: CrossAxisAlignment.stretch,
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 12, 16, 8),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Text(AppStrings.get(lang, 'shadowingTitle'), style: const TextStyle(fontSize: 19, fontWeight: FontWeight.w700)),
            TextButton(
              style: TextButton.styleFrom(backgroundColor: AppColors.tealDark, foregroundColor: Colors.white, shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              onPressed: _openCustomVideoDialog,
              child: Text(AppStrings.get(lang, 'addCustomVideo'), style: const TextStyle(fontSize: 12)),
            ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Row(
            children: cefrMetaList.map((m) {
              final active = m.code == _selectedLevel;
              return Expanded(
                child: GestureDetector(
                  onTap: () { SpeechService.instance.playTapClick(); setState(() => _selectedLevel = m.code); _loadVideos(); },
                  child: Container(
                    margin: const EdgeInsets.symmetric(horizontal: 3), padding: const EdgeInsets.symmetric(vertical: 8),
                    decoration: BoxDecoration(color: active ? AppColors.tealDark : AppColors.bgSoft, borderRadius: BorderRadius.circular(12), border: Border.all(color: AppColors.tealDark.withValues(alpha: 0.18))),
                    alignment: Alignment.center,
                    child: Text(m.code, style: TextStyle(color: active ? Colors.white : AppColors.tealDark, fontWeight: FontWeight.w700)),
                  ),
                ),
              );
            }).toList(),
          ),
        ),
        Padding(
          padding: const EdgeInsets.fromLTRB(16, 8, 16, 6),
          child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
            Expanded(child: Text(AppStrings.get(lang, 'videosSourceInfo'), style: const TextStyle(color: AppColors.tealSub, fontSize: 12))),
            OutlinedButton.icon(
              style: OutlinedButton.styleFrom(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 6), shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12))),
              onPressed: () { SpeechService.instance.playTapClick(); ApiService.instance.syncRemoteContent(force: true).then((_) => _loadVideos()); },
              icon: const Icon(Icons.refresh_rounded, size: 16),
              label: Text(AppStrings.get(lang, 'fetchNewVideos'), style: const TextStyle(fontSize: 12)),
            ),
          ]),
        ),
        if (_activeVideo != null) ...[
          Container(
            color: Colors.black,
            child: Stack(
              children: [
                if (_activeVideo!.isYouTube && _ytCtrl != null)
                  YoutubePlayer(key: ValueKey(_activeVideo!.id), controller: _ytCtrl!, showVideoProgressIndicator: true, progressIndicatorColor: AppColors.tealAccent)
                else if (_loadingMp4 || _vc == null || !_vc!.value.isInitialized)
                  const SizedBox(height: 190, child: Center(child: CircularProgressIndicator(color: AppColors.tealAccent)))
                else
                  AspectRatio(aspectRatio: _vc!.value.aspectRatio > 0 ? _vc!.value.aspectRatio : 16 / 9, child: VideoPlayer(_vc!)),
                Positioned(
                  top: 6, right: 6,
                  child: IconButton(
                    style: IconButton.styleFrom(backgroundColor: Colors.black54),
                    onPressed: () { SpeechService.instance.playTapClick(); _disposePlayers(); setState(() => _activeVideo = null); },
                    icon: const Icon(Icons.close_rounded, color: Colors.white),
                  ),
                ),
              ],
            ),
          ),
          Container(
            width: double.infinity,
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 8),
            decoration: const BoxDecoration(color: AppColors.tealDark, border: Border.symmetric(horizontal: BorderSide(color: AppColors.tealAccent, width: 1.0))),
            child: _loadingCaptions
                ? const Center(child: SizedBox(height: 18, width: 18, child: CircularProgressIndicator(strokeWidth: 2, color: AppColors.tealAccent)))
                : _activeVideo!.cues.isEmpty
                    ? Text(AppStrings.get(lang, 'noCaptions'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white70, fontSize: 12))
                    : activeCue == null
                        ? Text(AppStrings.get(lang, 'waitingSpeech'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white54, fontSize: 12))
                        : ValueListenableBuilder<int>(
                            valueListenable: _posMsNotifier,
                            builder: (_, posMs, __) => Column(mainAxisSize: MainAxisSize.min, children: [
                              WordHighlightedSentence(cue: activeCue, posMs: posMs, textAlign: TextAlign.center,
                                  baseStyle: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500, height: 1.3)),
                              if (activeCue.ar.isNotEmpty) ...[
                                const SizedBox(height: 3),
                                Text(activeCue.ar, textAlign: TextAlign.center, maxLines: 1, overflow: TextOverflow.ellipsis,
                                    style: const TextStyle(color: AppColors.tealAccent, fontSize: 12, height: 1.2)),
                              ],
                            ]),
                          ),
          ),
          if (_cueEval != null)
            Container(
              width: double.infinity, color: AppColors.tealSub, padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 8),
              child: Row(children: [
                Container(padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 3), decoration: BoxDecoration(color: AppColors.tealAccent, borderRadius: BorderRadius.circular(99)),
                    child: Text('${_cueEval!.score}%', style: const TextStyle(color: AppColors.tealDark, fontWeight: FontWeight.w700))),
                const SizedBox(width: 8),
                Expanded(child: Directionality(textDirection: TextDirection.ltr, child: Wrap(spacing: 4, runSpacing: 4, children: _cueEval!.words.map((w) => Container(
                  padding: const EdgeInsets.symmetric(horizontal: 7, vertical: 2),
                  decoration: BoxDecoration(color: w.isCorrect ? AppColors.greenLight : AppColors.orangeSoft, borderRadius: BorderRadius.circular(8)),
                  child: Text(w.text, style: TextStyle(color: w.isCorrect ? AppColors.greenText : AppColors.orangeText, fontSize: 12, fontWeight: FontWeight.w700)),
                )).toList()))),
              ]),
            ),
          Expanded(
            child: ListView.builder(
              controller: _cueScrollCtrl, padding: const EdgeInsets.all(12), itemCount: _activeVideo!.cues.length,
              itemBuilder: (_, i) {
                final cue = _activeVideo!.cues[i], isCurrent = i == _activeCueIndex;
                return GestureDetector(
                  onTap: () => _seekToCue(cue),
                  child: Container(
                    margin: const EdgeInsets.only(bottom: 8), padding: const EdgeInsets.all(12),
                    decoration: BoxDecoration(color: isCurrent ? AppColors.tealSub : AppColors.tealDark, borderRadius: BorderRadius.circular(16), border: Border.all(color: isCurrent ? AppColors.tealAccent : Colors.transparent, width: 1.5)),
                    child: Column(crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                      if (isCurrent)
                        ValueListenableBuilder<int>(
                          valueListenable: _posMsNotifier,
                          builder: (_, posMs, __) => WordHighlightedSentence(cue: cue, posMs: posMs, baseStyle: const TextStyle(color: Colors.white, fontSize: 14.5, fontWeight: FontWeight.w600)),
                        )
                      else
                        ClickableSentence(text: cue.en, style: const TextStyle(color: Colors.white, fontSize: 14, fontWeight: FontWeight.w500)),
                      if (cue.ar.isNotEmpty) ...[const SizedBox(height: 4), Text(cue.ar, style: const TextStyle(color: Colors.white70, fontSize: 13))],
                      const SizedBox(height: 8),
                      Row(children: [
                        _cueBtn('🔊', false, () { SpeechService.instance.playTapClick(); _pausePlayer(); SpeechService.instance.speakEnglish(cue.en); }),
                        const SizedBox(width: 8),
                        _cueBtn(_shadowingCueIndex == i ? '⏹' : '🎙️', _shadowingCueIndex == i, () => _shadowCue(i, cue)),
                      ]),
                    ]),
                  ),
                );
              },
            ),
          ),
        ] else ...[
          Expanded(
            child: _loadingList
                ? Center(child: Column(mainAxisSize: MainAxisSize.min, children: [const CircularProgressIndicator(color: AppColors.tealDark), const SizedBox(height: 12), Text(AppStrings.get(lang, 'loadingVideos'))]))
                : ListView.builder(
                    padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 6), itemCount: _videos.length,
                    itemBuilder: (_, idx) {
                      final v = _videos[idx];
                      final mins = v.durationSec > 0 ? '${(v.durationSec / 60).ceil()} min' : 'Short';
                      return GestureDetector(
                        onTap: () => _openVideo(v),
                        child: Container(
                          margin: const EdgeInsets.only(bottom: 10), padding: const EdgeInsets.all(14),
                          decoration: BoxDecoration(color: AppColors.tealDark, borderRadius: BorderRadius.circular(20)),
                          child: Row(children: [
Container(
                              width: 52,
                              height: 52,
                              decoration: BoxDecoration(color: AppColors.tealSub, borderRadius: BorderRadius.circular(14)),
                              child: Icon(v.isYouTube ? Icons.smart_display_rounded : Icons.play_circle_fill_rounded, color: AppColors.tealAccent, size: 30),
                            ),
                            const SizedBox(width: 12),
                            Expanded(
                              child: Column(
                                crossAxisAlignment: CrossAxisAlignment.start,
                                children: [
                                  Directionality(
                                    textDirection: TextDirection.ltr,
                                    child: Text(v.title, maxLines: 2, overflow: TextOverflow.ellipsis, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.w700, fontSize: 14)),
                                  ),
                                  const SizedBox(height: 4),
                                  Text('$_selectedLevel • $mins • ${v.sourceName}', style: const TextStyle(color: AppColors.tealAccent, fontSize: 12)),
                                ],
                              ),
                            ),
                          ]),
                        ),
                      );
                    },
                  ),
          ),
        ],
      ],
    );
  }
}