import 'package:flutter/material.dart';
import '../data/fallback_data.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';

class SplashScreen extends StatefulWidget {
  final VoidCallback onFinished;
  const SplashScreen({super.key, required this.onFinished});

  @override
  State<SplashScreen> createState() => _SplashScreenState();
}

class _SplashScreenState extends State<SplashScreen> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 2500), () {
      if (mounted) widget.onFinished();
    });
  }

  @override
  Widget build(BuildContext context) {
    final lang = StorageService.instance.lang;
    return Scaffold(
      backgroundColor: AppColors.bgMain,
      body: Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(28),
              child: Image.asset(
                'assets/images/logo.png',
                width: 124,
                height: 124,
                fit: BoxFit.contain,
                errorBuilder: (_, __, ___) => const CircleAvatar(
                  radius: 56,
                  backgroundColor: AppColors.tealDark,
                  child: Icon(Icons.record_voice_over_rounded, size: 52, color: AppColors.tealAccent),
                ),
              ),
            ),
            const SizedBox(height: 14),
            const VoxlinguaLogo(fontSize: 32),
            const SizedBox(height: 6),
            Text(
              AppStrings.get(lang, 'splashTagline'),
              style: const TextStyle(color: AppColors.tealSub, fontSize: 15),
            ),
          ],
        ),
      ),
    );
  }
}