import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../data/fallback_data.dart';
import '../models/app_models.dart';
import 'storage_service.dart';

class AppUpdateInfo {
  final String version, apkUrl, notes;
  final int build;
  final bool force;
  const AppUpdateInfo({required this.version, required this.build, required this.apkUrl, required this.notes, required this.force});
}

class ApiService {
  static final ApiService instance = ApiService._();
  ApiService._();

  static const int currentAppBuild = 1;
  static const String currentAppVersion = '1.0.0';

  final Map<String, String> _translationCache = {};
  final Set<String> _seenSentences = {};
  final Set<String> _seenWords = {};
  int _sentenceTurn = 0;
  Map<String, dynamic>? _remoteCacheMap;

  Future<bool> syncRemoteContent({bool force = false}) async {
    if (!force && _remoteCacheMap != null) return true;
    try {
      final base = StorageService.instance.remoteJsonUrl;
      final sep = base.contains('?') ? '&' : '?';
      final url = force ? '$base${sep}t=${DateTime.now().millisecondsSinceEpoch}' : base;
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 7));
      if (res.statusCode == 200) {
        final body = utf8.decode(res.bodyBytes);
        final decoded = jsonDecode(body);
        if (decoded is Map<String, dynamic>) {
          _remoteCacheMap = decoded;
          await StorageService.instance.saveRemoteContentCache(body);
          return true;
        }
      }
    } catch (_) {}
    final cachedRaw = StorageService.instance.getRemoteContentCache();
    if (cachedRaw != null && cachedRaw.isNotEmpty) {
      try {
        final decoded = jsonDecode(cachedRaw);
        if (decoded is Map<String, dynamic>) _remoteCacheMap = decoded;
      } catch (_) {}
    }
    return false;
  }

  AppUpdateInfo? checkPendingUpdate() {
    final map = _remoteCacheMap;
    if (map == null) return null;
    final remoteBuild = (map['appBuild'] as num?)?.toInt() ?? 0;
    final apkUrl = (map['apkUrl'] ?? '').toString().trim();
    if (remoteBuild > currentAppBuild && apkUrl.isNotEmpty) {
      return AppUpdateInfo(
        version: (map['appVersion'] ?? '1.0.$remoteBuild').toString(),
        build: remoteBuild,
        apkUrl: apkUrl,
        notes: (map['updateNotes'] ?? '').toString(),
        force: map['forceUpdate'] == true,
      );
    }
    return null;
  }

  Map<String, dynamic> getCurrentCloudMapSnapshot() {
    if (_remoteCacheMap != null) return Map<String, dynamic>.from(_remoteCacheMap!);
    final cachedRaw = StorageService.instance.getRemoteContentCache();
    if (cachedRaw != null && cachedRaw.isNotEmpty) {
      try {
        final d = jsonDecode(cachedRaw);
        if (d is Map<String, dynamic>) return d;
      } catch (_) {}
    }
    return {
      'appVersion': currentAppVersion, 'appBuild': currentAppBuild,
      'apkUrl': 'https://github.com/sadiqunu1-byte/Voxlingua1.app/releases/latest/download/app-release.apk',
      'updateNotes': '', 'forceUpdate': false, 'videos': <dynamic>[],
      'lessons': <String, dynamic>{'A1': [], 'A2': [], 'B1': [], 'B2': [], 'C1': [], 'C2': []},
    };
  }

  List<ShadowingVideo> getCloudVideosForLevel(String level) {
    final map = _remoteCacheMap;
    if (map == null || map['videos'] is! List) return [];
    final out = <ShadowingVideo>[];
    for (final raw in (map['videos'] as List)) {
      if (raw is Map) {
        final vid = ShadowingVideo.fromJson(Map<String, dynamic>.from(raw));
        if (vid.level.toUpperCase() == level.toUpperCase() && (vid.youtubeId.isNotEmpty || vid.videoUrl.isNotEmpty)) out.add(vid);
      }
    }
    return out;
  }

  List<LevelVocabItem> getCloudVocabForLevel(String level) {
    final map = _remoteCacheMap;
    if (map == null || map['lessons'] is! Map) return [];
    final list = (map['lessons'] as Map)[level.toUpperCase()];
    if (list is! List) return [];
    return list.whereType<Map>().map((e) => LevelVocabItem.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  Future<String> translateToArabic(String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return '';
    if (_translationCache.containsKey(clean)) return _translationCache[clean]!;
    final res = await http.get(Uri.parse('https://api.mymemory.translated.net/get?q=${Uri.encodeComponent(clean)}&langpair=en|ar')).timeout(const Duration(seconds: 7));
    if (res.statusCode != 200) throw Exception('Translation failed');
    final translated = (jsonDecode(res.body)['responseData']?['translatedText'] ?? '').toString().trim();
    if (translated.isNotEmpty) _translationCache[clean] = translated;
    return translated;
  }

  Future<WordLookup> lookupWord(String rawWord) async {
    final cleanWord = rawWord.replaceAll(RegExp(r"[^a-zA-Z'-]"), '').toLowerCase();
    if (cleanWord.isEmpty) throw Exception('Invalid word');
    String phonetic = '', example = '', arabic = '';
    await Future.wait([
      http.get(Uri.parse('https://api.dictionaryapi.dev/api/v2/entries/en/${Uri.encodeComponent(cleanWord)}')).timeout(const Duration(seconds: 6)).then((res) {
        if (res.statusCode == 200) {
          final list = jsonDecode(res.body);
          if (list is List && list.isNotEmpty) {
            final entry = list[0] as Map<String, dynamic>;
            phonetic = (entry['phonetic'] ?? '').toString();
            if (phonetic.isEmpty && entry['phonetics'] is List) {
              for (final p in entry['phonetics']) { if (p is Map && (p['text'] ?? '').toString().isNotEmpty) { phonetic = p['text'].toString(); break; } }
            }
            if (entry['meanings'] is List) {
              for (final m in entry['meanings']) {
                for (final d in (m['definitions'] as List? ?? [])) { if ((d['example'] ?? '').toString().isNotEmpty && example.isEmpty) { example = d['example'].toString(); break; } }
                if (example.isNotEmpty) break;
              }
              if (example.isEmpty) { final def = entry['meanings']?[0]?['definitions']?[0]?['definition']; if (def != null) example = def.toString(); }
            }
          }
        }
      }).catchError((_) {}),
      translateToArabic(cleanWord).then((v) => arabic = v).catchError((_) => ''),
    ]);
    if (arabic.isEmpty && phonetic.isEmpty && example.isEmpty) throw Exception('Offline');
    return WordLookup(
      word: cleanWord, phonetic: phonetic.isNotEmpty ? phonetic : '/$cleanWord/',
      arabic: arabic.isNotEmpty ? arabic : '—',
      example: example.isNotEmpty ? example : 'Try to use "$cleanWord" in a natural English sentence.',
    );
  }

  List<String> _extractSentences(String paragraph) => paragraph
      .replaceAll(RegExp(r'\[[^\]]*\]|\([^)]*\)'), '')
      .split(RegExp(r'(?<=[.!?])\s+'))
      .map((s) => s.trim())
      .where((s) { final wc = s.split(RegExp(r'\s+')).length; return wc >= 6 && wc <= 16 && RegExp(r'^[A-Z]').hasMatch(s); })
      .toList();

  String _guessLevel(String s) {
    final words = s.trim().split(RegExp(r'\s+'));
    final avg = words.fold<int>(0, (sum, w) => sum + w.length) / max(1, words.length);
    if (words.length <= 8 && avg < 4.7) return 'A1';
    if (words.length <= 11 && avg < 5.2) return 'A2';
    if (words.length <= 14 && avg < 5.7) return 'B1';
    if (words.length <= 17) return 'B2';
    return avg >= 6.0 ? 'C2' : 'C1';
  }

  Future<SentenceItem> fetchUnlimitedSentence({String? preferredLevel}) async {
    await syncRemoteContent();
    if (preferredLevel != null) {
      for (final item in getCloudVocabForLevel(preferredLevel)) {
        if (item.en.isNotEmpty && !_seenSentences.contains(item.en)) {
          _seenSentences.add(item.en);
          return SentenceItem(id: 'cloud_${item.en.hashCode}', level: preferredLevel, en: item.en, ar: item.enAr.isNotEmpty ? item.enAr : item.ar);
        }
      }
    }
    final isBeginner = preferredLevel == 'A1' || preferredLevel == 'A2';
    final mode = isBeginner ? ((_sentenceTurn++ % 2) + 1) : (_sentenceTurn++ % 3);
    final candidates = <String>[];
    final rng = Random();
    try {
      if (mode == 0) {
        final r = await http.get(Uri.parse('https://en.wikipedia.org/api/rest_v1/page/random/summary')).timeout(const Duration(seconds: 6));
        if (r.statusCode == 200) candidates.addAll(_extractSentences((jsonDecode(r.body)['extract'] ?? '').toString()));
      } else if (mode == 1) {
        final r = await http.get(Uri.parse('https://dummyjson.com/quotes?limit=15&skip=${rng.nextInt(1400)}')).timeout(const Duration(seconds: 6));
        if (r.statusCode == 200) {
          for (final q in (jsonDecode(r.body)['quotes'] as List? ?? [])) {
            final t = (q['quote'] ?? '').toString().trim();
            final wc = t.split(RegExp(r'\s+')).length;
            if (wc >= 5 && wc <= (isBeginner ? 11 : 18)) candidates.add(t);
          }
        }
      } else {
        const letters = 'abcdefghijlmnoprstw';
        final r = await http.get(Uri.parse('https://api.datamuse.com/words?sp=${letters[rng.nextInt(letters.length)]}*&max=30')).timeout(const Duration(seconds: 6));
        if (r.statusCode == 200) {
          final list = jsonDecode(r.body) as List;
          if (list.isNotEmpty) {
            final info = await lookupWord(list[rng.nextInt(list.length)]['word'].toString());
            final wc = info.example.split(RegExp(r'\s+')).length;
            if (wc >= 5 && wc <= (isBeginner ? 12 : 18)) candidates.add(info.example);
          }
        }
      }
    } catch (_) {}
    final picked = candidates.firstWhere((s) => !_seenSentences.contains(s), orElse: () => candidates.isNotEmpty ? candidates.first : '');
    if (picked.isNotEmpty) {
      _seenSentences.add(picked);
      final ar = await translateToArabic(picked).catchError((_) => '');
      return SentenceItem(id: 'dyn_${DateTime.now().millisecondsSinceEpoch}_${rng.nextInt(999)}', level: preferredLevel ?? _guessLevel(picked), en: picked, ar: ar.isNotEmpty ? ar : '—');
    }
    return fallbackDailySentences[rng.nextInt(fallbackDailySentences.length)];
  }

  static const Map<String, List<String>> _topics = {
    'A1': ['family', 'food', 'home', 'morning', 'school', 'color', 'friend', 'water', 'book', 'house'],
    'A2': ['travel', 'shopping', 'weather', 'weekend', 'hobby', 'health', 'work', 'train', 'market'],
    'B1': ['football', 'soccer', 'career', 'decision', 'culture', 'advice', 'goal', 'teamwork'],
    'B2': ['tactics', 'strategy', 'midfield', 'technology', 'communication', 'persuasion', 'growth'],
    'C1': ['formation', 'pressing', 'leadership', 'innovation', 'analysis', 'resilience', 'discourse'],
    'C2': ['philosophy', 'eloquence', 'epistemology', 'nuance', 'rhetoric', 'diplomacy', 'paradigm'],
  };

  Future<List<LevelVocabItem>> fetchDynamicLevelItems(String level, int page) async {
    await syncRemoteContent();
    final results = <LevelVocabItem>[];
    if (page == 0) {
      for (final item in getCloudVocabForLevel(level)) { _seenWords.add(item.word.toLowerCase()); results.add(item); }
    }
    final topicList = _topics[level] ?? _topics['A1']!;
    try {
      final dmRes = await http.get(Uri.parse('https://api.datamuse.com/words?ml=${Uri.encodeComponent(topicList[page % topicList.length])}&md=df&max=35')).timeout(const Duration(seconds: 6));
      if (dmRes.statusCode == 200) {
        final candidates = (jsonDecode(dmRes.body) as List).where((w) {
          final word = (w['word'] ?? '').toString();
          return RegExp(r'^[a-z]{4,13}$').hasMatch(word) && !_seenWords.contains(word);
        }).take(5);
        for (final c in candidates) {
          final w = c['word'].toString(); _seenWords.add(w);
          try {
            final info = await lookupWord(w);
            final exAr = await translateToArabic(info.example).catchError((_) => info.arabic);
            results.add(LevelVocabItem(word: info.word, phonetic: info.phonetic, ar: info.arabic, en: info.example, enAr: exAr.isNotEmpty ? exAr : info.arabic));
          } catch (_) {}
        }
      }
    } catch (_) {}
    return results.isEmpty ? (fallbackLevelData[level] ?? fallbackLevelData['A1']!) : results;
  }

  static int _parseTimeToMs(String raw) {
    final parts = raw.trim().replaceAll(',', '.').split(':');
    int h = 0, m = 0; double s = 0;
    if (parts.length == 3) { h = int.tryParse(parts[0]) ?? 0; m = int.tryParse(parts[1]) ?? 0; s = double.tryParse(parts[2]) ?? 0; }
    else if (parts.length == 2) { m = int.tryParse(parts[0]) ?? 0; s = double.tryParse(parts[1]) ?? 0; }
    return ((h * 3600 + m * 60 + s) * 1000).round();
  }

  static List<WordTiming> buildProportionalWordTimings(String sentence, int startMs, int endMs) {
    final words = sentence.trim().split(RegExp(r'\s+')).where((w) => w.isNotEmpty).toList();
    if (words.isEmpty) return [];
    final totalDur = max(300, endMs - startMs);
    final totalChars = max(1, words.fold<int>(0, (s, w) => s + max(2, w.length)));
    int cursor = startMs;
    final out = <WordTiming>[];
    for (int i = 0; i < words.length; i++) {
      final w = words[i];
      final wDur = (i == words.length - 1) ? max(80, endMs - cursor) : ((totalDur * max(2, w.length)) / totalChars).round().clamp(80, totalDur);
      final wEnd = min(endMs, cursor + wDur);
      out.add(WordTiming(word: w, startMs: cursor, endMs: max(cursor + 50, wEnd)));
      cursor = wEnd;
    }
    return out;
  }

  static List<SubtitleCue> parseSrtOrVtt(String content) {
    final blocks = content.replaceAll('\r\n', '\n').replaceAll('\r', '\n').split(RegExp(r'\n{2,}'));
    final cues = <SubtitleCue>[];
    final timeRx = RegExp(r'(\d{1,2}:\d{2}(?::\d{2})?[.,]\d{2,3})\s*-->\s*(\d{1,2}:\d{2}(?::\d{2})?[.,]\d{2,3})');
    for (final block in blocks) {
      final lines = block.split('\n').map((l) => l.trim()).where((l) => l.isNotEmpty).toList();
      if (lines.isEmpty) continue;
      int ti = -1; RegExpMatch? match;
      for (int i = 0; i < lines.length; i++) { final m = timeRx.firstMatch(lines[i]); if (m != null) { ti = i; match = m; break; } }
      if (ti == -1 || match == null) continue;
      final st = _parseTimeToMs(match.group(1)!), enMs = _parseTimeToMs(match.group(2)!);
      final txt = lines.sublist(ti + 1).join(' ').replaceAll(RegExp(r'<[^>]+>'), '').trim();
      if (txt.isEmpty || enMs <= st) continue;
      cues.add(SubtitleCue(startMs: st, endMs: enMs, en: txt, words: buildProportionalWordTimings(txt, st, enMs)));
    }
    return cues;
  }

  static List<SubtitleCue> _parseYoutubeJson3(String body) {
    final events = (jsonDecode(body)['events'] as List?) ?? [];
    final cues = <SubtitleCue>[];
    for (final ev in events) {
      if (ev is! Map || ev['segs'] is! List) continue;
      final tStart = (ev['tStartMs'] as num?)?.toInt() ?? 0;
      final dDur = (ev['dDurationMs'] as num?)?.toInt() ?? 3000;
      final endMs = tStart + max(500, dDur);
      final segs = ev['segs'] as List;
      final wt = <WordTiming>[];
      final buf = StringBuffer();
      for (int i = 0; i < segs.length; i++) {
        final seg = segs[i];
        if (seg is! Map) continue;
        final text = (seg['utf8'] ?? '').toString().replaceAll('\n', ' ').trim();
        if (text.isEmpty) continue;
        if (buf.isNotEmpty) buf.write(' ');
        buf.write(text);
        final wStart = tStart + ((seg['tOffsetMs'] as num?)?.toInt() ?? 0);
        final nextOff = (i + 1 < segs.length && segs[i + 1] is Map) ? ((segs[i + 1]['tOffsetMs'] as num?)?.toInt() ?? dDur) : dDur;
        final wEnd = max(wStart + 120, tStart + nextOff);
        for (final piece in text.split(RegExp(r'\s+'))) { if (piece.isNotEmpty) wt.add(WordTiming(word: piece, startMs: wStart, endMs: wEnd)); }
      }
      final full = buf.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
      if (full.isEmpty || full.startsWith('[')) continue;
      cues.add(SubtitleCue(startMs: tStart, endMs: endMs, en: full, words: wt.isNotEmpty ? wt : buildProportionalWordTimings(full, tStart, endMs)));
    }
    return cues;
  }

  Future<List<SubtitleCue>> _fetchYoutubeCaptionsDirect(String videoId) async {
    try {
      final pageRes = await http.get(Uri.parse('https://www.youtube.com/watch?v=$videoId'), headers: const {
        'User-Agent': 'Mozilla/5.0 (Linux; Android 13) AppleWebKit/537.36 Chrome/120.0 Mobile Safari/537.36', 'Accept-Language': 'en-US,en;q=0.9',
      }).timeout(const Duration(seconds: 8));
      if (pageRes.statusCode == 200) {
        final m = RegExp(r'"captionTracks":(\[[^\]]+\])').firstMatch(pageRes.body);
        if (m != null) {
          final tracks = jsonDecode(m.group(1)!) as List;
          Map? chosen;
          for (final t in tracks) { if (t is Map && (t['languageCode'] ?? '').toString().startsWith('en') && t['kind'] != 'asr') { chosen = t; break; } }
          chosen ??= tracks.cast<Map?>().firstWhere((t) => t != null && (t['languageCode'] ?? '').toString().startsWith('en'), orElse: () => null);
          if (chosen != null && chosen['baseUrl'] != null) {
            final j3 = await http.get(Uri.parse('${chosen['baseUrl'].toString().replaceAll(r'\u0026', '&')}&fmt=json3')).timeout(const Duration(seconds: 7));
            if (j3.statusCode == 200) { final cues = _parseYoutubeJson3(utf8.decode(j3.bodyBytes, allowMalformed: true)); if (cues.isNotEmpty) return cues; }
          }
        }
      }
    } catch (_) {}
    for (final host in const ['https://inv.nadeko.net', 'https://invidious.privacyredirect.com', 'https://yt.artemislena.eu']) {
      try {
        final capRes = await http.get(Uri.parse('$host/api/v1/captions/$videoId')).timeout(const Duration(seconds: 4));
        if (capRes.statusCode != 200) continue;
        final caps = (jsonDecode(capRes.body)['captions'] as List?) ?? [];
        final en = caps.cast<Map?>().firstWhere((c) => c != null && (c['languageCode'] ?? '').toString().startsWith('en'), orElse: () => null);
        if (en != null && en['url'] != null) {
          final u = en['url'].toString();
          final vttRes = await http.get(Uri.parse(u.startsWith('http') ? u : '$host$u')).timeout(const Duration(seconds: 5));
          if (vttRes.statusCode == 200) { final parsed = parseSrtOrVtt(utf8.decode(vttRes.bodyBytes, allowMalformed: true)); if (parsed.isNotEmpty) return parsed; }
        }
      } catch (_) {}
    }
    return [];
  }

  Future<List<ShadowingVideo>> fetchShadowingVideos(String level, {int page = 1}) async {
    await syncRemoteContent();
    final videos = <ShadowingVideo>[];
    if (page == 1) videos.addAll(getCloudVideosForLevel(level));
    for (final v in getCuratedYoutubeVideos(level)) {
      if (!videos.any((x) => x.youtubeId == v.youtubeId && v.youtubeId.isNotEmpty)) videos.add(v);
    }
    return videos;
  }

  Future<List<SubtitleCue>> loadAndTranslateSubtitles(ShadowingVideo video) async {
    if (video.cues.isNotEmpty) {
      for (final c in video.cues) { if (c.words.isEmpty) c.words = buildProportionalWordTimings(c.en, c.startMs, c.endMs); }
      return video.cues;
    }
    List<SubtitleCue> cues = [];
    if (video.subtitleUrl.isNotEmpty) {
      try {
        final res = await http.get(Uri.parse(video.subtitleUrl), headers: const {'User-Agent': 'VoxlinguaApp/1.0'}).timeout(const Duration(seconds: 8));
        if (res.statusCode == 200) cues = parseSrtOrVtt(utf8.decode(res.bodyBytes, allowMalformed: true));
      } catch (_) {}
    } else if (video.isYouTube) {
      cues = await _fetchYoutubeCaptionsDirect(video.youtubeId);
    }
    for (int i = 0; i < cues.length && i < 4; i++) {
      cues[i].ar = await translateToArabic(cues[i].en).catchError((_) => '');
    }
    video.cues = cues;
    return cues;
  }

  Future<void> translateRemainingCues(List<SubtitleCue> cues, {VoidCallback? onLineReady}) async {
    for (int i = 4; i < cues.length; i++) {
      if (cues[i].ar.isEmpty) {
        cues[i].ar = await translateToArabic(cues[i].en).catchError((_) => '');
        onLineReady?.call();
      }
    }
  }
}