// lib/services/api_service.dart
// Voxlingua - ApiService (متوافق مع باقي ملفات المشروع الحالية)

import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../data/fallback_data.dart';
import '../models/app_models.dart';
import 'storage_service.dart';

/// معلومات تحديث التطبيق القادمة من ملف JSON السحابي (مفتاح "update").
/// يستخدمها main.dart عبر: update.force / update.version / update.notes / update.apkUrl
class AppUpdateInfo {
  final String version;
  final bool force;
  final String notes;
  final String apkUrl;

  const AppUpdateInfo({
    required this.version,
    required this.apkUrl,
    this.force = false,
    this.notes = '',
  });
}

class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();

  /// نسخة التطبيق الحالية (طابق قيمة version في pubspec.yaml بدون رقم البناء).
  static const String currentAppVersion = '1.0.0';

  static const Map<String, String> _browserHeaders = <String, String>{
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
    'Cookie': 'CONSENT=YES+1; SOCS=CAI',
  };

  static const Duration _timeout = Duration(seconds: 15);

  final Map<String, String> _translationCache = <String, String>{};
  final Map<String, List<SubtitleCue>> _captionCache =
      <String, List<SubtitleCue>>{};
  final Random _rng = Random();

  Map<String, dynamic> _remoteData = <String, dynamic>{};
  bool _cacheLoaded = false;
  DateTime? _lastSync;
  String _lastSentenceId = '';

  // ---------------------------------------------------------------------------
  // أدوات مساعدة
  // ---------------------------------------------------------------------------
  static String _norm(String s) => s.trim().toUpperCase();

  static bool _asBool(dynamic v) {
    if (v is bool) return v;
    final String s = (v ?? '').toString().trim().toLowerCase();
    return s == 'true' || s == '1' || s == 'yes';
  }

  static int _compareVersions(String a, String b) {
    List<int> parse(String v) => v
        .split('+')
        .first
        .split('.')
        .map((String p) => int.tryParse(p.trim()) ?? 0)
        .toList();
    final List<int> pa = parse(a);
    final List<int> pb = parse(b);
    final int n = max(pa.length, pb.length);
    for (int i = 0; i < n; i++) {
      final int x = i < pa.length ? pa[i] : 0;
      final int y = i < pb.length ? pb[i] : 0;
      if (x != y) return x < y ? -1 : 1;
    }
    return 0;
  }

  static String _unescapeHtml(String s) {
    return s
        .replaceAll('&quot;', '"')
        .replaceAll('&#39;', "'")
        .replaceAll('&apos;', "'")
        .replaceAll('&lt;', '<')
        .replaceAll('&gt;', '>')
        .replaceAll('&amp;', '&');
  }

  // ---------------------------------------------------------------------------
  // المزامنة السحابية
  // ---------------------------------------------------------------------------
  void _ensureCacheLoaded() {
    if (_cacheLoaded) return;
    _cacheLoaded = true;
    try {
      final String? raw = StorageService.instance.getRemoteContentCache();
      if (raw != null && raw.isNotEmpty) {
        final dynamic decoded = jsonDecode(raw);
        if (decoded is Map) {
          _remoteData = Map<String, dynamic>.from(decoded);
        }
      }
    } catch (e) {
      debugPrint('ApiService._ensureCacheLoaded error: $e');
    }
  }

  /// يزامن المحتوى من السحابة. يعيد true عند توفر محتوى سحابي حديث.
  /// عند الفشل يبقى آخر محتوى مخزّن محلياً قيد الاستخدام ويعيد false.
  Future<bool> syncRemoteContent({bool force = false}) async {
    _ensureCacheLoaded();
    final DateTime now = DateTime.now();
    if (!force &&
        _remoteData.isNotEmpty &&
        _lastSync != null &&
        now.difference(_lastSync!) < const Duration(minutes: 10)) {
      return true;
    }
    try {
      final String url = StorageService.instance.remoteJsonUrl.trim();
      if (url.isEmpty) return false;
      Uri uri = Uri.parse(url);
      if (force) {
        uri = uri.replace(queryParameters: <String, String>{
          ...uri.queryParameters,
          't': now.millisecondsSinceEpoch.toString(),
        });
      }
      final http.Response res = await http.get(uri).timeout(_timeout);
      if (res.statusCode != 200) return false;
      final String body = utf8.decode(res.bodyBytes);
      final dynamic decoded = jsonDecode(body);
      if (decoded is! Map) return false;
      _remoteData = Map<String, dynamic>.from(decoded);
      _lastSync = now;
      await StorageService.instance.saveRemoteContentCache(body);
      return true;
    } catch (e) {
      debugPrint('ApiService.syncRemoteContent error: $e');
      return false;
    }
  }

  /// يعيد معلومات التحديث إن كانت نسخة السحابة أحدث من نسخة التطبيق، وإلا null.
  AppUpdateInfo? checkPendingUpdate() {
    _ensureCacheLoaded();
    final dynamic raw = _remoteData['update'];
    if (raw is! Map) return null;
    final String version = (raw['version'] ?? '').toString().trim();
    final String apkUrl =
        (raw['apkUrl'] ?? raw['apk_url'] ?? raw['url'] ?? '').toString().trim();
    if (version.isEmpty || apkUrl.isEmpty) return null;
    if (_compareVersions(version, currentAppVersion) <= 0) return null;
    return AppUpdateInfo(
      version: version,
      apkUrl: apkUrl,
      force: _asBool(raw['force']),
      notes: (raw['notes'] ?? '').toString(),
    );
  }

  /// نسخة عميقة وقابلة للتعديل من خريطة المحتوى السحابي الحالية
  /// (المفاتيح المتوقعة: videos و lessons و update).
  Map<String, dynamic> getCurrentCloudMapSnapshot() {
    _ensureCacheLoaded();
    if (_remoteData.isEmpty) {
      return <String, dynamic>{
        'videos': <dynamic>[],
        'lessons': <String, dynamic>{},
      };
    }
    final dynamic copy = jsonDecode(jsonEncode(_remoteData));
    return Map<String, dynamic>.from(copy as Map);
  }

  // ---------------------------------------------------------------------------
  // فيديوهات التظليل
  // ---------------------------------------------------------------------------
  List<ShadowingVideo> _remoteVideos(String level) {
    final dynamic raw = _remoteData['videos'];
    final List<ShadowingVideo> out = <ShadowingVideo>[];

    void addOne(dynamic m, String? levelHint) {
      if (m is! Map) return;
      try {
        final Map<String, dynamic> j = Map<String, dynamic>.from(m);
        if (levelHint != null && (j['level'] ?? '').toString().isEmpty) {
          j['level'] = levelHint;
        }
        final ShadowingVideo v = ShadowingVideo.fromJson(j);
        if (_norm(v.level) == _norm(level)) out.add(v);
      } catch (e) {
        debugPrint('ApiService._remoteVideos skip item: $e');
      }
    }

    if (raw is List) {
      for (final dynamic m in raw) {
        addOne(m, null);
      }
    } else if (raw is Map) {
      raw.forEach((dynamic k, dynamic v) {
        if (v is List) {
          for (final dynamic m in v) {
            addOne(m, k.toString());
          }
        }
      });
    }
    return out;
  }

  Future<List<ShadowingVideo>> fetchShadowingVideos(
    String level, {
    bool forceRefresh = false,
  }) async {
    await syncRemoteContent(force: forceRefresh);
    final List<ShadowingVideo> result = _remoteVideos(level);
    final Set<String> ids = result.map((ShadowingVideo v) => v.id).toSet();
    for (final ShadowingVideo v in getCuratedYoutubeVideos(level)) {
      if (ids.add(v.id)) result.add(v);
    }
    return result;
  }

  // ---------------------------------------------------------------------------
  // المفردات والجمل
  // ---------------------------------------------------------------------------
  List<LevelVocabItem> _levelPool(String level) {
    final String key = _norm(level);
    final List<LevelVocabItem> pool = <LevelVocabItem>[];
    final Set<String> seen = <String>{};

    final dynamic lessons = _remoteData['lessons'];
    if (lessons is Map) {
      dynamic list;
      lessons.forEach((dynamic k, dynamic v) {
        if (_norm(k.toString()) == key) list = v;
      });
      if (list is List) {
        for (final dynamic m in list) {
          if (m is! Map) continue;
          try {
            final LevelVocabItem item =
                LevelVocabItem.fromJson(Map<String, dynamic>.from(m));
            if (item.word.isNotEmpty && seen.add(item.word.toLowerCase())) {
              pool.add(item);
            }
          } catch (e) {
            debugPrint('ApiService._levelPool skip item: $e');
          }
        }
      }
    }

    final List<LevelVocabItem> local =
        fallbackLevelData[key] ?? const <LevelVocabItem>[];
    for (final LevelVocabItem item in local) {
      if (seen.add(item.word.toLowerCase())) pool.add(item);
    }
    return pool;
  }

  /// يعيد دفعة من مفردات المستوى. [page] يبدأ من 0 و [count] حجم الدفعة.
  /// عند انتهاء المفردات المتاحة تُعاد دفعة عشوائية جديدة ليبقى زر "المزيد" فعّالاً.
  Future<List<LevelVocabItem>> fetchDynamicLevelItems(
    String level, [
    int page = 0,
    int count = 6,
  ]) async {
    await syncRemoteContent();
    final List<LevelVocabItem> pool = _levelPool(level);
    if (pool.isEmpty) return <LevelVocabItem>[];
    final int start = (page < 0 ? 0 : page) * count;
    if (start < pool.length) {
      final int end = min(start + count, pool.length);
      return pool.sublist(start, end);
    }
    final List<LevelVocabItem> shuffled = List<LevelVocabItem>.from(pool)
      ..shuffle(_rng);
    return shuffled.take(count).toList();
  }

  List<SentenceItem> _remoteSentences() {
    final List<SentenceItem> out = <SentenceItem>[];
    final dynamic raw = _remoteData['sentences'];
    if (raw is List) {
      for (final dynamic m in raw) {
        if (m is! Map) continue;
        final String en = (m['en'] ?? '').toString();
        if (en.isEmpty) continue;
        out.add(SentenceItem(
          id: (m['id'] ?? 'r_${en.hashCode}').toString(),
          level: (m['level'] ?? 'B1').toString(),
          en: en,
          ar: (m['ar'] ?? '').toString(),
        ));
      }
    }
    return out;
  }

  Future<SentenceItem> fetchUnlimitedSentence({String? preferredLevel}) async {
    await syncRemoteContent();
    final List<SentenceItem> all = <SentenceItem>[
      ...fallbackDailySentences,
      ..._remoteSentences(),
    ];
    List<SentenceItem> pool = all;
    if (preferredLevel != null && preferredLevel.isNotEmpty) {
      final List<SentenceItem> filtered = all
          .where((SentenceItem s) => _norm(s.level) == _norm(preferredLevel))
          .toList();
      if (filtered.isNotEmpty) pool = filtered;
    }
    if (pool.length > 1) {
      final List<SentenceItem> withoutLast =
          pool.where((SentenceItem s) => s.id != _lastSentenceId).toList();
      if (withoutLast.isNotEmpty) pool = withoutLast;
    }
    final SentenceItem picked = pool[_rng.nextInt(pool.length)];
    _lastSentenceId = picked.id;
    return picked;
  }

  Future<LevelVocabItem> fetchUnlimitedWord(String level) async {
    await syncRemoteContent();
    List<LevelVocabItem> pool = _levelPool(level);
    if (pool.isEmpty) pool = _levelPool('B1');
    if (pool.isEmpty) {
      return const LevelVocabItem(
        word: 'practice',
        phonetic: '/ˈpræktɪs/',
        ar: 'تدريب',
        en: 'Practice makes perfect.',
        enAr: 'الممارسة تصنع الإتقان.',
      );
    }
    return pool[_rng.nextInt(pool.length)];
  }

  // ---------------------------------------------------------------------------
  // الترجمة إلى العربية (MyMemory)
  // ---------------------------------------------------------------------------
  Future<String> translateToArabic(String text) async {
    final String clean = text.trim();
    if (clean.isEmpty) return '';
    final String? cached = _translationCache[clean];
    if (cached != null) return cached;
    try {
      final String q = clean.length > 480 ? clean.substring(0, 480) : clean;
      final Uri uri = Uri.https(
        'api.mymemory.translated.net',
        '/get',
        <String, String>{'q': q, 'langpair': 'en|ar'},
      );
      final http.Response res = await http.get(uri).timeout(_timeout);
      if (res.statusCode == 200) {
        final dynamic body = jsonDecode(utf8.decode(res.bodyBytes));
        if (body is Map && body['responseData'] is Map) {
          final String t = _unescapeHtml(
              (body['responseData']['translatedText'] ?? '').toString().trim());
          if (t.isNotEmpty && !t.toUpperCase().contains('MYMEMORY WARNING')) {
            _translationCache[clean] = t;
            return t;
          }
        }
      }
    } catch (e) {
      debugPrint('ApiService.translateToArabic error: $e');
    }
    return '';
  }

  // ---------------------------------------------------------------------------
  // القاموس (Free Dictionary API)
  // ---------------------------------------------------------------------------
  Future<WordLookup> lookupWord(String rawWord) async {
    final String word =
        rawWord.toLowerCase().replaceAll(RegExp(r"[^a-z'\-]"), '').trim();
    if (word.isEmpty) {
      throw Exception('Empty word');
    }

    String phonetic = '';
    String example = '';
    try {
      final http.Response res = await http
          .get(Uri.parse('https://api.dictionaryapi.dev/api/v2/entries/en/$word'))
          .timeout(_timeout);
      if (res.statusCode == 200) {
        final dynamic body = jsonDecode(utf8.decode(res.bodyBytes));
        if (body is List && body.isNotEmpty && body.first is Map) {
          final Map<dynamic, dynamic> entry = body.first as Map;
          phonetic = (entry['phonetic'] ?? '').toString();
          if (phonetic.isEmpty && entry['phonetics'] is List) {
            for (final dynamic p in entry['phonetics'] as List) {
              if (p is Map && (p['text'] ?? '').toString().isNotEmpty) {
                phonetic = p['text'].toString();
                break;
              }
            }
          }
          example = _firstExample(entry['meanings']);
        }
      }
    } catch (e) {
      debugPrint('ApiService.lookupWord error: $e');
    }

    final String arabic = await translateToArabic(word);
    if (phonetic.isEmpty && example.isEmpty && arabic.isEmpty) {
      throw Exception('Word not found');
    }
    return WordLookup(
      word: word,
      phonetic: phonetic,
      arabic: arabic,
      example: example,
    );
  }

  String _firstExample(dynamic meanings) {
    if (meanings is! List) return '';
    for (final dynamic m in meanings) {
      if (m is! Map || m['definitions'] is! List) continue;
      for (final dynamic d in m['definitions'] as List) {
        if (d is Map) {
          final String ex = (d['example'] ?? '').toString().trim();
          if (ex.isNotEmpty) return ex;
        }
      }
    }
    return '';
  }

  // ---------------------------------------------------------------------------
  // توقيت الكلمات
  // ---------------------------------------------------------------------------
  static List<WordTiming> buildProportionalWordTimings(
    String text,
    int startMs,
    int endMs,
  ) {
    final List<String> words =
        text.split(RegExp(r'\s+')).where((String w) => w.isNotEmpty).toList();
    if (words.isEmpty) return <WordTiming>[];
    final int total = max(endMs - startMs, words.length);
    int totalWeight = 0;
    for (final String w in words) {
      totalWeight += w.length + 1;
    }
    final List<WordTiming> out = <WordTiming>[];
    int cursor = startMs;
    for (int i = 0; i < words.length; i++) {
      final int span = (total * (words[i].length + 1) / totalWeight).round();
      final int end = i == words.length - 1 ? startMs + total : cursor + span;
      out.add(WordTiming(word: words[i], startMs: cursor, endMs: end));
      cursor = end;
    }
    return out;
  }

  // ---------------------------------------------------------------------------
  // SRT / VTT
  // ---------------------------------------------------------------------------
  static List<SubtitleCue> parseSrtOrVtt(String raw) {
    final List<SubtitleCue> cues = <SubtitleCue>[];
    final String normalized =
        raw.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    final List<String> blocks = normalized.split(RegExp(r'\n\s*\n'));
    final RegExp timeRe = RegExp(
      r'(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[.,](\d{1,3})\s*-->\s*'
      r'(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[.,](\d{1,3})',
    );

    int toMs(String? h, String m, String s, String ms) {
      final int hh = int.tryParse(h ?? '0') ?? 0;
      final int mm = int.tryParse(m) ?? 0;
      final int ss = int.tryParse(s) ?? 0;
      final int mmm = int.tryParse(ms.padRight(3, '0')) ?? 0;
      return ((hh * 60 + mm) * 60 + ss) * 1000 + mmm;
    }

    for (final String block in blocks) {
      final List<String> lines = block.split('\n');
      int timeIdx = -1;
      RegExpMatch? match;
      for (int i = 0; i < lines.length; i++) {
        final RegExpMatch? m = timeRe.firstMatch(lines[i]);
        if (m != null) {
          timeIdx = i;
          match = m;
          break;
        }
      }
      if (match == null) continue;
      final int start =
          toMs(match.group(1), match.group(2)!, match.group(3)!, match.group(4)!);
      final int end =
          toMs(match.group(5), match.group(6)!, match.group(7)!, match.group(8)!);
      final String text = _unescapeHtml(lines
          .sublist(timeIdx + 1)
          .join(' ')
          .replaceAll(RegExp(r'<[^>]*>'), '')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim());
      if (text.isEmpty) continue;
      cues.add(SubtitleCue(
        startMs: start,
        endMs: end,
        en: text,
        ar: '',
        words: buildProportionalWordTimings(text, start, end),
      ));
    }
    return cues;
  }

  // ---------------------------------------------------------------------------
  // ترجمة يوتيوب (رسمية ثم تلقائية asr ثم timedtext)
  // ---------------------------------------------------------------------------
  Future<List<SubtitleCue>> fetchYoutubeCaptions(String videoId) async {
    final String id = videoId.trim();
    if (id.isEmpty) return <SubtitleCue>[];
    final List<SubtitleCue>? cached = _captionCache[id];
    if (cached != null && cached.isNotEmpty) return cached;

    List<SubtitleCue> cues = <SubtitleCue>[];

    // 1) من صفحة الفيديو: captionTracks
    try {
      final http.Response page = await http
          .get(
            Uri.parse('https://www.youtube.com/watch?v=$id&hl=en'),
            headers: _browserHeaders,
          )
          .timeout(_timeout);
      if (page.statusCode == 200) {
        final String html = utf8.decode(page.bodyBytes, allowMalformed: true);
        final String? tracksJson = _extractCaptionTracksJson(html);
        if (tracksJson != null) {
          final dynamic decoded = jsonDecode(tracksJson);
          if (decoded is List) {
            final List<Map<String, dynamic>> tracks = decoded
                .whereType<Map>()
                .map((Map m) => Map<String, dynamic>.from(m))
                .toList();
            cues = await _fetchFromTracks(tracks);
          }
        }
      }
    } catch (e) {
      debugPrint('ApiService.fetchYoutubeCaptions(page) error: $e');
    }

    // 2) مسار احتياطي: timedtext
    if (cues.isEmpty) {
      final List<String> urls = <String>[
        'https://www.youtube.com/api/timedtext?v=$id&lang=en&fmt=json3',
        'https://www.youtube.com/api/timedtext?v=$id&lang=en&kind=asr&fmt=json3',
      ];
      for (final String u in urls) {
        cues = await _fetchJson3(Uri.parse(u));
        if (cues.isNotEmpty) break;
      }
    }

    if (cues.isNotEmpty) _captionCache[id] = cues;
    return cues;
  }

  Future<List<SubtitleCue>> _fetchFromTracks(
      List<Map<String, dynamic>> tracks) async {
    bool isEnglish(Map<String, dynamic> t) =>
        (t['languageCode'] ?? '').toString().startsWith('en');

    Map<String, dynamic>? chosen;
    for (final Map<String, dynamic> t in tracks) {
      if (isEnglish(t) && t['kind'] != 'asr') {
        chosen = t;
        break;
      }
    }
    if (chosen == null) {
      for (final Map<String, dynamic> t in tracks) {
        if (isEnglish(t) && t['kind'] == 'asr') {
          chosen = t;
          break;
        }
      }
    }

    if (chosen != null) {
      final Uri? uri = _json3Uri((chosen['baseUrl'] ?? '').toString(), null);
      if (uri != null) {
        final List<SubtitleCue> r = await _fetchJson3(uri);
        if (r.isNotEmpty) return r;
      }
    }

    // بديل أخير: أي مسار قابل للترجمة الآلية إلى الإنجليزية
    for (final Map<String, dynamic> t in tracks) {
      if (t['isTranslatable'] == true) {
        final Uri? uri = _json3Uri((t['baseUrl'] ?? '').toString(), 'en');
        if (uri != null) {
          final List<SubtitleCue> r = await _fetchJson3(uri);
          if (r.isNotEmpty) return r;
        }
        break;
      }
    }
    return <SubtitleCue>[];
  }

  Uri? _json3Uri(String baseUrl, String? tlang) {
    if (baseUrl.isEmpty) return null;
    try {
      final Uri u = Uri.parse(baseUrl);
      final Map<String, String> q = Map<String, String>.from(u.queryParameters);
      q['fmt'] = 'json3';
      if (tlang != null) q['tlang'] = tlang;
      return u.replace(queryParameters: q);
    } catch (e) {
      debugPrint('ApiService._json3Uri error: $e');
      return null;
    }
  }

  Future<List<SubtitleCue>> _fetchJson3(Uri uri) async {
    try {
      final http.Response r =
          await http.get(uri, headers: _browserHeaders).timeout(_timeout);
      if (r.statusCode == 200 && r.bodyBytes.isNotEmpty) {
        return _parseYoutubeJson3(utf8.decode(r.bodyBytes, allowMalformed: true));
      }
    } catch (e) {
      debugPrint('ApiService._fetchJson3 error: $e');
    }
    return <SubtitleCue>[];
  }

  /// يستخرج مصفوفة captionTracks من كود الصفحة بمطابقة الأقواس.
  String? _extractCaptionTracksJson(String html) {
    const String key = '"captionTracks":';
    final int idx = html.indexOf(key);
    if (idx < 0) return null;
    final int start = html.indexOf('[', idx + key.length);
    if (start < 0) return null;
    int depth = 0;
    bool inString = false;
    bool escaped = false;
    for (int i = start; i < html.length; i++) {
      final String c = html[i];
      if (inString) {
        if (escaped) {
          escaped = false;
        } else if (c == '\\') {
          escaped = true;
        } else if (c == '"') {
          inString = false;
        }
        continue;
      }
      if (c == '"') {
        inString = true;
      } else if (c == '[') {
        depth++;
      } else if (c == ']') {
        depth--;
        if (depth == 0) return html.substring(start, i + 1);
      }
    }
    return null;
  }

  List<SubtitleCue> _parseYoutubeJson3(String body) {
    final List<SubtitleCue> cues = <SubtitleCue>[];
    try {
      final dynamic decoded = jsonDecode(body);
      if (decoded is! Map || decoded['events'] is! List) return cues;
      for (final dynamic ev in decoded['events'] as List) {
        if (ev is! Map || ev['segs'] is! List) continue;
        final int startMs = (ev['tStartMs'] as num?)?.toInt() ?? 0;
        final int durMs = (ev['dDurationMs'] as num?)?.toInt() ?? 0;
        final int endMs = durMs > 0 ? startMs + durMs : startMs + 1500;

        final List<String> texts = <String>[];
        final List<int> starts = <int>[];

        for (final dynamic seg in ev['segs'] as List) {
          if (seg is! Map) continue;
          final String t = (seg['utf8'] ?? '')
              .toString()
              .replaceAll('\n', ' ')
              .trim();
          if (t.isEmpty) continue;
          final int offset = (seg['tOffsetMs'] as num?)?.toInt() ?? 0;
          texts.add(t);
          starts.add(startMs + offset);
        }
        if (texts.isEmpty) continue;

        final String text = _unescapeHtml(
            texts.join(' ').replaceAll(RegExp(r'\s+'), ' ').trim());

        final List<WordTiming> words = <WordTiming>[];
        for (int i = 0; i < texts.length; i++) {
          final int s = starts[i];
          final int e = i + 1 < texts.length
              ? starts[i + 1]
              : (endMs > s ? endMs : s + 300);
          words.addAll(buildProportionalWordTimings(texts[i], s, e));
        }

        cues.add(SubtitleCue(
          startMs: startMs,
          endMs: endMs,
          en: text,
          ar: '',
          words: words.isNotEmpty
              ? words
              : buildProportionalWordTimings(text, startMs, endMs),
        ));
      }
    } catch (e) {
      debugPrint('ApiService._parseYoutubeJson3 error: $e');
    }
    return cues;
  }

  Future<List<SubtitleCue>> _downloadSubtitleFile(String url) async {
    try {
      final http.Response r =
          await http.get(Uri.parse(url), headers: _browserHeaders).timeout(_timeout);
      if (r.statusCode == 200) {
        return parseSrtOrVtt(utf8.decode(r.bodyBytes, allowMalformed: true));
      }
    } catch (e) {
      debugPrint('ApiService._downloadSubtitleFile error: $e');
    }
    return <SubtitleCue>[];
  }

  // ---------------------------------------------------------------------------
  // تحميل وترجمة الترجمات
  // ---------------------------------------------------------------------------
  Future<void> _translateCue(SubtitleCue cue) async {
    final String t = await translateToArabic(cue.en);
    if (t.isNotEmpty) cue.ar = t;
  }

  /// يحمّل ترجمة الفيديو (من الفيديو نفسه أو SRT مخصص أو يوتيوب أو subtitleUrl)،
  /// يضعها في video.cues، ويترجم أول بضعة أسطر فوراً. الباقي عبر translateRemainingCues.
  Future<List<SubtitleCue>> loadAndTranslateSubtitles(
    ShadowingVideo video, {
    String? customSrt,
  }) async {
    List<SubtitleCue> cues = video.cues;

    if (customSrt != null && customSrt.trim().isNotEmpty) {
      cues = parseSrtOrVtt(customSrt);
    } else if (cues.isEmpty) {
      if (video.youtubeId.isNotEmpty) {
        cues = await fetchYoutubeCaptions(video.youtubeId);
      } else if (video.subtitleUrl.isNotEmpty) {
        cues = await _downloadSubtitleFile(video.subtitleUrl);
      }
    }

    for (final SubtitleCue cue in cues) {
      if (cue.words.isEmpty) {
        cue.words = buildProportionalWordTimings(cue.en, cue.startMs, cue.endMs);
      }
    }

    video.cues = cues;

    final List<SubtitleCue> firstBatch = cues
        .where((SubtitleCue c) => c.ar.trim().isEmpty)
        .take(4)
        .toList();
    if (firstBatch.isNotEmpty) {
      await Future.wait<void>(firstBatch.map(_translateCue));
    }
    return cues;
  }

  /// يترجم الأسطر التي ليس لها ترجمة عربية بعد (بالتتابع) ويستدعي [onLineReady]
  /// بعد كل سطر. يتوقف مبكراً إذا تعذرت الترجمة (مثلاً تجاوز حد MyMemory اليومي).
  Future<void> translateRemainingCues(
    List<SubtitleCue> cues, {
    int maxCount = 25,
    VoidCallback? onLineReady,
  }) async {
    int done = 0;
    int failures = 0;
    for (final SubtitleCue cue in cues) {
      if (done >= maxCount || failures >= 3) break;
      if (cue.ar.trim().isNotEmpty) continue;
      await _translateCue(cue);
      done++;
      if (cue.ar.trim().isNotEmpty) {
        failures = 0;
        onLineReady?.call();
      } else {
        failures++;
      }
    }
  }
}
