// lib/services/api_service.dart
// Voxlingua - ApiService
//
// ملاحظة: الاستيرادات وأسماء الحقول في النماذج أدناه مبنية على افتراضات
// (راجع قسم "الافتراضات" في رد المساعد). عدّل المسارات إن اختلفت عندك.

import 'dart:async';
import 'dart:convert';
import 'dart:math';

import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;

import '../data/fallback_data.dart';
import '../models/models.dart';
import 'storage_service.dart';

class ApiService {
  ApiService._();
  static final ApiService instance = ApiService._();
  factory ApiService() => instance;

  // ---------------------------------------------------------------------------
  // ثوابت وكاش
  // ---------------------------------------------------------------------------
  static const Map<String, String> _browserHeaders = <String, String>{
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 '
            '(KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
    'Accept':
        'text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8',
  };

  static const Duration _timeout = Duration(seconds: 15);

  final Map<String, String> _translationCache = <String, String>{};
  final Map<String, List<SubtitleCue>> _captionCache =
      <String, List<SubtitleCue>>{};
  final Random _rng = Random();

  Map<String, dynamic> _remoteData = <String, dynamic>{};
  String _remoteVersion = '';
  String _pendingVersion = '';
  DateTime? _lastSync;

  // ---------------------------------------------------------------------------
  // المزامنة السحابية
  // ---------------------------------------------------------------------------
  Future<Map<String, dynamic>?> _downloadRemoteJson() async {
    try {
      final String url = StorageService.instance.remoteJsonUrl;
      if (url.isEmpty) return null;
      final http.Response res =
          await http.get(Uri.parse(url)).timeout(_timeout);
      if (res.statusCode != 200) return null;
      final dynamic decoded = jsonDecode(utf8.decode(res.bodyBytes));
      if (decoded is Map<String, dynamic>) return decoded;
    } catch (e) {
      debugPrint('ApiService._downloadRemoteJson error: $e');
    }
    return null;
  }

  /// يزامن المحتوى من السحابة. يعيد true إذا تم تحميل بيانات جديدة.
  Future<bool> syncRemoteContent({bool force = false}) async {
    final DateTime now = DateTime.now();
    if (!force &&
        _remoteData.isNotEmpty &&
        _lastSync != null &&
        now.difference(_lastSync!) < const Duration(minutes: 10)) {
      return false;
    }
    final Map<String, dynamic>? data = await _downloadRemoteJson();
    if (data == null) return false;
    _remoteData = data;
    _remoteVersion = (data['version'] ?? '').toString();
    _pendingVersion = '';
    _lastSync = now;
    return true;
  }

  /// يتحقق من وجود تحديث معلّق دون تطبيقه.
  Future<bool> checkPendingUpdate() async {
    final Map<String, dynamic>? data = await _downloadRemoteJson();
    if (data == null) return false;
    final String v = (data['version'] ?? '').toString();
    if (v.isNotEmpty && v != _remoteVersion) {
      _pendingVersion = v;
      return true;
    }
    _pendingVersion = '';
    return false;
  }

  /// لقطة من حالة الخريطة السحابية الحالية.
  Map<String, dynamic> getCurrentCloudMapSnapshot() {
    return <String, dynamic>{
      'version': _remoteVersion,
      'pendingVersion': _pendingVersion,
      'lastSync': _lastSync?.toIso8601String(),
      'hasData': _remoteData.isNotEmpty,
      'videoLevels': _levelKeys('videos'),
      'vocabLevels': _levelKeys('vocab'),
    };
  }

  List<String> _levelKeys(String section) {
    final dynamic s = _remoteData[section];
    if (s is Map) return s.keys.map((dynamic k) => k.toString()).toList();
    return <String>[];
  }

  List<Map<String, dynamic>> _remoteList(String section, String level) {
    final dynamic s = _remoteData[section];
    if (s is Map && s[level] is List) {
      return (s[level] as List)
          .whereType<Map>()
          .map((Map m) => Map<String, dynamic>.from(m))
          .toList();
    }
    return <Map<String, dynamic>>[];
  }

  // ---------------------------------------------------------------------------
  // فيديوهات التظليل والمفردات
  // ---------------------------------------------------------------------------
  Future<List<ShadowingVideo>> fetchShadowingVideos(
    String level, {
    bool forceRefresh = false,
  }) async {
    await syncRemoteContent(force: forceRefresh);
    final List<ShadowingVideo> result = _remoteList('videos', level)
        .map((Map<String, dynamic> m) => ShadowingVideo.fromJson(m))
        .toList();
    if (result.isNotEmpty) return result;
    return List<ShadowingVideo>.from(FallbackData.videosFor(level));
  }

  Future<List<LevelVocabItem>> fetchDynamicLevelItems(
    String level, {
    int count = 6,
  }) async {
    await syncRemoteContent();
    List<LevelVocabItem> pool = _remoteList('vocab', level)
        .map((Map<String, dynamic> m) => LevelVocabItem.fromJson(m))
        .toList();
    if (pool.isEmpty) {
      pool = List<LevelVocabItem>.from(FallbackData.wordsFor(level));
    }
    pool.shuffle(_rng);
    return pool.take(count).toList();
  }

  Future<SentenceItem> fetchUnlimitedSentence({String? preferredLevel}) async {
    final List<SentenceItem> all = FallbackData.sentences;
    List<SentenceItem> pool = all;
    if (preferredLevel != null) {
      final List<SentenceItem> filtered = all
          .where((SentenceItem s) => s.level == preferredLevel)
          .toList();
      if (filtered.isNotEmpty) pool = filtered;
    }
    return pool[_rng.nextInt(pool.length)];
  }

  Future<LevelVocabItem> fetchUnlimitedWord(String level) async {
    final List<LevelVocabItem> pool = FallbackData.wordsFor(level);
    return pool[_rng.nextInt(pool.length)];
  }

  // ---------------------------------------------------------------------------
  // الترجمة
  // ---------------------------------------------------------------------------
  Future<String> translateToArabic(String text) async {
    final String clean = text.trim();
    if (clean.isEmpty) return '';
    final String? cached = _translationCache[clean];
    if (cached != null) return cached;
    try {
      final Uri uri = Uri.https(
        'api.mymemory.translated.net',
        '/get',
        <String, String>{'q': clean, 'langpair': 'en|ar'},
      );
      final http.Response res = await http.get(uri).timeout(_timeout);
      if (res.statusCode == 200) {
        final dynamic body = jsonDecode(utf8.decode(res.bodyBytes));
        if (body is Map && body['responseData'] is Map) {
          final String t =
              (body['responseData']['translatedText'] ?? '').toString().trim();
          if (t.isNotEmpty && !t.toUpperCase().contains('MYMEMORY WARNING')) {
            _translationCache[clean] = t;
            return t;
          }
        }
      }
    } catch (e) {
      debugPrint('ApiService.translateToArabic error: $e');
    }
    return '';
  }

  // ---------------------------------------------------------------------------
  // القاموس
  // ---------------------------------------------------------------------------
  Future<WordLookup> lookupWord(String rawWord) async {
    final String word = rawWord
        .toLowerCase()
        .replaceAll(RegExp(r"[^a-z'\-]"), '')
        .trim();
    String phonetic = '';
    String example = '';
    if (word.isNotEmpty) {
      try {
        final http.Response res = await http
            .get(Uri.parse(
                'https://api.dictionaryapi.dev/api/v2/entries/en/$word'))
            .timeout(_timeout);
        if (res.statusCode == 200) {
          final dynamic body = jsonDecode(utf8.decode(res.bodyBytes));
          if (body is List && body.isNotEmpty && body.first is Map) {
            final Map<dynamic, dynamic> entry = body.first as Map;
            phonetic = (entry['phonetic'] ?? '').toString();
            if (phonetic.isEmpty && entry['phonetics'] is List) {
              for (final dynamic p in entry['phonetics'] as List) {
                if (p is Map && (p['text'] ?? '').toString().isNotEmpty) {
                  phonetic = p['text'].toString();
                  break;
                }
              }
            }
            if (entry['meanings'] is List) {
              outer:
              for (final dynamic m in entry['meanings'] as List) {
                if (m is Map && m['definitions'] is List) {
                  for (final dynamic d in m['definitions'] as List) {
                    if (d is Map &&
                        (d['example'] ?? '').toString().isNotEmpty) {
                      example = d['example'].toString();
                      break outer;
                    }
                  }
                }
              }
            }
          }
        }
      } catch (e) {
        debugPrint('ApiService.lookupWord error: $e');
      }
    }
    final String arabic = await translateToArabic(word.isEmpty ? rawWord : word);
    final String exampleAr =
        example.isEmpty ? '' : await translateToArabic(example);
    return WordLookup(
      word: word.isEmpty ? rawWord : word,
      phonetic: phonetic,
      example: example,
      exampleAr: exampleAr,
      arabic: arabic,
    );
  }

  // ---------------------------------------------------------------------------
  // توقيت الكلمات
  // ---------------------------------------------------------------------------
  static List<WordTiming> buildProportionalWordTimings(
    String text,
    int startMs,
    int endMs,
  ) {
    final List<String> words =
        text.split(RegExp(r'\s+')).where((String w) => w.isNotEmpty).toList();
    if (words.isEmpty) return <WordTiming>[];
    final int total = max(endMs - startMs, words.length);
    int totalWeight = 0;
    for (final String w in words) {
      totalWeight += w.length + 1;
    }
    final List<WordTiming> out = <WordTiming>[];
    int cursor = startMs;
    for (int i = 0; i < words.length; i++) {
      final int span = (total * (words[i].length + 1) / totalWeight).round();
      final int end = i == words.length - 1 ? startMs + total : cursor + span;
      out.add(WordTiming(word: words[i], startMs: cursor, endMs: end));
      cursor = end;
    }
    return out;
  }

  // ---------------------------------------------------------------------------
  // SRT / VTT
  // ---------------------------------------------------------------------------
  List<SubtitleCue> parseSrtOrVtt(String raw) {
    final List<SubtitleCue> cues = <SubtitleCue>[];
    final String normalized = raw.replaceAll('\r\n', '\n').replaceAll('\r', '\n');
    final List<String> blocks = normalized.split(RegExp(r'\n\s*\n'));
    final RegExp timeRe = RegExp(
      r'(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[.,](\d{1,3})\s*-->\s*'
      r'(?:(\d{1,2}):)?(\d{1,2}):(\d{2})[.,](\d{1,3})',
    );
    int toMs(String? h, String m, String s, String ms) {
      final int hh = int.tryParse(h ?? '0') ?? 0;
      final int mm = int.tryParse(m) ?? 0;
      final int ss = int.tryParse(s) ?? 0;
      final int mmm = int.tryParse(ms.padRight(3, '0')) ?? 0;
      return ((hh * 60 + mm) * 60 + ss) * 1000 + mmm;
    }

    for (final String block in blocks) {
      final List<String> lines = block.split('\n');
      int timeIdx = -1;
      RegExpMatch? match;
      for (int i = 0; i < lines.length; i++) {
        final RegExpMatch? m = timeRe.firstMatch(lines[i]);
        if (m != null) {
          timeIdx = i;
          match = m;
          break;
        }
      }
      if (match == null) continue;
      final int start = toMs(match.group(1), match.group(2)!, match.group(3)!,
          match.group(4)!);
      final int end = toMs(match.group(5), match.group(6)!, match.group(7)!,
          match.group(8)!);
      final String text = lines
          .sublist(timeIdx + 1)
          .join(' ')
          .replaceAll(RegExp(r'<[^>]*>'), '')
          .replaceAll(RegExp(r'\s+'), ' ')
          .trim();
      if (text.isEmpty) continue;
      cues.add(SubtitleCue(
        startMs: start,
        endMs: end,
        en: text,
        ar: '',
        words: buildProportionalWordTimings(text, start, end),
      ));
    }
    return cues;
  }

  // ---------------------------------------------------------------------------
  // ترجمة يوتيوب
  // ---------------------------------------------------------------------------
  Future<List<SubtitleCue>> fetchYoutubeCaptions(String videoId) async {
    final List<SubtitleCue>? cached = _captionCache[videoId];
    if (cached != null && cached.isNotEmpty) return cached;

    List<SubtitleCue> cues = <SubtitleCue>[];

    // 1) من صفحة الفيديو
    try {
      final http.Response page = await http
          .get(
            Uri.parse('https://www.youtube.com/watch?v=$videoId&hl=en'),
            headers: _browserHeaders,
          )
          .timeout(_timeout);
      if (page.statusCode == 200) {
        final String html = utf8.decode(page.bodyBytes, allowMalformed: true);
        final String? tracksJson = _extractCaptionTracksJson(html);
        if (tracksJson != null) {
          final dynamic decoded = jsonDecode(tracksJson);
          if (decoded is List) {
            final List<Map<String, dynamic>> tracks = decoded
                .whereType<Map>()
                .map((Map m) => Map<String, dynamic>.from(m))
                .toList();
            Map<String, dynamic>? chosen;
            for (final Map<String, dynamic> t in tracks) {
              final String lang = (t['languageCode'] ?? '').toString();
              if (lang.startsWith('en') && t['kind'] != 'asr') {
                chosen = t;
                break;
              }
            }
            if (chosen == null) {
              for (final Map<String, dynamic> t in tracks) {
                final String lang = (t['languageCode'] ?? '').toString();
                if (lang.startsWith('en') && t['kind'] == 'asr') {
                  chosen = t;
                  break;
                }
              }
            }
            final String baseUrl = (chosen?['baseUrl'] ?? '').toString();
            if (baseUrl.isNotEmpty) {
              final String url = baseUrl.contains('fmt=')
                  ? baseUrl
                  : '$baseUrl&fmt=json3';
              final http.Response cap = await http
                  .get(Uri.parse(url), headers: _browserHeaders)
                  .timeout(_timeout);
              if (cap.statusCode == 200) {
                cues = _parseYoutubeJson3(
                    utf8.decode(cap.bodyBytes, allowMalformed: true));
              }
            }
          }
        }
      }
    } catch (e) {
      debugPrint('ApiService.fetchYoutubeCaptions(page) error: $e');
    }

    // 2) مسار احتياطي: timedtext
    if (cues.isEmpty) {
      final List<String> urls = <String>[
        'https://www.youtube.com/api/timedtext?v=$videoId&lang=en&fmt=json3',
        'https://www.youtube.com/api/timedtext?v=$videoId&lang=en&kind=asr&fmt=json3',
      ];
      for (final String u in urls) {
        try {
          final http.Response r = await http
              .get(Uri.parse(u), headers: _browserHeaders)
              .timeout(_timeout);
          if (r.statusCode == 200 && r.body.trim().isNotEmpty) {
            cues = _parseYoutubeJson3(
                utf8.decode(r.bodyBytes, allowMalformed: true));
            if (cues.isNotEmpty) break;
          }
        } catch (e) {
          debugPrint('ApiService.fetchYoutubeCaptions(timedtext) error: $e');
        }
      }
    }

    if (cues.isNotEmpty) _captionCache[videoId] = cues;
    return cues;
  }

  /// يستخرج مصفوفة captionTracks من كود الصفحة بمطابقة الأقواس.
  String? _extractCaptionTracksJson(String html) {
    const String key = '"captionTracks":';
    final int idx = html.indexOf(key);
    if (idx < 0) return null;
    final int start = html.indexOf('[', idx + key.length);
    if (start < 0) return null;
    int depth = 0;
    bool inString = false;
    bool escaped = false;
    for (int i = start; i < html.length; i++) {
      final String c = html[i];
      if (inString) {
        if (escaped) {
          escaped = false;
        } else if (c == '\\') {
          escaped = true;
        } else if (c == '"') {
          inString = false;
        }
        continue;
      }
      if (c == '"') {
        inString = true;
      } else if (c == '[') {
        depth++;
      } else if (c == ']') {
        depth--;
        if (depth == 0) return html.substring(start, i + 1);
      }
    }
    return null;
  }

  List<SubtitleCue> _parseYoutubeJson3(String body) {
    final List<SubtitleCue> cues = <SubtitleCue>[];
    try {
      final dynamic decoded = jsonDecode(body);
      if (decoded is! Map || decoded['events'] is! List) return cues;
      for (final dynamic ev in decoded['events'] as List) {
        if (ev is! Map || ev['segs'] is! List) continue;
        final int startMs = (ev['tStartMs'] as num?)?.toInt() ?? 0;
        final int durMs = (ev['dDurationMs'] as num?)?.toInt() ?? 0;
        final int endMs = startMs + durMs;

        final List<WordTiming> words = <WordTiming>[];
        final StringBuffer sb = StringBuffer();
        final List<Map<String, dynamic>> pieces = <Map<String, dynamic>>[];

        for (final dynamic seg in ev['segs'] as List) {
          if (seg is! Map) continue;
          final String t = (seg['utf8'] ?? '').toString().replaceAll('\n', ' ');
          final String trimmed = t.trim();
          if (trimmed.isEmpty) continue;
          final int offset = (seg['tOffsetMs'] as num?)?.toInt() ?? 0;
          pieces.add(<String, dynamic>{
            'text': trimmed,
            'start': startMs + offset,
          });
          sb.write('$trimmed ');
        }
        final String text = sb.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
        if (text.isEmpty) continue;

        for (int i = 0; i < pieces.length; i++) {
          final int s = pieces[i]['start'] as int;
          final int e = i + 1 < pieces.length
              ? pieces[i + 1]['start'] as int
              : (endMs > s ? endMs : s + 300);
          final String pt = pieces[i]['text'] as String;
          final List<String> parts =
              pt.split(RegExp(r'\s+')).where((String w) => w.isNotEmpty).toList();
          if (parts.length <= 1) {
            words.add(WordTiming(word: pt, startMs: s, endMs: e));
          } else {
            words.addAll(buildProportionalWordTimings(pt, s, e));
          }
        }

        cues.add(SubtitleCue(
          startMs: startMs,
          endMs: endMs > startMs ? endMs : startMs + 1500,
          en: text,
          ar: '',
          words: words.isNotEmpty
              ? words
              : buildProportionalWordTimings(text, startMs, endMs),
        ));
      }
    } catch (e) {
      debugPrint('ApiService._parseYoutubeJson3 error: $e');
    }
    return cues;
  }

  // ---------------------------------------------------------------------------
  // تحميل وترجمة الترجمات
  // ---------------------------------------------------------------------------
  Future<List<SubtitleCue>> loadAndTranslateSubtitles(
    String videoId, {
    String? customSrt,
  }) async {
    List<SubtitleCue> cues;
    if (customSrt != null && customSrt.trim().isNotEmpty) {
      cues = parseSrtOrVtt(customSrt);
    } else {
      cues = await fetchYoutubeCaptions(videoId);
    }
    if (cues.isEmpty) return cues;
    await translateRemainingCues(cues);
    return cues;
  }

  Future<void> translateRemainingCues(
    List<SubtitleCue> cues, {
    int maxCount = 25,
    VoidCallback? onProgress,
  }) async {
    int done = 0;
    for (final SubtitleCue cue in cues) {
      if (done >= maxCount) break;
      if (cue.ar.trim().isNotEmpty) continue;
      final String t = await translateToArabic(cue.en);
      if (t.isNotEmpty) {
        cue.ar = t;
        onProgress?.call();
      }
      done++;
    }
  }
}
