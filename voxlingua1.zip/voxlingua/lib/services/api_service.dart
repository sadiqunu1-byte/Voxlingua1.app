import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:http/http.dart' as http;
import '../data/fallback_data.dart';
import '../models/app_models.dart';
import 'storage_service.dart';

class AppUpdateInfo {
  final String version, apkUrl, notes;
  final int build;
  final bool force;
  const AppUpdateInfo({
    required this.version,
    required this.apkUrl,
    required this.notes,
    required this.build,
    required this.force,
  });
}

class ApiService {
  static final ApiService instance = ApiService._();
  ApiService._();

  static const int currentAppBuild = 1;
  static const String currentAppVersion = '1.0.0';

  final Map<String, String> _translationCache = {};
  final Set<String> _seenSentences = {};
  final Set<String> _seenWords = {};
  int _sentenceTurn = 0;
  Map<String, dynamic>? _remoteCacheMap;

  static const Map<String, String> _browserHeaders = {
    'User-Agent':
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36',
    'Accept-Language': 'en-US,en;q=0.9',
  };

  Future<bool> syncRemoteContent({bool force = false}) async {
    if (!force && _remoteCacheMap != null) return true;
    try {
      final base = StorageService.instance.remoteJsonUrl;
      final sep = base.contains('?') ? '&' : '?';
      final url = force ? '$base${sep}t=${DateTime.now().millisecondsSinceEpoch}' : base;
      final res = await http.get(Uri.parse(url)).timeout(const Duration(seconds: 10));
      if (res.statusCode == 200) {
        final body = utf8.decode(res.bodyBytes);
        final decoded = jsonDecode(body);
        if (decoded is Map<String, dynamic>) {
          _remoteCacheMap = decoded;
          await StorageService.instance.saveRemoteContentCache(body);
          return true;
        }
      }
    } catch (_) {}
    final cachedRaw = StorageService.instance.getRemoteContentCache();
    if (cachedRaw != null && cachedRaw.isNotEmpty) {
      try {
        final decoded = jsonDecode(cachedRaw);
        if (decoded is Map<String, dynamic>) _remoteCacheMap = decoded;
      } catch (_) {}
    }
    return false;
  }

  AppUpdateInfo? checkPendingUpdate() {
    final map = _remoteCacheMap;
    if (map == null) return null;
    final remoteBuild = (map['appBuild'] as num?)?.toInt() ?? 0;
    final apkUrl = (map['apkUrl'] ?? map['apkDownloadUrl'] ?? '').toString().trim();
    if (remoteBuild > currentAppBuild && apkUrl.isNotEmpty) {
      return AppUpdateInfo(
        version: (map['appVersion'] ?? map['latestVersion'] ?? '1.0.$remoteBuild').toString(),
        build: remoteBuild,
        apkUrl: apkUrl,
        notes: (map['updateNotes'] ?? '').toString(),
        force: map['forceUpdate'] == true,
      );
    }
    return null;
  }

  Map<String, dynamic> getCurrentCloudMapSnapshot() {
    if (_remoteCacheMap != null) return Map<String, dynamic>.from(_remoteCacheMap!);
    final cachedRaw = StorageService.instance.getRemoteContentCache();
    if (cachedRaw != null && cachedRaw.isNotEmpty) {
      try {
        final d = jsonDecode(cachedRaw);
        if (d is Map<String, dynamic>) return d;
      } catch (_) {}
    }
    return {
      'appVersion': currentAppVersion,
      'appBuild': currentAppBuild,
      'apkUrl': 'https://github.com',
      'updateNotes': '',
      'forceUpdate': false,
      'videos': <dynamic>[],
      'lessons': <String, dynamic>{'A1': [], 'A2': [], 'B1': [], 'B2': [], 'C1': [], 'C2': []},
    };
  }

  List<ShadowingVideo> getCloudVideosForLevel(String level) {
    final map = _remoteCacheMap;
    if (map == null || map['videos'] is! List) return [];
    final out = <ShadowingVideo>[];
    for (final raw in (map['videos'] as List)) {
      if (raw is Map) {
        final vid = ShadowingVideo.fromJson(Map<String, dynamic>.from(raw));
        if (vid.level.toUpperCase() == level.toUpperCase() && vid.id.isNotEmpty) {
          out.add(vid);
        }
      }
    }
    return out;
  }

  List<LevelVocabItem> getCloudVocabForLevel(String level) {
    final map = _remoteCacheMap;
    if (map == null || map['lessons'] is! Map) return [];
    final list = (map['lessons'] as Map)[level.toUpperCase()];
    if (list is! List) return [];
    return list.whereType<Map>().map((e) => LevelVocabItem.fromJson(Map<String, dynamic>.from(e))).toList();
  }

  Future<List<ShadowingVideo>> fetchShadowingVideos(String level, {bool forceRefresh = false}) async {
    await syncRemoteContent(force: forceRefresh);
    final cloud = getCloudVideosForLevel(level);
    final defaults = FallbackData.videosForLevel(level);
    final merged = <ShadowingVideo>[...cloud];
    for (final d in defaults) {
      if (!merged.any((v) => v.id == d.id)) merged.add(d);
    }
    return merged;
  }

  Future<List<LevelVocabItem>> fetchDynamicLevelItems(String level, {int count = 6}) async {
    await syncRemoteContent();
    final upper = level.toUpperCase();
    final cloud = getCloudVocabForLevel(upper);
    if (cloud.isNotEmpty) return cloud;
    final out = <LevelVocabItem>[];
    for (int i = 0; i < count; i++) {
      out.add(await fetchUnlimitedWord(upper));
    }
    return out;
  }

  Future<String> translateToArabic(String text) async {
    final clean = text.trim();
    if (clean.isEmpty) return '';
    if (_translationCache.containsKey(clean)) return _translationCache[clean]!;
    try {
      final res = await http
          .get(Uri.parse('https://translated.net{Uri.encodeComponent(clean)}&langpair=en|ar'))
          .timeout(const Duration(seconds: 7));
      if (res.statusCode == 200) {
        final translated = (jsonDecode(res.body)['responseData']?['translatedText'] ?? '').toString().trim();
        if (translated.isNotEmpty) {
          _translationCache[clean] = translated;
          return translated;
        }
      }
    } catch (_) {}
    return '';
  }

  Future<WordLookup> lookupWord(String rawWord) async {
    final cleanWord = rawWord.replaceAll(RegExp(r"[^a-zA-Z'-]"), '').toLowerCase();
    if (cleanWord.isEmpty) throw Exception('Invalid word');
    String phonetic = '', example = '', arabic = '';
    await Future.wait([
      http.get(Uri.parse('https://dictionaryapi.dev')).then((res) {
        if (res.statusCode == 200) {
          final list = jsonDecode(res.body);
          if (list is List && list.isNotEmpty && list.first is Map) {
            final entry = Map<String, dynamic>.from(list.first as Map);
            phonetic = (entry['phonetic'] ?? '').toString();
            if (phonetic.isEmpty && entry['phonetics'] is List) {
              for (final p in entry['phonetics']) {
                if (p is Map && (p['text'] ?? '').toString().isNotEmpty) {
                  phonetic = p['text'].toString();
                  break;
                }
              }
            }
            if (entry['meanings'] is List) {
              for (final m in entry['meanings']) {
                if (m is Map) {
                  for (final d in (m['definitions'] as List? ?? [])) {
                    if (d is Map && (d['example'] ?? '').toString().isNotEmpty) {
                      example = d['example'].toString();
                      break;
                    }
                  }
                }
                if (example.isNotEmpty) break;
              }
              if (example.isEmpty && (entry['meanings'] as List).isNotEmpty) {
                final firstM = (entry['meanings'] as List).first;
                if (firstM is Map && (firstM['definitions'] as List?)?.isNotEmpty == true) {
                  final firstD = (firstM['definitions'] as List).first;
                  if (firstD is Map && firstD['definition'] != null) {
                    example = firstD['definition'].toString();
                  }
                }
              }
            }
          }
        }
      }).catchError((_) {}),
      translateToArabic(cleanWord).then((v) => arabic = v).catchError((_) => ''),
    ]);
    return WordLookup(
      word: cleanWord,
      phonetic: phonetic.isNotEmpty ? phonetic : '/$cleanWord/',
      arabic: arabic.isNotEmpty ? arabic : '—',
      example: example.isNotEmpty ? example : 'Use "$cleanWord" in a daily sentence.',
    );
  }
  List<String> _extractSentences(String paragraph) => paragraph
      .replaceAll(RegExp(r'\[[^\]]*\]|\([^\)]*\)'), '')
      .split(RegExp(r'(?<=[.!?])\s+'))
      .map((s) => s.trim())
      .where((s) {
        final wc = s.split(RegExp(r'\s+')).length;
        return wc >= 4 && wc <= 22 && RegExp(r'^[A-Z]').hasMatch(s);
      })
      .toList();

  String _guessLevel(String s) {
    final words = s.trim().split(RegExp(r'\s+'));
    final avg = words.fold<int>(0, (sum, w) => sum + w.length) / max(1, words.length);
    if (words.length <= 8 && avg < 4.7) return 'A1';
    if (words.length <= 11 && avg < 5.2) return 'A2';
    if (words.length <= 14 && avg < 5.7) return 'B1';
    if (words.length <= 17) return 'B2';
    return avg >= 6.0 ? 'C2' : 'C1';
  }

  Future<SentenceItem> fetchUnlimitedSentence({String? preferredLevel}) async {
    await syncRemoteContent();
    if (preferredLevel != null) {
      for (final item in getCloudVocabForLevel(preferredLevel)) {
        if (item.en.isNotEmpty && !_seenSentences.contains(item.en)) {
          _seenSentences.add(item.en);
          return SentenceItem(
            id: 'cloud_${item.en.hashCode}',
            en: item.en,
            ar: item.ar,
            level: preferredLevel.toUpperCase(),
          );
        }
      }
    }
    final isBeginner = preferredLevel == 'A1' || preferredLevel == 'A2';
    final mode = isBeginner ? ((_sentenceTurn++ % 2) + 1) : (_sentenceTurn++ % 3);
    final candidates = <String>[];
    final rng = Random();
    try {
      if (mode == 0) {
        final r = await http
            .get(Uri.parse('https://wikipedia.org'))
            .timeout(const Duration(seconds: 7));
        if (r.statusCode == 200) candidates.addAll(_extractSentences((jsonDecode(r.body)['extract'] ?? '').toString()));
      } else if (mode == 1) {
        final r = await http
            .get(Uri.parse('https://dummyjson.com{rng.nextInt(900)}'))
            .timeout(const Duration(seconds: 7));
        if (r.statusCode == 200) {
          for (final q in (jsonDecode(r.body)['quotes'] as List? ?? [])) {
            final t = (q['quote'] ?? '').toString().trim();
            final wc = t.split(RegExp(r'\s+')).length;
            if (wc >= 5 && wc <= (isBeginner ? 11 : 18)) candidates.add(t);
          }
        }
      } else {
        final r = await http.get(Uri.parse('https://adviceslip.com')).timeout(const Duration(seconds: 7));
        if (r.statusCode == 200) {
          final adv = (jsonDecode(r.body)['slip']?['advice'] ?? '').toString().trim();
          if (adv.isNotEmpty) candidates.add(adv);
        }
      }
    } catch (_) {}

    final fresh = candidates.where((s) => !_seenSentences.contains(s)).toList();
    if (fresh.isNotEmpty) {
      final chosen = fresh[rng.nextInt(fresh.length)];
      _seenSentences.add(chosen);
      final ar = await translateToArabic(chosen);
      return SentenceItem(
        id: 'api_${DateTime.now().millisecondsSinceEpoch}',
        en: chosen,
        ar: ar.isNotEmpty ? ar : 'استمع ورتّب الكلمات لتكوين الجملة الصحيحة.',
        level: preferredLevel ?? _guessLevel(chosen),
      );
    }
    return FallbackData.sentencesForLevel(preferredLevel ?? 'B1').first;
  }

  Future<LevelVocabItem> fetchUnlimitedWord(String level) async {
    await syncRemoteContent();
    final upper = level.toUpperCase();
    for (final item in getCloudVocabForLevel(upper)) {
      if (item.word.isNotEmpty && !_seenWords.contains(item.word.toLowerCase())) {
        _seenWords.add(item.word.toLowerCase());
        return item;
      }
    }
    final seeds = {
      'A1': ['water', 'house', 'friend', 'happy', 'morning', 'school', 'family', 'work', 'food', 'book'],
      'A2': ['travel', 'weather', 'healthy', 'market', 'ticket', 'journey', 'kitchen', 'helpful', 'holiday', 'dinner'],
      'B1': ['decision', 'improve', 'challenge', 'culture', 'opinion', 'achieve', 'protect', 'discover', 'prepare', 'success'],
      'B2': ['strategy', 'influence', 'efficient', 'approach', 'maintain', 'analyze', 'crucial', 'adapt', 'outcome', 'perspective'],
      'C1': ['resilient', 'ambiguous', 'coherent', 'pragmatic', 'scrutiny', 'intricate', 'advocate', 'mitigate', 'eloquent', 'paradigm'],
      'C2': ['ephemeral', 'ubiquitous', 'fastidious', 'magnanimous', 'equivocal', 'perspicacious', 'alacrity', 'ameliorate', 'cacophony', 'esoteric'],
    };
    final pool = seeds[upper] ?? seeds['B1']!;
    final rng = Random();
    final seed = pool[rng.nextInt(pool.length)];
    try {
      final res = await http
          .get(Uri.parse('https://datamuse.com'))
          .timeout(const Duration(seconds: 7));
      if (res.statusCode == 200) {
        final list = (jsonDecode(res.body) as List)
            .map((e) => (e['word'] ?? '').toString().trim())
            .where((w) => RegExp(r'^[a-zA-Z]{4,12}$').hasMatch(w) && !_seenWords.contains(w.toLowerCase()))
            .toList();
        if (list.isNotEmpty) {
          final chosen = list[rng.nextInt(list.length)];
          _seenWords.add(chosen.toLowerCase());
          final info = await lookupWord(chosen);
          final enEx = info.example;
          final arEx = await translateToArabic(enEx);
          return LevelVocabItem(
            word: info.word,
            phonetic: info.phonetic,
            ar: info.arabic,
            en: enEx,
            arSentence: arEx.isNotEmpty ? arEx : 'مثال عملي لاستخدام الكلمة.',
          );
        }
      }
    } catch (_) {}
    return FallbackData.vocabForLevel(upper).first;
  }

  List<WordTiming> buildProportionalWordTimings(String text, int startMs, int endMs) {
    final tokens = text.trim().split(RegExp(r'\s+')).where((t) => t.isNotEmpty).toList();
    if (tokens.isEmpty) return [];
    final totalDur = max(300, endMs - startMs);
    final totalChars = max(1, tokens.fold<int>(0, (sum, t) => sum + t.length));
    final out = <WordTiming>[];
    int cursor = startMs;
    for (int i = 0; i < tokens.length; i++) {
      final share = (totalDur * (tokens[i].length / totalChars)).round();
      final wEnd = (i == tokens.length - 1) ? endMs : min(endMs, cursor + max(100, share));
      out.add(WordTiming(word: tokens[i], startMs: cursor, endMs: max(cursor + 80, wEnd)));
      cursor = wEnd;
    }
    return out;
  }

  List<SubtitleCue> parseSrtOrVtt(String raw) {
    final cues = <SubtitleCue>[];
    final cleaned = raw.replaceAll('\r\n', '\n').replaceFirst(RegExp(r'^WEBVTT[^\n]*\n+'), '').trim();
    if (cleaned.isEmpty) return cues;
    final blocks = cleaned.split(RegExp(r'\n\s*\n'));
    final timeRe = RegExp(r'(\d{1,2}:)?(\d{2}):(\d{2})[.,](\d{3})\s*-->\s*(\d{1,2}:)?(\d{2}):(\d{2})[.,](\d{3})');
    for (final block in blocks) {
      final lines = block.trim().split('\n');
      int timeIdx = -1;
      RegExpMatch? m;
      for (int i = 0; i < lines.length; i++) {
        m = timeRe.firstMatch(lines[i]);
        if (m != null) {
          timeIdx = i;
          break;
        }
      }
      if (m == null || timeIdx == -1) continue;
      int toMs(String? h, String min, String sec, String ms) {
        final hh = int.tryParse((h ?? '0').replaceAll(':', '')) ?? 0;
        final mm = int.tryParse(min) ?? 0;
        final ss = int.tryParse(sec) ?? 0;
        final mmm = int.tryParse(ms) ?? 0;
        return ((hh * 3600 + mm * 60 + ss) * 1000) + mmm;
      }

      final startMs = toMs(m.group(1), m.group(2)!, m.group(3)!, m.group(4)!);
      final endMs = max(startMs + 400, toMs(m.group(5), m.group(6)!, m.group(7)!, m.group(8)!));
      final textLines = lines
          .sublist(timeIdx + 1)
          .map((l) => l.replaceAll(RegExp(r'<[^>]*>'), '').trim())
          .where((l) => l.isNotEmpty)
          .toList();
      if (textLines.isEmpty) continue;
      final en = textLines.first;
      final ar = textLines.length > 1 ? textLines.sublist(1).join(' ') : '';
      cues.add(SubtitleCue(
        startMs: startMs,
        endMs: endMs,
        en: en,
        ar: ar,
        words: buildProportionalWordTimings(en, startMs, endMs),
      ));
    }
    return cues;
  }

  Future<List<SubtitleCue>> loadAndTranslateSubtitles(String videoId, {String? customSrt}) async {
    if (customSrt != null && customSrt.trim().isNotEmpty) {
      final parsed = parseSrtOrVtt(customSrt);
      if (parsed.isNotEmpty) {
        await translateRemainingCues(parsed, maxCount: 12);
        return parsed;
      }
    }
    final cues = await fetchYoutubeCaptions(videoId);
    if (cues.isNotEmpty) {
      await translateRemainingCues(cues, maxCount: 12);
    }
    return cues;
  }

  Future<void> translateRemainingCues(List<SubtitleCue> cues, {int maxCount = 25, VoidCallback? onProgress}) async {
    int translatedCount = 0;
    for (int i = 0; i < cues.length; i++) {
      if (translatedCount >= maxCount) break;
      if (cues[i].ar.trim().isEmpty && cues[i].en.trim().isNotEmpty) {
        final ar = await translateToArabic(cues[i].en);
        if (ar.isNotEmpty) {
          cues[i] = SubtitleCue(
            startMs: cues[i].startMs,
            endMs: cues[i].endMs,
            en: cues[i].en,
            ar: ar,
            words: cues[i].words,
          );
          translatedCount++;
          onProgress?.call();
        }
      }
    }
  }

  Future<List<SubtitleCue>> fetchYoutubeCaptions(String videoId) async {
    try {
      final watchRes = await http
          .get(Uri.parse('https://youtube.com'), headers: _browserHeaders)
          .timeout(const Duration(seconds: 12));
      if (watchRes.statusCode == 200) {
        final html = watchRes.body;
        final match = RegExp(r'"captionTracks":(\[.*?\])').firstMatch(html);
        if (match != null) {
          final tracks = jsonDecode(match.group(1)!) as List;
          String? baseUrl;
          for (final t in tracks) {
            if (t is Map) {
   startMs: cues[i].startMs,
            endMs: cues[i].endMs,
            en: cues[i].en,
            ar: ar,
            words: cues[i].words,
          );
          translatedCount++;
          onProgress?.call();
        }
      }
    }
  }

  Future<List<SubtitleCue>> fetchYoutubeCaptions(String videoId) async {
    try {
      final watchRes = await http
          .get(Uri.parse('https://youtube.com'), headers: _browserHeaders)
          .timeout(const Duration(seconds: 12));
      if (watchRes.statusCode == 200) {
        final html = watchRes.body;
        final match = RegExp(r'"captionTracks":(\[.*?\])').firstMatch(html);
        if (match != null) {
          final tracks = jsonDecode(match.group(1)!) as List;
          String? baseUrl;
          for (final t in tracks) {
            if (t is Map) {
Use code with caution.
final lang = (t['languageCode'] ?? '').toString();
final kind = (t['kind'] ?? '').toString();
if (lang.startsWith('en') && kind != 'asr') {
baseUrl = t['baseUrl']?.toString();
break;
}
}
}
if (baseUrl == null && tracks.isNotEmpty) {
final fallbackTrack = tracks.firstWhere(
(t) => t is Map && (t['languageCode'] ?? '').toString().startsWith('en'),
orElse: () => tracks.first,
);
if (fallbackTrack is Map) {
baseUrl = fallbackTrack['baseUrl']?.toString();
}
}
if (baseUrl != null && baseUrl.isNotEmpty) {
final json3Url = baseUrl.contains('fmt=') ? baseUrl : '$baseUrl&fmt=json3';
final capRes = await http
.get(Uri.parse(json3Url), headers: _browserHeaders)
.timeout(const Duration(seconds: 10));
if (capRes.statusCode == 200 && capRes.body.trim().startsWith('{')) {
final cues = parseYoutubeJson3(capRes.body);
if (cues.isNotEmpty) return cues;
}
}
}
}
} catch () {}
for (final kind in ['', '&kind=asr']) {
try {
final url = 'youtube.com〈=en$kind&fmt=json3';
final res = await http.get(Uri.parse(url), headers: _browserHeaders).timeout(const Duration(seconds: 8));
if (res.statusCode == 200 && res.body.trim().startsWith('{')) {
final cues = parseYoutubeJson3(res.body);
if (cues.isNotEmpty) return cues;
}
} catch () {}
}
return [];
}
static List _parseYoutubeJson3(String body) {
final cues = [];
try {
final decoded = jsonDecode(body);
final events = decoded['events'] as List? ?? [];
for (final ev in events) {
if (ev is! Map || ev['segs'] is! List) continue;
final int tStart = (ev['tStartMs'] as num?)?.toInt() ?? 0;
final int dDur = (ev['dDurationMs'] as num?)?.toInt() ?? 3000;
final int endMs = tStart + max(500, dDur);
final segs = ev['segs'] as List;
final buf = StringBuffer();
final words = [];
for (int i = 0; i < segs.length; i++) {
final seg = segs[i];
if (seg is! Map) continue;
final rawText = (seg['utf8'] ?? '').toString().replaceAll('\n', ' ');
if (rawText.trim().isEmpty) continue;
final int wStart = tStart + ((seg['tOffsetMs'] as num?)?.toInt() ?? 0);
final int nextOff = (i + 1 < segs.length && segs[i + 1] is Map)
? ((segs[i + 1]['tOffsetMs'] as num?)?.toInt() ?? dDur)
: dDur;
final int wEnd = max(wStart + 120, tStart + nextOff);
buf.write(rawText);
for (final token in rawText.trim().split(RegExp(r'\s+'))) {
if (token.isNotEmpty) {
words.add(WordTiming(word: token, startMs: wStart, endMs: wEnd));
}
}
}
final fullText = buf.toString().replaceAll(RegExp(r'\s+'), ' ').trim();
if (fullText.isNotEmpty) {
cues.add(SubtitleCue(
startMs: tStart,
endMs: endMs,
en: fullText,
ar: '',
words: words,
));
}
}
} catch (_) {}
return cues;
}
}