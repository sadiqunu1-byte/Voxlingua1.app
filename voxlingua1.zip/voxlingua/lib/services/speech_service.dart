import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart';
import '../models/app_models.dart';
import 'storage_service.dart';

class SpeechService {
  static final SpeechService instance = SpeechService._();
  SpeechService._();

  final FlutterTts _tts = FlutterTts();
  final SpeechToText _stt = SpeechToText();
  bool _ttsReady = false;
  bool _sttAvailable = false;

  void playTapClick() {
    if (!StorageService.instance.clickSound) return;
    SystemSound.play(SystemSoundType.click);
  }

  Future<void> _ensureTts() async {
    if (_ttsReady) return;
    await _tts.setLanguage('en-US');
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);
    await _tts.awaitSpeakCompletion(true);
    try {
      final voices = await _tts.getVoices;
      if (voices is List) {
        final enVoice = voices.cast<Map>().firstWhere(
          (v) {
            final loc = (v['locale'] ?? '').toString().toLowerCase();
            return loc == 'en-us' || loc == 'en_us' || loc == 'en-gb' || loc == 'en_gb';
          },
          orElse: () => {},
        );
        if (enVoice.isNotEmpty && enVoice['name'] != null && enVoice['locale'] != null) {
          await _tts.setVoice({
            'name': enVoice['name'].toString(),
            'locale': enVoice['locale'].toString(),
          });
        }
      }
    } catch (_) {}
    _ttsReady = true;
  }

  Future<void> speakEnglish(
    String text, {
    bool slow = false,
    VoidCallback? onStart,
    VoidCallback? onDone,
  }) async {
    if (text.trim().isEmpty) return;
    await _ensureTts();
    await _tts.stop();
    await _tts.setSpeechRate(slow ? 0.30 : 0.50);
    _tts.setStartHandler(() => onStart?.call());
    _tts.setCompletionHandler(() => onDone?.call());
    _tts.setCancelHandler(() => onDone?.call());
    _tts.setErrorHandler((_) => onDone?.call());
    onStart?.call();
    await _tts.speak(text);
  }

  Future<void> stopSpeaking() async {
    await _tts.stop();
  }

  Future<String?> startListening({
    required void Function(String liveText) onLive,
    required void Function(String finalText) onFinal,
    required VoidCallback onStopped,
  }) async {
    if (_stt.isListening) {
      await _stt.stop();
      onStopped();
      return null;
    }

    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      onStopped();
      return 'micDenied';
    }

    if (!_sttAvailable) {
      _sttAvailable = await _stt.initialize(
        onStatus: (s) {
          if (s == 'done' || s == 'notListening') {
            onStopped();
          }
        },
        onError: (_) => onStopped(),
      );
    }

    if (!_sttAvailable) {
      onStopped();
      return 'micUnavailable';
    }

    String latest = '';
    await _stt.listen(
      localeId: 'en_US',
      listenOptions: SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
        listenMode: ListenMode.dictation,
      ),
      onResult: (result) {
        latest = result.recognizedWords.trim();
        onLive(latest);
        if (result.finalResult && latest.isNotEmpty) {
          onFinal(latest);
          onStopped();
        }
      },
    );
    return null;
  }

  Future<void> stopListening() async {
    if (_stt.isListening) {
      await _stt.stop();
    }
  }

  static String cleanText(String input) {
    return input
        .toLowerCase()
        .replaceAll(RegExp(r"[^\w\s']"), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static int levenshtein(String a, String b) {
    final m = a.length;
    final n = b.length;
    final dp = List.generate(m + 1, (_) => List<int>.filled(n + 1, 0));
    for (int i = 0; i <= m; i++) dp[i][0] = i;
    for (int j = 0; j <= n; j++) dp[0][j] = j;

    for (int i = 1; i <= m; i++) {
      for (int j = 1; j <= n; j++) {
        final cost = a[i - 1] == b[j - 1] ? 0 : 1;
        dp[i][j] = min(
          dp[i - 1][j] + 1,
          min(dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost),
        );
      }
    }
    return dp[m][n];
  }

  PronunciationEval evaluate(String target, String spoken) {
    final cTarget = cleanText(target);
    final cSpoken = cleanText(spoken);
    if (cTarget.isEmpty) return const PronunciationEval(score: 0, words: []);

    final maxLen = max(cTarget.length, cSpoken.length);
    final dist = levenshtein(cTarget, cSpoken);
    final charSim = maxLen == 0 ? 0 : (((maxLen - dist) / maxLen) * 100).round().clamp(0, 100);

    final rawWords = target.trim().split(RegExp(r'\s+'));
    final spokenWords = cSpoken.isEmpty ? <String>[] : cSpoken.split(' ');

    int matched = 0;
    final feedback = rawWords.map((orig) {
      final cw = cleanText(orig);
      final ok = spokenWords.any((sw) => sw == cw || (cw.length >= 4 && levenshtein(cw, sw) <= 1));
      if (ok) matched++;
      return WordFeedback(text: orig, isCorrect: ok);
    }).toList();

    final wordSim = ((matched / rawWords.length) * 100).round();
    final finalScore = ((charSim * 0.45) + (wordSim * 0.55)).round().clamp(0, 100);
    return PronunciationEval(score: finalScore, words: feedback);
  }
}