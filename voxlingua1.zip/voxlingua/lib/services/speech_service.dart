import 'dart:async';
import 'dart:convert';
import 'dart:math';
import 'package:flutter/foundation.dart';
import 'package:flutter/services.dart';
import 'package:flutter_tts/flutter_tts.dart';
import 'package:http/http.dart' as http;
import 'package:permission_handler/permission_handler.dart';
import 'package:speech_to_text/speech_to_text.dart';
import 'package:video_player/video_player.dart';
import '../models/app_models.dart';
import 'storage_service.dart';

class SpeechService {
  static final SpeechService instance = SpeechService._();
  SpeechService._();

  final FlutterTts _tts = FlutterTts();
  final SpeechToText _stt = SpeechToText();
  bool _ttsReady = false;
  bool _sttAvailable = false;

  // ---------------------------------------------------------------------------
  // إعدادات النطق (مناسبة للمتعلمين)
  // ---------------------------------------------------------------------------
  static const double _normalRate = 0.42;
  static const double _slowRate = 0.28;

  Map<String, String>? _bestVoice;
  Map<String, String>? _localVoice;
  bool _usingNetworkVoice = false;

  // ---------------------------------------------------------------------------
  // النطق البشري للكلمات المفردة (dictionaryapi.dev + video_player كمشغّل صوت)
  // ---------------------------------------------------------------------------
  final Map<String, String?> _audioUrlCache = {};
  VideoPlayerController? _audioCtrl;
  VoidCallback? _audioDone;
  int _playToken = 0;

  void playTapClick() {
    if (!StorageService.instance.clickSound) return;
    SystemSound.play(SystemSoundType.click);
  }

  // ---------------------------------------------------------------------------
  // اختيار أفضل صوت إنجليزي على الجهاز
  // ---------------------------------------------------------------------------
  static final RegExp _novelty = RegExp(
    r'fred|albert|bad news|good news|bahh|bells|boing|bubbles|cellos|jester|'
    r'organ|superstar|trinoids|whisper|wobble|zarvox|junior|ralph|kathy|princess',
  );

  int _scoreVoice(Map voice, {required bool network}) {
    final name = (voice['name'] ?? '').toString().toLowerCase();
    final loc = (voice['locale'] ?? '').toString().toLowerCase().replaceAll('_', '-');
    int score = loc == 'en-us' ? 100 : 80;

    if (network) score += 60;
    if (name.contains('neural') || name.contains('wavenet')) score += 50;
    if (name.contains('premium') || name.contains('enhanced')) score += 40;
    if (name.contains('siri')) score += 30;
    if (name.contains('high')) score += 20;
    if (name.contains('compact') || name.contains('embedded')) score -= 40;
    if (name.contains('low')) score -= 30;
    if (_novelty.hasMatch(name)) score -= 200;

    final q = voice['quality'];
    if (q is num) score += (q / 10).round(); // أندرويد: 500 = جودة عالية جداً
    return score;
  }

  bool _isNetworkVoice(Map voice) {
    final name = (voice['name'] ?? '').toString().toLowerCase();
    final req = voice['network_required'];
    return name.contains('network') || req == true || req == '1' || req == 1;
  }

  Future<void> _pickBestVoice() async {
    try {
      final voices = await _tts.getVoices;
      if (voices is! List) return;

      Map? best, bestLocal;
      int bestScore = -100000, bestLocalScore = -100000;

      for (final raw in voices) {
        if (raw is! Map) continue;
        final loc = (raw['locale'] ?? '').toString().toLowerCase().replaceAll('_', '-');
        if (loc != 'en-us' && loc != 'en-gb') continue;
        if (raw['name'] == null || raw['locale'] == null) continue;
        final features = (raw['features'] ?? '').toString().toLowerCase();
        if (features.contains('notinstalled')) continue;

        final network = _isNetworkVoice(raw);
        final s = _scoreVoice(raw, network: network);
        if (s > bestScore) {
          bestScore = s;
          best = raw;
        }
        if (!network && s > bestLocalScore) {
          bestLocalScore = s;
          bestLocal = raw;
        }
      }

      Map<String, String>? toVoice(Map? m) => m == null
          ? null
          : {'name': m['name'].toString(), 'locale': m['locale'].toString()};

      _bestVoice = toVoice(best);
      _localVoice = toVoice(bestLocal);
      _usingNetworkVoice = best != null && _isNetworkVoice(best);

      if (_bestVoice != null) {
        await _tts.setVoice(_bestVoice!);
      }
    } catch (_) {}
  }

  Future<void> _ensureTts() async {
    if (_ttsReady) return;
    await _tts.setLanguage('en-US');
    await _tts.setPitch(1.0);
    await _tts.setVolume(1.0);
    await _tts.awaitSpeakCompletion(true);
    await _pickBestVoice();
    _ttsReady = true;
  }

  // ---------------------------------------------------------------------------
  // أدوات النطق البشري
  // ---------------------------------------------------------------------------
  static final RegExp _wordRe = RegExp(r"^[A-Za-z][A-Za-z'’\-]*$");

  /// يُرجع الكلمة نظيفة إذا كان النص كلمة إنجليزية مفردة، وإلا null.
  String? _asSingleWord(String text) {
    final w = text
        .trim()
        .replaceAll(RegExp(r'[.,!?;:"“”]+$'), '')
        .replaceAll(RegExp(r'^["“”]+'), '')
        .trim();
    if (w.length < 2 || !_wordRe.hasMatch(w)) return null;
    return w;
  }

  Future<String?> _fetchWordAudioUrl(String word) async {
    final key = word.toLowerCase();
    if (_audioUrlCache.containsKey(key)) return _audioUrlCache[key];

    String? result;
    try {
      final res = await http
          .get(Uri.parse('https://api.dictionaryapi.dev/v2/entries/en/${Uri.encodeComponent(key)}'))
          .timeout(const Duration(seconds: 4));

      if (res.statusCode == 200) {
        final data = jsonDecode(res.body);
        if (data is List) {
          String? us, any;
          for (final entry in data) {
            if (entry is! Map) continue;
            final phonetics = entry['phonetics'];
            if (phonetics is! List) continue;
            for (final p in phonetics) {
              if (p is! Map) continue;
              var a = (p['audio'] ?? '').toString().trim();
              if (a.isEmpty) continue;
              if (a.startsWith('//')) a = 'https:$a';
              if (!a.startsWith('http')) continue;
              any ??= a;
              if (a.toLowerCase().contains('-us')) us ??= a;
            }
          }
          result = us ?? any;
        }
        _audioUrlCache[key] = result;
      } else if (res.statusCode == 404) {
        _audioUrlCache[key] = null; // الكلمة غير موجودة، لا داعي لإعادة المحاولة
      }
    } catch (_) {
      // خطأ شبكة: لا نخزّنه حتى نحاول لاحقاً
    }
    return result;
  }

  Future<void> _stopAudio() async {
    final c = _audioCtrl;
    final done = _audioDone;
    _audioCtrl = null;
    _audioDone = null;
    if (c != null) {
      try {
        await c.pause();
      } catch (_) {}
      try {
        await c.dispose();
      } catch (_) {}
    }
    done?.call();
  }

  /// يحاول تشغيل التسجيل البشري. يعيد true إذا بدأ التشغيل (أو أُلغي لأن طلباً أحدث وصل).
  Future<bool> _playHumanWord(String word, int token, VoidCallback? onDone) async {
    VideoPlayerController? ctrl;
    try {
      final url = await _fetchWordAudioUrl(word);
      if (url == null) return false;
      if (token != _playToken) return true;

      ctrl = VideoPlayerController.networkUrl(
        Uri.parse(url),
        videoPlayerOptions: VideoPlayerOptions(mixWithOthers: true),
      );
      await ctrl.initialize().timeout(const Duration(seconds: 6));

      if (token != _playToken) {
        await ctrl.dispose();
        return true;
      }

      final player = ctrl;
      _audioCtrl = player;
      _audioDone = onDone;

      var finished = false;
      void listener() {
        if (finished) return;
        final v = player.value;
        if (v.isCompleted || v.hasError) {
          finished = true;
          if (identical(_audioCtrl, player)) {
            final done = _audioDone;
            _audioCtrl = null;
            _audioDone = null;
            scheduleMicrotask(() async {
              try {
                await player.dispose();
              } catch (_) {}
              done?.call();
            });
          }
        }
      }

      player.addListener(listener);
      await player.setVolume(1.0);
      await player.play();
      return true;
    } catch (_) {
      if (identical(_audioCtrl, ctrl)) {
        _audioCtrl = null;
        _audioDone = null;
      }
      try {
        await ctrl?.dispose();
      } catch (_) {}
      return false;
    }
  }

  Future<void> _speakWithTts(
    String text, {
    required bool slow,
    VoidCallback? onStart,
    VoidCallback? onDone,
  }) async {
    await _ensureTts();
    await _tts.stop();
    await _tts.setSpeechRate(slow ? _slowRate : _normalRate);

    var started = false;
    void fireStart() {
      if (started) return;
      started = true;
      onStart?.call();
    }

    var retried = false;
    _tts.setStartHandler(fireStart);
    _tts.setCompletionHandler(() => onDone?.call());
    _tts.setCancelHandler(() => onDone?.call());
    _tts.setErrorHandler((_) async {
      // إذا فشل صوت الشبكة (لا إنترنت) نعود لأفضل صوت محلي مرة واحدة
      if (!retried && _usingNetworkVoice && _localVoice != null) {
        retried = true;
        _usingNetworkVoice = false;
        _bestVoice = _localVoice;
        try {
          await _tts.setVoice(_localVoice!);
          await _tts.speak(text);
          return;
        } catch (_) {}
      }
      onDone?.call();
    });

    fireStart();
    await _tts.speak(text);
  }

  // ---------------------------------------------------------------------------
  // الدالة العامة (نفس الاسم والتوقيع السابق)
  // ---------------------------------------------------------------------------
  Future<void> speakEnglish(
    String text, {
    bool slow = false,
    VoidCallback? onStart,
    VoidCallback? onDone,
  }) async {
    final clean = text.trim();
    if (clean.isEmpty) return;

    final token = ++_playToken;
    await _stopAudio();
    try {
      await _tts.stop();
    } catch (_) {}

    final word = _asSingleWord(clean);
    if (word != null) {
      onStart?.call();
      final played = await _playHumanWord(word, token, onDone);
      if (played) return;
      if (token != _playToken) return;
      await _speakWithTts(clean, slow: slow, onStart: null, onDone: onDone);
      return;
    }

    await _speakWithTts(clean, slow: slow, onStart: onStart, onDone: onDone);
  }

  Future<void> stopSpeaking() async {
    _playToken++;
    await _stopAudio();
    await _tts.stop();
  }

  Future<String?> startListening({
    required void Function(String liveText) onLive,
    required void Function(String finalText) onFinal,
    required VoidCallback onStopped,
  }) async {
    if (_stt.isListening) {
      await _stt.stop();
      onStopped();
      return null;
    }

    final status = await Permission.microphone.request();
    if (!status.isGranted) {
      onStopped();
      return 'micDenied';
    }

    if (!_sttAvailable) {
      _sttAvailable = await _stt.initialize(
        onStatus: (s) {
          if (s == 'done' || s == 'notListening') {
            onStopped();
          }
        },
        onError: (_) => onStopped(),
      );
    }

    if (!_sttAvailable) {
      onStopped();
      return 'micUnavailable';
    }

    String latest = '';
    await _stt.listen(
      localeId: 'en_US',
      listenOptions: SpeechListenOptions(
        partialResults: true,
        cancelOnError: true,
        listenMode: ListenMode.dictation,
      ),
      onResult: (result) {
        latest = result.recognizedWords.trim();
        onLive(latest);
        if (result.finalResult && latest.isNotEmpty) {
          onFinal(latest);
          onStopped();
        }
      },
    );
    return null;
  }

  Future<void> stopListening() async {
    if (_stt.isListening) {
      await _stt.stop();
    }
  }

  static String cleanText(String input) {
    return input
        .toLowerCase()
        .replaceAll(RegExp(r"[^\w\s']"), ' ')
        .replaceAll(RegExp(r'\s+'), ' ')
        .trim();
  }

  static int levenshtein(String a, String b) {
    final m = a.length;
    final n = b.length;
    final dp = List.generate(m + 1, (_) => List<int>.filled(n + 1, 0));
    for (int i = 0; i <= m; i++) dp[i][0] = i;
    for (int j = 0; j <= n; j++) dp[0][j] = j;

    for (int i = 1; i <= m; i++) {
      for (int j = 1; j <= n; j++) {
        final cost = a[i - 1] == b[j - 1] ? 0 : 1;
        dp[i][j] = min(
          dp[i - 1][j] + 1,
          min(dp[i][j - 1] + 1, dp[i - 1][j - 1] + cost),
        );
      }
    }
    return dp[m][n];
  }

  PronunciationEval evaluate(String target, String spoken) {
    final cTarget = cleanText(target);
    final cSpoken = cleanText(spoken);
    if (cTarget.isEmpty) return const PronunciationEval(score: 0, words: []);

    final maxLen = max(cTarget.length, cSpoken.length);
    final dist = levenshtein(cTarget, cSpoken);
    final charSim = maxLen == 0 ? 0 : (((maxLen - dist) / maxLen) * 100).round().clamp(0, 100);

    final rawWords = target.trim().split(RegExp(r'\s+'));
    final spokenWords = cSpoken.isEmpty ? <String>[] : cSpoken.split(' ');

    int matched = 0;
    final feedback = rawWords.map((orig) {
      final cw = cleanText(orig);
      final ok = spokenWords.any((sw) => sw == cw || (cw.length >= 4 && levenshtein(cw, sw) <= 1));
      if (ok) matched++;
      return WordFeedback(text: orig, isCorrect: ok);
    }).toList();

    final wordSim = ((matched / rawWords.length) * 100).round();
    final finalScore = ((charSim * 0.45) + (wordSim * 0.55)).round().clamp(0, 100);
    return PronunciationEval(score: finalScore, words: feedback);
  }
}
