import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/app_models.dart';

class StorageService extends ChangeNotifier {
  static final StorageService instance = StorageService._();
  StorageService._();

  static const String defaultRemoteJsonUrl =
      'https://raw.githubusercontent.com/sadiqunu1-byte/Voxlingua1.app/main/lessons.json';

  SharedPreferences? _prefs;
  String lang = 'ar';
  int fontScalePercent = 100;
  bool clickSound = true;
  int streak = 0;
  String lastStreakDate = '';
  String remoteJsonUrl = defaultRemoteJsonUrl;
  String lastSyncIso = '';
  List<WordLookup> savedWords = [];
  List<String> masteredIds = [];
  Map<String, int> masteredByLevel = {'A1': 0, 'A2': 0, 'B1': 0, 'B2': 0, 'C1': 0, 'C2': 0};

  Future<void> init(Locale deviceLocale) async {
    _prefs = await SharedPreferences.getInstance();
    final defaultLang = deviceLocale.languageCode.toLowerCase() == 'ar' ? 'ar' : 'en';
    lang = _prefs?.getString('lang') ?? defaultLang;
    fontScalePercent = (_prefs?.getInt('fontScale') ?? 100).clamp(80, 150);
    clickSound = _prefs?.getBool('clickSound') ?? true;
    streak = _prefs?.getInt('streak') ?? 0;
    lastStreakDate = _prefs?.getString('lastStreakDate') ?? '';
    remoteJsonUrl = _prefs?.getString('remoteJsonUrl') ?? defaultRemoteJsonUrl;
    lastSyncIso = _prefs?.getString('lastSyncIso') ?? '';
    masteredIds = _prefs?.getStringList('masteredIds') ?? [];

    final savedJson = _prefs?.getString('savedWords');
    if (savedJson != null && savedJson.isNotEmpty) {
      try {
        savedWords = (jsonDecode(savedJson) as List).map((e) => WordLookup.fromJson(e as Map<String, dynamic>)).toList();
      } catch (_) {}
    }

    final lvlJson = _prefs?.getString('masteredByLevel');
    if (lvlJson != null && lvlJson.isNotEmpty) {
      try {
        final map = jsonDecode(lvlJson) as Map<String, dynamic>;
        for (final k in masteredByLevel.keys) {
          masteredByLevel[k] = (map[k] as num?)?.toInt() ?? 0;
        }
      } catch (_) {}
    }
    notifyListeners();
  }

  Future<void> setLanguage(String newLang) async {
    lang = newLang;
    await _prefs?.setString('lang', newLang);
    notifyListeners();
  }

  Future<void> setFontScale(int percent) async {
    fontScalePercent = percent.clamp(80, 150);
    await _prefs?.setInt('fontScale', fontScalePercent);
    notifyListeners();
  }

  Future<void> setClickSound(bool enabled) async {
    clickSound = enabled;
    await _prefs?.setBool('clickSound', enabled);
    notifyListeners();
  }

  Future<void> setRemoteJsonUrl(String url) async {
    remoteJsonUrl = url.trim().isEmpty ? defaultRemoteJsonUrl : url.trim();
    await _prefs?.setString('remoteJsonUrl', remoteJsonUrl);
    notifyListeners();
  }

  Future<void> saveRemoteContentCache(String rawJson) async {
    await _prefs?.setString('remote_content_cache', rawJson);
    lastSyncIso = DateTime.now().toIso8601String();
    await _prefs?.setString('lastSyncIso', lastSyncIso);
    notifyListeners();
  }

  String? getRemoteContentCache() => _prefs?.getString('remote_content_cache');

  Future<bool> saveWord(WordLookup item) async {
    if (savedWords.any((w) => w.word.toLowerCase() == item.word.toLowerCase())) return false;
    savedWords.insert(0, item);
    await _prefs?.setString('savedWords', jsonEncode(savedWords.map((w) => w.toJson()).toList()));
    notifyListeners();
    return true;
  }

  Future<void> deleteWord(int index) async {
    if (index < 0 || index >= savedWords.length) return;
    savedWords.removeAt(index);
    await _prefs?.setString('savedWords', jsonEncode(savedWords.map((w) => w.toJson()).toList()));
    notifyListeners();
  }

  Future<void> markMasteredAndStreak(String itemId, {String? levelCode}) async {
    final now = DateTime.now();
    final today = '${now.year}-${now.month.toString().padLeft(2, '0')}-${now.day.toString().padLeft(2, '0')}';
    final yest = now.subtract(const Duration(days: 1));
    final yesterday = '${yest.year}-${yest.month.toString().padLeft(2, '0')}-${yest.day.toString().padLeft(2, '0')}';

    if (lastStreakDate != today) {
      streak = (lastStreakDate == yesterday) ? streak + 1 : 1;
      lastStreakDate = today;
      await _prefs?.setInt('streak', streak);
      await _prefs?.setString('lastStreakDate', today);
    }
    if (itemId.isNotEmpty && !masteredIds.contains(itemId)) {
      masteredIds.add(itemId);
      await _prefs?.setStringList('masteredIds', masteredIds);
      if (levelCode != null && masteredByLevel.containsKey(levelCode)) {
        masteredByLevel[levelCode] = (masteredByLevel[levelCode] ?? 0) + 1;
        await _prefs?.setString('masteredByLevel', jsonEncode(masteredByLevel));
      }
    }
    notifyListeners();
  }
}