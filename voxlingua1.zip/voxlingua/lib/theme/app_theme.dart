import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';

class AppColors {
  static const Color bgMain = Color(0xFFFFFFFF);
  static const Color bgSoft = Color(0xFFF8FAFC);
  static const Color tealDark = Color(0xFF0B3B3C);
  static const Color tealSub = Color(0xFF0F4C4E);
  static const Color tealAccent = Color(0xFF4FD1C5);
  static const Color greenLight = Color(0xFFA7F3D0);
  static const Color greenText = Color(0xFF064E3B);
  static const Color orangeSoft = Color(0xFFFED7AA);
  static const Color orangeText = Color(0xFF7C2D12);
}

class AppTheme {
  static ThemeData buildTheme(bool isArabic) {
    final baseText = isArabic
        ? GoogleFonts.readexProTextTheme()
        : GoogleFonts.outfitTextTheme();

    return ThemeData(
      useMaterial3: true,
      scaffoldBackgroundColor: AppColors.bgSoft,
      colorScheme: ColorScheme.fromSeed(
        seedColor: AppColors.tealDark,
        primary: AppColors.tealDark,
        secondary: AppColors.tealAccent,
        surface: AppColors.bgMain,
      ),
      textTheme: baseText.apply(
        bodyColor: AppColors.tealDark,
        displayColor: AppColors.tealDark,
      ),
    );
  }
}

class VoxlinguaLogo extends StatelessWidget {
  final double fontSize;
  final Color color;

  const VoxlinguaLogo({
    super.key,
    this.fontSize = 22,
    this.color = AppColors.tealDark,
  });

  @override
  Widget build(BuildContext context) {
    return Directionality(
      textDirection: TextDirection.ltr,
      child: RichText(
        text: TextSpan(
          style: GoogleFonts.outfit(
            fontSize: fontSize,
            color: color,
            letterSpacing: -0.4,
          ),
          children: const [
            TextSpan(
              text: 'Vox',
              style: TextStyle(fontWeight: FontWeight.w300),
            ),
            TextSpan(
              text: 'lingua',
              style: TextStyle(fontWeight: FontWeight.w700),
            ),
          ],
        ),
      ),
    );
  }
}