import 'package:flutter/gestures.dart';
import 'package:flutter/material.dart';
import '../data/fallback_data.dart';
import '../models/app_models.dart';
import '../services/api_service.dart';
import '../services/speech_service.dart';
import '../services/storage_service.dart';
import '../theme/app_theme.dart';

Future<void> showWordBottomSheet(BuildContext context, String rawWord) async {
  final clean = rawWord.replaceAll(RegExp(r"[^a-zA-Z'-]"), '');
  if (clean.isEmpty) return;
  SpeechService.instance.playTapClick();
  showModalBottomSheet(
    context: context,
    backgroundColor: AppColors.tealDark,
    shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(26))),
    builder: (_) => _WordSheetBody(rawWord: clean),
  );
}

class _WordSheetBody extends StatefulWidget {
  final String rawWord;
  const _WordSheetBody({required this.rawWord});
  @override
  State<_WordSheetBody> createState() => _WordSheetBodyState();
}

class _WordSheetBodyState extends State<_WordSheetBody> {
  WordLookup? _data;
  bool _loading = true, _hasError = false;

  @override
  void initState() { super.initState(); _load(); }

  Future<void> _load() async {
    try {
      final res = await ApiService.instance.lookupWord(widget.rawWord);
      if (mounted) setState(() { _data = res; _loading = false; });
    } catch (_) {
      if (mounted) setState(() { _hasError = true; _loading = false; });
    }
  }

  @override
  Widget build(BuildContext context) {
    final lang = StorageService.instance.lang;
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(20, 12, 20, 22),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Center(child: Container(width: 44, height: 5, decoration: BoxDecoration(color: Colors.white30, borderRadius: BorderRadius.circular(99)))),
            const SizedBox(height: 16),
            if (_loading) ...[
              const Center(child: CircularProgressIndicator(color: AppColors.tealAccent)),
              const SizedBox(height: 12),
              Text(AppStrings.get(lang, 'loadingWord'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white)),
            ] else if (_hasError || _data == null)
              Text(AppStrings.get(lang, 'wordError'), textAlign: TextAlign.center, style: const TextStyle(color: Colors.white, fontSize: 15))
            else ...[
              Row(
                mainAxisAlignment: MainAxisAlignment.spaceBetween,
                children: [
                  Expanded(
                    child: Directionality(
                      textDirection: TextDirection.ltr,
                      child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                        Text(_data!.word, style: const TextStyle(color: AppColors.tealAccent, fontSize: 24, fontWeight: FontWeight.w700)),
                        Text(_data!.phonetic, style: const TextStyle(color: Colors.white70, fontSize: 15)),
                      ]),
                    ),
                  ),
                  IconButton.filled(
                    style: IconButton.styleFrom(backgroundColor: AppColors.tealAccent, foregroundColor: AppColors.tealDark),
                    onPressed: () { SpeechService.instance.playTapClick(); SpeechService.instance.speakEnglish(_data!.word); },
                    icon: const Icon(Icons.volume_up_rounded),
                  ),
                ],
              ),
              const SizedBox(height: 14),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: AppColors.tealSub, borderRadius: BorderRadius.circular(16)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(AppStrings.get(lang, 'meaningAr'), style: const TextStyle(color: AppColors.tealAccent, fontSize: 12)),
                  const SizedBox(height: 4),
                  Text(_data!.arabic, style: const TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w700)),
                ]),
              ),
              const SizedBox(height: 10),
              Container(
                padding: const EdgeInsets.all(12),
                decoration: BoxDecoration(color: AppColors.tealSub, borderRadius: BorderRadius.circular(16)),
                child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
                  Text(AppStrings.get(lang, 'exampleSentence'), style: const TextStyle(color: AppColors.tealAccent, fontSize: 12)),
                  const SizedBox(height: 4),
                  Directionality(textDirection: TextDirection.ltr, child: Text(_data!.example, style: const TextStyle(color: Colors.white, fontSize: 14))),
                ]),
              ),
              const SizedBox(height: 14),
              ElevatedButton.icon(
                style: ElevatedButton.styleFrom(
                  backgroundColor: AppColors.tealAccent, foregroundColor: AppColors.tealDark,
                  padding: const EdgeInsets.symmetric(vertical: 13),
                  shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(16)),
                ),
                onPressed: () async {
                  SpeechService.instance.playTapClick();
                  final messenger = ScaffoldMessenger.of(context);
                  final ok = await StorageService.instance.saveWord(_data!);
                  if (!mounted) return;
                  Navigator.pop(context);
                  messenger.showSnackBar(SnackBar(content: Text(AppStrings.get(lang, ok ? 'savedSuccess' : 'alreadySaved')), backgroundColor: AppColors.tealDark));
                },
                icon: const Icon(Icons.bookmark_add_rounded),
                label: Text(AppStrings.get(lang, 'saveToMyWords'), style: const TextStyle(fontWeight: FontWeight.w700)),
              ),
            ],
          ],
        ),
      ),
    );
  }
}

class ClickableSentence extends StatelessWidget {
  final String text;
  final TextStyle style;
  final TextAlign textAlign;
  const ClickableSentence({super.key, required this.text, required this.style, this.textAlign = TextAlign.left});

  @override
  Widget build(BuildContext context) {
    final words = text.trim().split(RegExp(r'\s+'));
    return Directionality(
      textDirection: TextDirection.ltr,
      child: Wrap(
        alignment: textAlign == TextAlign.center ? WrapAlignment.center : WrapAlignment.start,
        spacing: 5, runSpacing: 4,
        children: words.map((w) => InkWell(
          borderRadius: BorderRadius.circular(8),
          onTap: () => showWordBottomSheet(context, w),
          child: Padding(padding: const EdgeInsets.symmetric(horizontal: 2, vertical: 1), child: Text(w, style: style)),
        )).toList(),
      ),
    );
  }
}

class WordHighlightedSentence extends StatefulWidget {
  final SubtitleCue cue;
  final int posMs;
  final TextStyle baseStyle;
  final TextAlign textAlign;
  const WordHighlightedSentence({super.key, required this.cue, required this.posMs, required this.baseStyle, this.textAlign = TextAlign.left});
  @override
  State<WordHighlightedSentence> createState() => _WordHighlightedSentenceState();
}

class _WordHighlightedSentenceState extends State<WordHighlightedSentence> {
  final List<TapGestureRecognizer> _recognizers = [];
  late List<WordTiming> _timings;

  @override
  void initState() { super.initState(); _syncTimings(); }

  @override
  void didUpdateWidget(covariant WordHighlightedSentence oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (oldWidget.cue.en != widget.cue.en || oldWidget.cue.words.length != widget.cue.words.length) _syncTimings();
  }

  void _syncTimings() {
    for (final r in _recognizers) { r.dispose(); }
    _recognizers.clear();
    _timings = widget.cue.words.isNotEmpty ? widget.cue.words : ApiService.buildProportionalWordTimings(widget.cue.en, widget.cue.startMs, widget.cue.endMs);
    for (final wt in _timings) { _recognizers.add(TapGestureRecognizer()..onTap = () => showWordBottomSheet(context, wt.word)); }
  }

  @override
  void dispose() {
    for (final r in _recognizers) { r.dispose(); }
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final spans = <InlineSpan>[];
    for (int i = 0; i < _timings.length; i++) {
      final wt = _timings[i];
      final isActive = widget.posMs >= wt.startMs && widget.posMs <= wt.endMs;
      final isSpoken = widget.posMs > wt.endMs;
      spans.add(TextSpan(
        text: i == _timings.length - 1 ? wt.word : '${wt.word} ',
        recognizer: _recognizers[i],
        style: isActive
            ? widget.baseStyle.copyWith(color: AppColors.tealAccent, fontWeight: FontWeight.w800, backgroundColor: AppColors.tealAccent.withValues(alpha: 0.18))
            : widget.baseStyle.copyWith(color: isSpoken ? Colors.white : Colors.white70),
      ));
    }
    return Directionality(textDirection: TextDirection.ltr, child: RichText(textAlign: widget.textAlign, text: TextSpan(style: widget.baseStyle, children: spans)));
  }
}

class AnimatedWaveform extends StatefulWidget {
  final bool playing;
  const AnimatedWaveform({super.key, required this.playing});
  @override
  State<AnimatedWaveform> createState() => _AnimatedWaveformState();
}

class _AnimatedWaveformState extends State<AnimatedWaveform> with SingleTickerProviderStateMixin {
  late final AnimationController _ctrl;
  @override
  void initState() {
    super.initState();
    _ctrl = AnimationController(vsync: this, duration: const Duration(milliseconds: 650));
    if (widget.playing) _ctrl.repeat(reverse: true);
  }
  @override
  void didUpdateWidget(covariant AnimatedWaveform oldWidget) {
    super.didUpdateWidget(oldWidget);
    if (widget.playing && !_ctrl.isAnimating) { _ctrl.repeat(reverse: true); }
    else if (!widget.playing && _ctrl.isAnimating) { _ctrl.stop(); _ctrl.value = 0; }
  }
  @override
  void dispose() { _ctrl.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    const offsets = [0.2, 0.5, 0.9, 0.4, 0.8, 0.3, 0.6];
    return SizedBox(
      height: 28,
      child: AnimatedBuilder(
        animation: _ctrl,
        builder: (_, __) => Row(
          mainAxisAlignment: MainAxisAlignment.center,
          children: List.generate(7, (i) {
            final v = widget.playing ? (0.25 + 0.75 * ((_ctrl.value + offsets[i]) % 1.0)) : 0.25;
            return Container(
              width: 4, height: 24, margin: const EdgeInsets.symmetric(horizontal: 3), alignment: Alignment.center,
              child: Transform.scale(scaleY: v, child: Container(width: 4, height: 24, decoration: BoxDecoration(color: AppColors.tealAccent.withValues(alpha: widget.playing ? 1 : 0.45), borderRadius: BorderRadius.circular(99)))),
            );
          }),
        ),
      ),
    );
  }
}